Anatomical hand contact tests

Requires Python 3.12, mujoco 3.14, numpy, scipy.
From this extracted folder: python sim_v3/run_hands.py lift
Then: python sim_v3/run_hands.py turn
Then: python sim_v3/verify_hands.py
The two model XML files are also standalone MuJoCo models.
Render with Blender 4.5: blender -b --python sim_v3/render_hand.py
Set HAND_MODE=turn to render the turning experiment.

MyoHub/myo_sim supplies anatomical joint axes, ranges, inertias and contact geometry.
License: Apache 2.0; included below. This adaptation replaces muscle actuation
with torque-limited joint-position servos, removes the torso, adds a forearm
translation carriage, contact tasks, controller, telemetry and skin rendering.
No hand-object welds are used. The turning guide is an idealized hinge with
friction load, not a thread model. The skin is visual, not deformable tissue.
These tests do not yet replace the hands in the published full-stool run.
