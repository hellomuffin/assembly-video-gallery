"""Bounded MyoHand joints, torque-limited servos and physical skin contacts.
Uses MyoHub/myo_sim (Apache-2.0); no muscle actuation is claimed.
"""
from pathlib import Path
import xml.etree.ElementTree as E,copy,re
import mujoco,numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'outputs/hand_v3'
def build(mode="lift"):
 src=E.parse(OUT/'anatomical_source.xml').getroot()
 root=E.Element('mujoco',model='Anatomical hand contact bench')
 for tag in ['compiler','default','asset']:root.append(copy.deepcopy(src.find(tag)))
 # MjSpec serialization includes an anonymous nested default; flatten it.
 for parent in list(root.iter('default')):
  for child in list(parent):
   if child.tag=='default' and not child.get('class'):
    parent.remove(child)
    for node in list(child):parent.append(node)
 E.SubElement(root,'option',timestep='.002',integrator='implicitfast',iterations='100',gravity='0 0 -9.81')
 visual=E.SubElement(root,'visual');E.SubElement(visual,'global',offwidth='1280',offheight='720')
 world=E.SubElement(root,'worldbody');E.SubElement(world,'light',pos='0 -.3 1',diffuse='.8 .8 .8')
 E.SubElement(world,'geom',name='bench',type='plane',size='1 1 .01',pos='0 0 -.15',rgba='.17 .22 .24 1',contype='2',conaffinity='3')
 mount=E.SubElement(world,'body',name='forearm_mount',pos='0 0 0')
 E.SubElement(mount,'joint',name='lift',type='slide',axis='0 0 1',range='0 .16',limited='true',damping='20',armature='.1')
 E.SubElement(mount,'inertial',mass='1',pos='0 0 0',diaginertia='.01 .01 .01')
 hand=copy.deepcopy(src.find('.//body[@name="radius_r"]'));hand.set('pos','0 0 0');hand.set('childclass','myoarm')
 for parent in hand.iter():
  for x in list(parent):
   if x.tag in ('camera','site') or (x.tag=='geom' and 'coll' not in x.get('name','')):parent.remove(x)
 for g in hand.iter('geom'):
  g.set('rgba','.63 .36 .23 1');g.set('group','0');g.set('material','');g.set('contype','1');g.set('conaffinity','2');g.set('friction','1.1 .015 .001');g.set('solref','.008 1');g.set('solimp','.95 .99 .001');g.set('margin','0')
  g.attrib.pop('material',None)
 # Keep anatomical joint limits; tune finite-strength servo dynamics.
 for j in hand.iter('joint'):j.set('damping','.04' if 'pro_sup' not in j.get('name','') else '.15');j.set('armature','.0001');j.set('solreflimit','.004 1');j.set('solimplimit','.99 .999 .001')
 mount.append(hand)
 if True:
  for name,axis in [('base_x','1 0 0'),('base_y','0 1 0')]:
   E.SubElement(mount,'joint',name=name,type='slide',axis=axis,range='-.25 .25',limited='true',damping='15',armature='.1')
 tool=E.SubElement(world,'body',name='tool',pos='.022 -.31 -.005')
 E.SubElement(tool,'freejoint',name='tool_free') if mode=='lift' else E.SubElement(tool,'joint',name='tool_turn',type='hinge',axis='0 1 0',damping='.006',frictionloss='.20',armature='.0001')
 E.SubElement(tool,'geom',name='handle',type='cylinder',size='.017 .075',quat='.70710678 0 .70710678 0',mass='.12',rgba='.04 .17 .19 1',contype='2',conaffinity='3',friction='1.1 .015 .001')
 if mode=='turn':
  handle=tool.find("geom[@name='handle']");handle.set('type','ellipsoid');handle.set('size','.027 .045 .027');handle.attrib.pop('quat',None)
 E.SubElement(tool,'geom',name='shaft',type='capsule',fromto='0 -.017 0 0 -.13 0',size='.003',mass='.025',rgba='.65 .68 .7 1',contype='2',conaffinity='3')
 for x in ([-.043,.087] if mode=='lift' else []):
  E.SubElement(world,'geom',name='rest_'+str(x),type='box',size='.006 .025 .064',pos=f'{x} -.31 -.086',rgba='.35 .25 .13 1',contype='2',conaffinity='3')
 if mode=='turn':
  for x,z,sx,sz in [(-.031,-.005,.047,.07),(.075,-.005,.047,.07),(.022,.038,.006,.031),(.022,-.048,.006,.031)]:
   E.SubElement(world,'geom',name=f'bearing_{x}_{z}',type='box',size=f'{sx} .012 {sz}',pos=f'{x} -.437 {z}',rgba='.4 .3 .15 1',contype='2',conaffinity='3')
 if mode=='turn':E.SubElement(world,'geom',name='bearing_base',type='box',size='.10 .024 .035',pos='.022 -.437 -.115',rgba='.4 .3 .15 1',contype='2',conaffinity='3')
 # Explicit inter-digit collisions; adjacent anatomical segments overlap by design.
 contact=E.SubElement(root,'contact');digits=[]
 for g in hand.iter('geom'):
  n=g.get('name','');match=re.search(r'ph([2-5])|^([2-5])',n);digit='thumb' if 'thumb' in n else next((v for v in match.groups() if v),None) if match else None
  if digit and ('ph' in n or 'thumb' in n):digits.append((digit,n))
 for i,(a,ga) in enumerate(digits):
  for b,gb in digits[i+1:]:
   if a!=b:E.SubElement(contact,'pair',geom1=ga,geom2=gb,friction='1 .01 .001 .001 .001',solref='.004 1',solimp='.99 .999 .001')
 for g in world.iter('geom'):
  if g.get('contype')=='2':g.set('solref','.004 1');g.set('solimp','.99 .999 .001')
 actuator=E.SubElement(root,'actuator')
 E.SubElement(actuator,'position',name='lift_servo',joint='lift',kp='2000',kv='90',ctrlrange='0 .16',forcerange='-80 80')
 if True:
  for name in ['base_x','base_y']:E.SubElement(actuator,'position',name=name+'_servo',joint=name,kp='2500',kv='90',ctrlrange='-.25 .25',forcerange='-80 80')
 for j in hand.iter('joint'):
  name=j.get('name');lim='2' if name in ['pro_sup_r','flexion_r','deviation_r'] else '.45'
  E.SubElement(actuator,'position',name=name+'_servo',joint=name,kp='5',kv='.08',ctrlrange=j.get('range'),forcerange=f'-{lim} {lim}')
 # The retained dynamics use analytic contact shapes; discard unused bone meshes.
 for element in root.iter():element.attrib.pop('material',None)
 root.remove(root.find('asset'))
 root.find('compiler').attrib.pop('meshdir',None);root.find('compiler').attrib.pop('texturedir',None)
 p=OUT/('contact_model.xml' if mode=='lift' else 'turn_model.xml');E.indent(root);E.ElementTree(root).write(p)
 return mujoco.MjModel.from_xml_path(str(p))
if __name__=='__main__':
 m=build();d=mujoco.MjData(m);mujoco.mj_forward(m,d)
 print('nq/nv/nu',m.nq,m.nv,m.nu)
 for i in range(m.nbody):print(m.body(i).name,d.xpos[i].round(4))
 np.save(OUT/'neutral_qpos.npy',d.qpos)
