"""Continuous skin surface bound to the recorded anatomical rigid-body poses."""
import bpy,json,os,math,numpy as np
from pathlib import Path
from mathutils import Vector,Quaternion,Matrix
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'outputs/hand_v3';mode=os.environ.get('HAND_MODE','lift')
geo=json.loads((OUT/f'{mode}_geometry.json').read_text());rows=json.loads((OUT/f'{mode}_frames.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True;scene.cycles.denoiser='OPENIMAGEDENOISE';scene.cycles.denoising_use_gpu=True;scene.render.use_persistent_data=True
try:
 p=bpy.context.preferences.addons['cycles'].preferences;p.compute_device_type='CUDA';p.get_devices()
 for dev in p.devices:dev.use=dev.type=='CUDA'
 scene.cycles.device='GPU'
except:pass
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100;scene.world.color=(.18,.18,.18);scene.view_settings.view_transform='AgX'
def mat(name,color,rough=.5,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal;return m
skin=mat('Skin with fine surface texture',(.48,.245,.145),.48);bs=skin.node_tree.nodes.get('Principled BSDF');bs.inputs['Subsurface Weight'].default_value=.10;bs.inputs['Subsurface Radius'].default_value=(.012,.006,.003)
noise=skin.node_tree.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=1600;noise.inputs['Detail'].default_value=2
bump=skin.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.15;bump.inputs['Distance'].default_value=.00012;skin.node_tree.links.new(noise.outputs['Fac'],bump.inputs['Height']);skin.node_tree.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
nail=mat('Natural fingernails',(.61,.39,.30),.29);rubber=mat('Teal rubber grip',(.022,.11,.12),.65);steel=mat('Driver steel',(.45,.49,.53),.22,.85);wood=mat('Pine supports',(.46,.29,.13),.6);floor=mat('Work surface',(.13,.17,.18),.75);stripe=mat('Handle angle marker',(.94,.60,.08),.48)
def primitive(g,material):
 typ=g['type'];s=np.array(g['size']);pos=np.array(g['pos']);rot=np.array(g['mat']);parts=[]
 if typ==3: # capsule
  bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=s[0],depth=2*s[1]);parts.append(bpy.context.object)
  for z in [-s[1],s[1]]:
   bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=s[0],location=(0,0,z));parts.append(bpy.context.object)
 elif typ==5:
  bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=s[0],depth=2*s[1]);parts.append(bpy.context.object)
 elif typ==6:
  bpy.ops.mesh.primitive_cube_add(size=2);o=bpy.context.object;o.scale=s;parts.append(o)
 else:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12);o=bpy.context.object;o.scale=s if typ==4 else [s[0]]*3;parts.append(o)
 bpy.ops.object.select_all(action='DESELECT')
 for o in parts:o.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=parts[0];bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);o.location=pos;o.rotation_mode='QUATERNION';o.rotation_quaternion=Matrix(rot).to_quaternion();o.name=g['name'];o.data.materials.append(material)
 for p in o.data.polygons:p.use_smooth=True
 return o
skinparts=[];nails=[];objects=[];handgeoms=[]
for g in geo['geoms']:
 if g['name']=='bench':continue
 if 'coll' in g['name']:
  if 'coll_2' in g['name'] and g['type']==4:
   o=primitive(g,nail);nails.append((o,g));continue
  o=primitive(g,skin);skinparts.append(o);handgeoms.append(g)
 else:objects.append((primitive(g,rubber if g['name']=='handle' else steel if g['name']=='shaft' else wood),g))
# A continuous palm fills the spaces between the metacarpal collision pads.
b=geo['bodies'].index('capitate_r');p=np.array(geo['neutral_pos'][b])+np.array([-.002,-.024,-.001]);palm=dict(name='palm skin',type=4,size=[.030,.042,.014],pos=p.tolist(),mat=np.eye(3).tolist(),body=b)
skinparts.append(primitive(palm,skin));handgeoms.append(palm)
b=geo['bodies'].index('firstmc_r');p=np.array(geo['neutral_pos'][b])+np.array([.003,-.009,-.003]);pad=dict(name='thenar skin',type=4,size=[.015,.023,.014],pos=p.tolist(),mat=np.eye(3).tolist(),body=b);skinparts.append(primitive(pad,skin));handgeoms.append(pad)
bpy.ops.object.select_all(action='DESELECT')
for o in skinparts:o.select_set(True)
bpy.context.view_layer.objects.active=skinparts[0];bpy.ops.object.join();hand=skinparts[0];bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
mod=hand.modifiers.new('Continuous skin union','REMESH');mod.mode='VOXEL';mod.voxel_size=.0012;mod.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=mod.name)
mod=hand.modifiers.new('Skin smoothing','SMOOTH');mod.factor=1.3;mod.iterations=5;bpy.ops.object.modifier_apply(modifier=mod.name)
vertices=np.array([v.co[:] for v in hand.data.vertices]);N=len(vertices)
# Blend nearby anatomical bodies using signed distance to their skin capsules.
dist=[]
for g in handgeoms:
 local=(vertices-np.array(g['pos']))@np.array(g['mat']);s=np.array(g['size'])
 if g['type']==3:
  local[:,2]-=np.clip(local[:,2],-s[1],s[1]);dd=np.linalg.norm(local,axis=1)-s[0]
 else:dd=(np.linalg.norm(local/np.maximum(s,.001),axis=1)-1)*min(s)
 dist.append(dd)
D=np.array(dist).T;nearest=np.argsort(D,axis=1)[:,:3];vbody=np.array([g['body'] for g in handgeoms])[nearest];weights=np.exp(-np.take_along_axis(D,nearest,axis=1)/.002);weights/=weights.sum(axis=1)[:,None]
neutralR=np.array([np.array(Quaternion(q).to_matrix()) for q in geo['neutral_quat']]);neutralP=np.array(geo['neutral_pos']);local=np.einsum('nkji,nkj->nki',neutralR[vbody],vertices[:,None,:]-neutralP[vbody])
# Workbench with the same physical support geometry.
bpy.ops.mesh.primitive_cube_add(size=1,location=(0,-.25,-.155));o=bpy.context.object;o.scale=(1.2,.9,.01);o.data.materials.append(floor)
# A stripe on the rigid tool makes actual rotation visible.
toolbody=geo['bodies'].index('tool');bpy.ops.mesh.primitive_cube_add(size=1);marker=bpy.context.object;marker.scale=(.115,.002,.002) if mode=='lift' else (.002,.065,.002);marker.data.materials.append(stripe)
for loc,power,size in [((-.4,-.6,.7),9,.5),((.5,.1,.5),6,.4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(Vector((0,-.3,0))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.lens=48
view=os.environ.get('HAND_VIEW','close');cam.location=(.40,-.68,.39) if view=='close' else (.02,.055,.40);look=Vector((.018,-.295,.055));cam.rotation_euler=(look-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.clip_start=.005
folder=OUT/f'{mode}_{view}';folder.mkdir(exist_ok=True)
indices=list(range(len(rows)))
if os.environ.get('HAND_INDICES'):indices=[int(x) for x in os.environ['HAND_INDICES'].split(',')]
start=int(os.environ.get('HAND_START',0));stop=int(os.environ.get('HAND_STOP',len(rows)));indices=[i for i in indices if start<=i<stop]
for i in indices:
 row=rows[i];P=np.array(row['xpos']);R=np.array([np.array(Quaternion(q).to_matrix()) for q in row['xquat']]);verts=(weights[:,:,None]*(np.einsum('nkij,nkj->nki',R[vbody],local)+P[vbody])).sum(axis=1);hand.data.vertices.foreach_set('co',verts.ravel());hand.data.update()
 for o,g in objects+nails:
  b=g['body'];offset=np.array(g.get('local_pos',g['pos']));o.location=P[b]+R[b]@offset;o.rotation_quaternion=Quaternion(row['xquat'][b])@Quaternion(g.get('local_quat',[1,0,0,0]))
 marker.location=P[toolbody]+R[toolbody]@np.array([0,0,.0174 if mode=='lift' else .0274]);marker.rotation_mode='QUATERNION';marker.rotation_quaternion=Quaternion(row['xquat'][toolbody])
 scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=92;scene.render.filepath=str(folder/f'{i:05}.jpg');bpy.ops.render.render(write_still=True)
 print('FRAME',mode,view,i,flush=True)
