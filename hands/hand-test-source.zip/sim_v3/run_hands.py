"""Record actual servo commands and contact dynamics; never weld hand to object."""
from hand_model import *
import json,sys
mode=sys.argv[1] if len(sys.argv)>1 else 'lift'
m=build(mode);d=mujoco.MjData(m);grasp=np.load(OUT/('turn_grasp.npy' if mode=='turn' and (OUT/'turn_grasp.npy').exists() else 'grasp.npy'));names=['lift']+[j.get('name') for j in E.parse(OUT/'anatomical_source.xml').getroot().findall('.//worldbody//joint')]
hand_names=names[1:];qgrasp=dict(zip(names,grasp));aidx={m.actuator(i).name.replace('_servo',''):i for i in range(m.nu)}
qidx={m.joint(i).name:int(m.jnt_qposadr[i]) for i in range(m.njnt)}
qopen={n:0. for n in hand_names};qopen.update(dict(zip(hand_names[3:7],[.6,.7,.4,.2])))
for i,x in zip(range(2,6),[.15,.05,-.05,-.15]):qopen[f'mcp{i}_abduction_r']=x
for n,x in qopen.items():d.qpos[qidx[n]]=x
bid=m.body('tool').id;frames=[];commands=[];maxpen=0;pen_case=None;maxviol=0;toolcontacts=[];torques=[]
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def targets(t):
 q={n:0. for n in aidx};q['lift']=0
 if mode=='lift':
  close=min(t/1.2,1)*(1-smooth((t-10)/1.5))
  q['lift']=.10*min(max(t-1.5,0)/1.5,1)*(1-smooth((t-8)/2))
  q['base_y']=.20*smooth((t-11.5)/1.5);q['lift']+=.07*smooth((t-11.5)/1.5)
  stage='Close fingers' if t<1.2 else 'Establish contact' if t<1.5 else 'Lift through friction' if t<3 else 'Hold under gravity' if t<8 else 'Lower to supports' if t<10 else 'Open fingers' if t<11.5 else 'Withdraw and release'
 else:
  if t<2.5:close=smooth((t-.4)/1.5);angle=0;stage='Wrap handle'
  else:
   cyc=(t-2.5)%6;stroke=int((t-2.5)//6)
   if cyc<1.6:angle=.50*smooth(cyc/1.6);close=1;stage=f'Turn {stroke+1}: load-bearing grip'
   elif cyc<2.4:angle=.50;close=1-smooth((cyc-1.6)/.8);stage='Release fingers'
   elif cyc<3.6:angle=.50*(1-smooth((cyc-2.4)/1.2));close=0;stage='Reset wrist with fingers open'
   else:angle=0;close=smooth((cyc-3.6)/1.1);stage='Regrasp handle'
  q['pro_sup_r']=angle
  # Move the forearm carriage to rotate the palm about the fixed handle.
  from scipy.spatial.transform import Rotation
  pivot=np.zeros(3);center=np.array([.022,-.31,-.005]);delta=(center-pivot)-Rotation.from_rotvec(np.array([-.017161,.992666,-.119668])*angle).apply(center-pivot)
  q['base_x']=delta[0];q['base_y']=delta[1];q['lift']=delta[2]
  if t>=2.5:
   clearance=.035*(smooth((cyc-1.6)/.8) if cyc<2.4 else 1 if cyc<3.6 else 1-smooth((cyc-3.6)/.7))
   q['lift']+=clearance
   if cyc>=3.6:close=smooth((cyc-4.2)/.7)
 for n in hand_names:
  if n!='pro_sup_r':
   c=close
   if mode=='turn':c=smooth((close-.35)/.65) if n in hand_names[3:7] else smooth(close/ .65)
   q[n]=qopen[n]+(qgrasp[n]-qopen[n])*c
 return q,stage
# Let the open anatomical hand settle before the recorded episode.
for n,x in qopen.items():d.ctrl[aidx[n]]=x
for _ in range(500):mujoco.mj_step(m,d)
d.time=0
T=16 if mode=='lift' else 26.5
for k in range(round(T/.002)):
 t=k*.002
 if k%10==0:
  target,stage=targets(t)
  for n,x in target.items():d.ctrl[aidx[n]]=x
 mujoco.mj_step(m,d)
 for c in d.contact:
  if -c.dist>maxpen:maxpen=-c.dist;pen_case=dict(t=t,stage=stage,geoms=[m.geom(c.geom1).name,m.geom(c.geom2).name])
 for j in range(m.njnt):
  if m.jnt_limited[j]:maxviol=max(maxviol,float(max(m.jnt_range[j,0]-d.qpos[m.jnt_qposadr[j]],d.qpos[m.jnt_qposadr[j]]-m.jnt_range[j,1],0)))
 if True:
  force=0;handcontact=0
  for ci,c in enumerate(d.contact):
   bodies=[m.geom_bodyid[c.geom1],m.geom_bodyid[c.geom2]]
   if bid in bodies and any(b not in [0,bid] for b in bodies):
    f=np.zeros(6);mujoco.mj_contactForce(m,d,ci,f);force+=f[0];handcontact+=1
  commands.append(dict(t=round(d.time,4),stage=stage,target=d.ctrl.tolist(),qpos=d.qpos.tolist(),qvel=d.qvel.tolist(),q=[float(d.qpos[qidx[n]]) for n in aidx],torque=d.actuator_force.tolist(),contacts=handcontact,normal_force_N=float(force),tool_position=d.xpos[bid].tolist(),tool_angle=float(d.qpos[qidx['tool_turn']]) if mode=='turn' else None))
 if k%20==0:frames.append(dict(t=round(d.time,4),stage=stage,xpos=d.xpos.tolist(),xquat=d.xquat.tolist(),qpos=d.qpos.tolist()))
meta=dict(mode=mode,joints=list(aidx),n_controls=m.nu,physics_hz=500,control_hz=50,video_hz=25,anatomical_joint_count=23,hand_object_welds=0,actuation='Joint-position servos with finite torque; no muscle controller',forearm='Prescribed translation carriage; not a balanced full human',joint_ranges={n:m.joint(n).range.tolist() for n in aidx},force_limits=m.actuator_forcerange.tolist(),tool_load_Nm=.20 if mode=='turn' else None,max_penetration_m=maxpen,worst_penetration=pen_case,max_joint_limit_violation=maxviol,frames=len(frames),tool_start=commands[0]['tool_position'],tool_end=commands[-1]['tool_position'])
if mode=='lift':
 hold=[r for r in commands if 5<r['t']<8];meta['hold_min_height_m']=min(r['tool_position'][2] for r in hold);meta['hold_min_contacts']=min(r['contacts'] for r in hold);meta['final_hand_tool_contacts']=commands[-1]['contacts']
else:meta['final_tool_turn_deg']=float(np.degrees(commands[-1]['tool_angle']))
(OUT/f'{mode}_frames.json').write_text(json.dumps(frames));(OUT/f'{mode}_physics_steps.json').write_text(json.dumps(commands));(OUT/f'{mode}_commands.json').write_text(json.dumps(commands[::10]));(OUT/f'{mode}_evidence.json').write_text(json.dumps(meta,indent=2))
mujoco.mj_resetData(m,d);mujoco.mj_forward(m,d)
geoms=[]
for i in range(m.ngeom):geoms.append(dict(name=m.geom(i).name,body=int(m.geom_bodyid[i]),type=int(m.geom_type[i]),size=m.geom_size[i].tolist(),pos=d.geom_xpos[i].tolist(),mat=d.geom_xmat[i].reshape(3,3).tolist(),local_pos=m.geom_pos[i].tolist(),local_quat=m.geom_quat[i].tolist()))
(OUT/f'{mode}_geometry.json').write_text(json.dumps(dict(geoms=geoms,bodies=[m.body(i).name for i in range(m.nbody)],neutral_pos=d.xpos.tolist(),neutral_quat=d.xquat.tolist())))
print(json.dumps(meta,indent=2))
