import sys,time
sys.argv=['run_hands.py','turn']
from pathlib import Path
source=(Path(__file__).resolve().parent/'run_hands.py').read_text().split('# Let the open anatomical hand settle')[0]
exec(compile(source,'run_hands.py','exec'))
from scipy.optimize import differential_evolution
best=-1e9;count=0;start=time.monotonic()
def run(x):
 global best,count
 mujoco.mj_resetData(m,d)
 q=np.zeros(24);q[4:8]=x[3:7]
 for f in range(4):q[8+4*f:12+4*f]=[x[0],0,x[1],x[2]]
 qgrasp.update(dict(zip(names,q)))
 for n,v in qopen.items():d.qpos[qidx[n]]=v;d.ctrl[aidx[n]]=v
 for _ in range(250):mujoco.mj_step(m,d)
 before=peak=end=0.;minclose=99;maxpen=0;thumb_touch=0;closed_samples=0
 for k in range(4250):
  t=k*.002
  if k%10==0:
   target,stage=targets(t)
   for n,v in target.items():d.ctrl[aidx[n]]=v
  mujoco.mj_step(m,d)
  a=d.qpos[qidx['tool_turn']]
  if 1400<k<1950:
   closed_samples+=1
   thumb_touch+=any(('thumb' in m.geom(c.geom1).name and m.geom(c.geom2).name=='handle') or ('thumb' in m.geom(c.geom2).name and m.geom(c.geom1).name=='handle') for c in d.contact)
  if k==1250:before=a
  if k==2050:peak=a
  if k>3300:maxpen=max(maxpen,max([0]+[-c.dist for c in d.contact]))
 end=a;net=end-before;back=max(0,peak-end);score=net-.4*back-50*max(0,maxpen-.003)+.5*(thumb_touch/max(closed_samples,1))
 count+=1
 if score>best:
  best=score;np.save(OUT/'turn_grasp.npy',q);print(count,'score',round(score,3),'netdeg',round(np.degrees(net),1),'backdeg',round(np.degrees(back),1),'thumb',round(thumb_touch/max(closed_samples,1),2),'seconds',round(time.monotonic()-start),flush=True)
 return -score
bounds=[(.65,1.45),(.35,1.5),(.2,1.45),(-.2,.55),(-.48,.35),(-.77,-.1),(-1.25,-.3)]
r=differential_evolution(run,bounds,popsize=4,maxiter=5,polish=False,seed=25);print(r.x,r.fun)
