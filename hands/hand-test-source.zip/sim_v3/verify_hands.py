"""Independent checks on all 500 Hz samples and controller replay under perturbations."""
from pathlib import Path
import json,numpy as np,mujoco
O=Path(__file__).resolve().parent.parent/'outputs/hand_v3';report={}
for mode in ['lift','turn']:
 rows=json.loads((O/f'{mode}_physics_steps.json').read_text());meta=json.loads((O/f'{mode}_evidence.json').read_text());m=mujoco.MjModel.from_xml_path(str(O/('contact_model.xml' if mode=='lift' else 'turn_model.xml')))
 t=np.array([r['t'] for r in rows]);U=np.array([r['target'] for r in rows]);F=np.array([r['torque'] for r in rows]);Q=np.array([r['q'] for r in rows]);lim=np.array([m.joint(n).range for n in meta['joints']]);violation=np.maximum(np.maximum(lim[:,0]-Q,Q-lim[:,1]),0);angular=float(violation[:,3:].max());linear=float(violation[:,:3].max())
 checks=dict(continuous_500_hz=bool(np.allclose(np.diff(t),.002)),commands_held_between_50_hz_updates=bool(all(np.allclose(U[i:i+10],U[i]) for i in range(0,len(U),10))),finite_states=bool(np.isfinite(Q).all()),no_welds=m.neq==0,actuator_force_caps=bool(np.all(F>=m.actuator_forcerange[:,0]-1e-8) and np.all(F<=m.actuator_forcerange[:,1]+1e-8)),joint_targets_in_bounds=bool(np.all(U>=lim[:,0]-1e-8) and np.all(U<=lim[:,1]+1e-8)),angular_soft_limit_error_under_one_degree=angular<np.pi/180)
 result=dict(checks=checks,max_angular_limit_excursion_deg=float(np.degrees(angular)),max_carriage_limit_excursion_m=linear,max_contact_penetration_mm=meta['max_penetration_m']*1000,physics_steps=len(rows))
 if mode=='lift':
  hold=[r for r in rows if 5<=r['t']<=8];checks.update(hold_above_8cm=all(r['tool_position'][2]-meta['tool_start'][2]>.08 for r in hold),continuous_hold_contact=all(r['contacts']>0 for r in hold),final_release=rows[-1]['contacts']==0)
 else:
  strokes=[]
  for k in range(4):
   start=2.5+6*k;at=lambda x:min(rows,key=lambda r:abs(r['t']-x))['tool_angle'];reset=[r for r in rows if start+2.5<r['t']<start+3.5]
   strokes.append(dict(net_turn_deg=float(np.degrees(at(start+5.998)-at(start))),release_regrasp_loss_deg=float(np.degrees(at(start+1.6)-at(start+5.998))),reset_max_contacts=max(r['contacts'] for r in reset),reset_tool_drift_deg=float(np.degrees(max(r['tool_angle'] for r in reset)-min(r['tool_angle'] for r in reset)))))
  result['strokes']=strokes;checks.update(four_positive_turns=all(s['net_turn_deg']>20 for s in strokes),contact_free_resets=all(s['reset_max_contacts']==0 for s in strokes),reset_drift_under_one_degree=all(s['reset_tool_drift_deg']<1 for s in strokes))
 result['passed']=all(checks.values());report[mode]=result
 # Replay the recorded controller commands; do not retune for each perturbation.
 sensitivity=[]
 for mass_scale,friction_scale in [(1.,1.),(.8,1.),(1.2,1.),(1.,.8),(1.,1.2)]:
  mm=mujoco.MjModel.from_xml_path(str(O/('contact_model.xml' if mode=='lift' else 'turn_model.xml')));dd=mujoco.MjData(mm);b=mm.body('tool').id;mm.body_mass[b]*=mass_scale;mm.body_inertia[b]*=mass_scale;mm.geom_friction[:,0]*=friction_scale;mujoco.mj_setConst(mm,dd);dd.qpos[:]=rows[0]['qpos'];dd.qvel[:]=rows[0]['qvel'];mujoco.mj_forward(mm,dd);minimum=1e9
  for i,r in enumerate(rows[1:],1):
   dd.ctrl[:]=r['target'];mujoco.mj_step(mm,dd)
   if mode=='lift' and 5<=r['t']<=8:minimum=min(minimum,dd.xpos[b,2]-meta['tool_start'][2])
  measure=float(minimum) if mode=='lift' else float(np.degrees(dd.qpos[mm.jnt_qposadr[mm.joint('tool_turn').id]]))
  sensitivity.append(dict(mass_scale=mass_scale,friction_scale=friction_scale,hold_clearance_m=measure if mode=='lift' else None,final_tool_angle_deg=measure if mode=='turn' else None,passed=measure>.08 if mode=='lift' else measure>80))
 result['limited_sensitivity_checks']=sensitivity
report['passed']=all(report[m]['passed'] for m in ['lift','turn']);report['scope']='Nominal hand tests and small parameter perturbations only. No full-body or sim-to-real validation.'
(O/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
