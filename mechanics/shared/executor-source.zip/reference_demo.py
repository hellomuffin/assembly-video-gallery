"""Explicit reference task policy using known assembly poses; not a user model.
The environment itself does not select correct parts or repair wrong actions.
"""
import json,time,hashlib
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
from engine import AssemblyWorld,ActionRejected


def place(w,part,goal,rotation):
    p,r=w.pose(part);hp,hr=w.pose('gripper')
    ceiling=max(.9,max(w.pose(n)[0][2]+max(w.parts[n]['size'])/2 for n in w.parts)+.25)
    w.move([hp[0],hp[1],ceiling]);w.move([p[0],p[1],ceiling],r);w.move(p,r);w.grasp(part)
    # Preserve the measured grasp offset instead of snapping the object.
    hp,hr=w.pose('gripper');p,r=w.pose(part);local=hr.inv().apply(p-hp);rel=hr.inv()*r
    desired=rotation*rel.inv();root_goal=np.asarray(goal)-desired.apply(local)
    w.move([hp[0],hp[1],ceiling],hr);w.move([root_goal[0],root_goal[1],ceiling],desired)
    w.move(root_goal,desired);w.advance(.3)


def run(asset,out,seed):
    start=time.monotonic();w=AssemblyWorld(asset,seed);assembled={w.spec['base']};remaining=list(w.connectors)
    while remaining:
        eligible=[key for key in remaining if w.connectors[key]['a'] in assembled]
        if not eligible:raise RuntimeError('Reference assembly description has an unresolved dependency')
        key=eligible[0];c=w.connectors[key]
        if c['b'] not in assembled:
            p,r=w.pose(c['a']);offset=np.asarray(w.parts[c['b']]['assembly_position'])-w.parts[c['a']]['assembly_position']
            place(w,c['b'],p+r.apply(offset),r)
        if w.held==c['b']:w.align(key)
        print('ALIGN',key,w.mating_error(key),w.pose(c['b'])[0].tolist(),flush=True)
        pos,axis=w.tool_site(key)
        while w.engagement[key]<c['required_turns']:
            w.turn(key,min(.25,c['required_turns']-w.engagement[key]),c['minimum_torque']*1.2,pos,axis)
        w.release();w.advance(.4);assembled.add(c['b']);remaining.remove(key)
    w.move([0,-1,1.2]);w.advance(2.)
    errors={k:float(w.mating_error(k)[0]) for k in w.connectors}
    checks=dict(all_connections_fastened=len(w.fastened)==len(w.connectors),hands_released=w.held is None,
                alignment_under_6mm=max(errors.values())<.006,gravity_enabled=np.allclose(w.m.opt.gravity,[0,0,-9.81]),
                no_applied_furniture_forces=all(np.all(w.d.xfrc_applied[w.ids[n]]==0) for n in w.parts),
                no_furniture_gravity_compensation=all(w.m.body_gravcomp[w.ids[n]]==0 for n in w.parts))
    w.save(out);result=dict(engine_sha256=hashlib.sha256((Path(__file__).parent/'engine.py').read_bytes()).hexdigest(),asset_sha256=hashlib.sha256(Path(asset).read_bytes()).hexdigest(),passed=bool(all(checks.values())),checks={k:bool(v) for k,v in checks.items()},asset=w.spec['id'],seed=seed,seconds=float(w.d.time),wall_seconds=time.monotonic()-start,alignment_m=errors,scope='Reference policy in assembly orientation on the floor. Simplified assisted gripper and abstract tool turns; no anatomical human, detailed screw contact, tool-access collision, or final upright flipping claim.')
    (Path(out)/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
    assert result['passed']
    return w

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('asset');p.add_argument('out');p.add_argument('--seed',type=int,default=0);a=p.parse_args();run(a.asset,a.out,a.seed)
