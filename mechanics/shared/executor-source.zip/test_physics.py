"""Behavior tests: contacts and action history, not visual appearance."""
import json
from pathlib import Path
import numpy as np
from engine import AssemblyWorld,ActionRejected
from reference_demo import place,run
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'outputs/shared_v1'

def rejected(fn):
 try:fn()
 except ActionRejected:return True
 raise AssertionError('Invalid action was accepted')

results={}
w=AssemblyWorld(ROOT/'assets/cantilever_test.json');pos,axis=w.tool_site('mount')
results['misaligned_components_rejected']=rejected(lambda:w.turn('mount',.25,.4,pos,axis))
assert not w.fastened
p,r=w.pose('post');offset=np.asarray(w.parts['beam']['assembly_position'])-w.parts['post']['assembly_position'];place(w,'beam',p+r.apply(offset),r)
w.align('mount')
print('CANTILEVER ALIGN',w.mating_error('mount'),w.pose('beam')[0],flush=True)
pos,axis=w.tool_site('mount')
results['wrong_tool_location_rejected']=rejected(lambda:w.turn('mount',.25,.4,pos+[.1,0,0],axis))
results['wrong_tool_axis_rejected']=rejected(lambda:w.turn('mount',.25,.4,pos,-axis))
results['nonfinite_turn_rejected']=rejected(lambda:w.turn('mount',float('nan'),.4,pos,axis))
results['insufficient_torque_rejected']=rejected(lambda:w.turn('mount',.25,.01,pos,axis))
for _ in range(4):w.turn('mount',.25,.4,pos,axis)
assert w.engagement['mount']==1 and not w.fastened and not w.d.eq_active[w.m.equality('joint_mount').id]
z=w.pose('beam')[0][2];w.release();w.advance(1.2);drop=float(z-w.pose('beam')[0][2]);assert drop>.2,drop
results['partial_fastening_released_beam_drop_m']=drop;w.save(OUT/'negative_partial')
w=run(ROOT/'assets/cantilever_test.json',OUT/'positive_cantilever',0)
assert w.mating_error('mount')[0]<.006
pos,axis=w.tool_site('mount');w.turn('mount',-.25,.4,pos,axis)
assert 'mount' not in w.fastened
z=w.pose('beam')[0][2];w.advance(1.2);drop=float(z-w.pose('beam')[0][2]);assert drop>.2
results['loosening_released_beam_drop_m']=drop;w.save(OUT/'negative_loosened')
for asset in ['table','shelf']:
 for seed in [1,7]:
  demo=run(ROOT/'assets'/f'{asset}.json',OUT/f'{asset}_seed{seed}',seed)
  results[f'{asset}_seed{seed}']=len(demo.fastened)
report=dict(passed=True,checks=results,scope='Two proxy furniture descriptions with randomized non-overlapping initial positions and yaw, a cantilever support test, and incorrect tool/fastening actions. Does not establish arbitrary-CAD generalization or human/tool collision realism.')
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
