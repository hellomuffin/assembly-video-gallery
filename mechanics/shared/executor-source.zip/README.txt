Reusable assembly mechanics prototype
====================================

Run with the project's .venv-assembly Python:
  python assembly/sim_shared/test_physics.py
  MUJOCO_GL=egl python assembly/sim_shared/render_proofs.py

engine.py contains the furniture-independent action executor. JSON assets define
parts, dimensions, masses, assembly-frame positions, connector endpoints, tool
sites/axes, and tightening thresholds. No furniture names or dimensions are
special-cased in the executor. New connector kinds require explicit behavior;
unsupported kinds are rejected.

reference_demo.py is an EXPLICIT reference task policy with access to correct
assembly poses. It is not an assistant, user simulator, or evaluation policy.
It chooses the correct sequence for demonstration. The engine only executes
the caller's requested actions; it does not choose the correct connector.

Physical model:
- Free rigid components with gravity and contact enabled.
- A finite-force, finite-torque virtual gripper; assisted weld while held.
- No component pose assignments after initialization in the simulation.
- Screw GROUPS approximated by fixed joints after guarded abstract turns.
- Tool site, axis, mating alignment, turn count and torque gates.
- Releasing removes the grasp. Loosening removes the fastened joint when
  engagement drops below the tightening threshold.
- Assembly is completed upside down (table) or on its back (shelf), on the floor.

Important limitations:
- Proxy box geometry, not imported production furniture CAD.
- The gripper marker is noncolliding. There are no anatomical hands, arms,
  finite human reach, or body balance in this core yet.
- Tool turns and torque are abstract actions, not physical screwdriver contact.
- Torque gates are illustrative, not calibrated connector strengths. Fastened
  joints do not yet break under overload. Part-to-part collisions stay enabled.
- The reference transport path uses a shared overhead route, not a general
  obstacle-avoiding planner. Blocked alignment raises an error.
- The cantilever test has a declared 3 mm connector clearance bridged by its
  simplified fastener group. It does not validate detailed wood joint mechanics.
- Tests establish these behaviors on two furniture descriptions, not arbitrary
  CAD generalization, realistic human manipulation, or zero sim-to-real gap.

render_proofs.py only replays recorded poses. Its pose assignments are for
visualization, not simulation. Green indicates the component held by the
virtual gripper. Video labels identify the approximations and playback speed.
