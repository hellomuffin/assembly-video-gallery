"""Independently inspect recorded active constraints and sampled collision geometry."""
import hashlib,json
from pathlib import Path
import mujoco,numpy as np
root=Path(__file__).resolve().parent.parent/'outputs/shared_v1';reports=[]
for name in ['table_seed1','table_seed7','shelf_seed1','shelf_seed7','negative_partial','positive_cantilever','negative_loosened']:
 source=root/name;blob=(source/'trajectory.json').read_bytes();rows=json.loads(blob)
 m=mujoco.MjModel.from_binary_path(str(source/'model.mjb'));d=mujoco.MjData(m);worst=0.;violations=[]
 for i,row in enumerate(rows):
  expected={m.equality('joint_'+c).id for c in row['fastened']}
  if row['held']:expected.add(m.equality('grasp_'+row['held']).id)
  if set(row['active_constraints'])!=expected:violations.append(i)
  for part,pose in {**row['parts'],'gripper':row['gripper']}.items():
   qa=m.jnt_qposadr[m.body_jntadr[m.body(part).id]];d.qpos[qa:qa+7]=[*pose[0],*pose[1]]
  d.eq_active[:]=False;d.eq_active[row['active_constraints']]=True;mujoco.mj_forward(m,d)
  worst=max(worst,max((-c.dist for c in d.contact),default=0.))
 reports.append(dict(source=name,frames=len(rows),constraint_mismatches=violations,maximum_sampled_penetration_m=float(worst),trajectory_sha256=hashlib.sha256(blob).hexdigest()))
 assert not violations
report=dict(passed=all(not r['constraint_mismatches'] and r['maximum_sampled_penetration_m']<.003 for r in reports),recordings=reports,scope='Checks recorded 25 Hz poses, actual active-constraint IDs, and sampled geometric penetration. Not a continuous collision or force audit.')
(root/'recording-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
