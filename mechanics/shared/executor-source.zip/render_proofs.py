"""Render recorded proxy physics; annotations identify abstract grasp/joint state."""
import os
os.environ.setdefault('MUJOCO_GL','egl')
import hashlib,json,subprocess
from pathlib import Path
import numpy as np,mujoco
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent/'outputs/shared_v1';OUT=BASE/'media';OUT.mkdir(exist_ok=True)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
items=[]
for folder,name,title,stride,last in [('table_seed1','table','Table / assembled upside down',4,None),('shelf_seed1','shelf','Shelf / assembled on its back',4,None),('negative_partial','unfastened','Partial tightening / release',1,75),('positive_cantilever','fastened','Tightened connection / release',1,75)]:
 source=BASE/folder;blob=(source/'trajectory.json').read_bytes();rows=json.loads(blob)
 selected=list(range(max(0,len(rows)-last) if last else 0,len(rows),stride))
 m=mujoco.MjModel.from_binary_path(str(source/'model.mjb'));d=mujoco.MjData(m)
 camera=mujoco.MjvCamera();camera.lookat[:]=[0,-.4,.25] if last is None else [.2,0,.3];camera.distance=2.8 if last is None else 1.65;camera.azimuth=135;camera.elevation=-33
 m.vis.headlight.ambient[:]=[.35,.35,.35];m.vis.headlight.diffuse[:]=[.65,.65,.65]
 m.light_ambient[:]=[.2,.2,.2];m.light_diffuse[:]=[.8,.8,.8]
 m.vis.global_.offwidth=800;m.vis.global_.offheight=600
 renderer=mujoco.Renderer(m,height=600,width=800)
 target=OUT/(name+'.mp4');encode=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','800x600','-r','25','-i','-','-an','-c:v','libx264','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],stdin=subprocess.PIPE)
 for index in selected:
  row=rows[index]
  for part,pose in {**row['parts'],'gripper':row['gripper']}.items():
   body=m.body(part).id;qa=m.jnt_qposadr[m.body_jntadr[body]];d.qpos[qa:qa+7]=[*pose[0],*pose[1]]
  for part in row['parts']:
   g=m.geom('shape_'+part).id;m.geom_rgba[g]=[.35,.75,.55,1] if part==row['held'] else [.76,.59,.37,1]
  mujoco.mj_forward(m,d);renderer.update_scene(d,camera=camera)
  im=Image.fromarray(renderer.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,800,79),fill='#101513');draw.text((18,10),title,font=font,fill='white');draw.text((18,41),f"Physics proxy | {stride}x speed | virtual grasp, abstract screw groups",font=small,fill='#c7e8a6')
  draw.rectangle((0,551,800,600),fill='#101513');draw.text((18,559),f"Held: {row['held'] or 'none'}    Fastened groups: {len(row['fastened'])}    t = {row['t']:.2f}s",font=font,fill='white')
  encode.stdin.write(np.asarray(im).tobytes())
 encode.stdin.close();assert encode.wait()==0;renderer.close();im.save(OUT/(name+'.jpg'))
 subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','null','-'],check=True)
 item=dict(file=target.name,source=folder,source_trajectory_sha256=hashlib.sha256(blob).hexdigest(),source_frame_indices=selected,frames=len(selected),duration_seconds=len(selected)/25,playback_speed=stride,sha256=hashlib.sha256(target.read_bytes()).hexdigest());items.append(item);print('RENDERED',name,len(selected),flush=True)
(OUT/'manifest.json').write_text(json.dumps(dict(videos=items,scope=__doc__),indent=2))
