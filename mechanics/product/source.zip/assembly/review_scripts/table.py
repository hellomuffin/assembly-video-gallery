import json,os,subprocess,concurrent.futures,hashlib
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
p=Path('assembly/outputs/body_rebuild/embodied/table_v205');out=Path('assembly/outputs/body_rebuild/table-verified-motion-v205');out.mkdir(parents=True,exist_ok=True)
for name in ['result.json','body-validation.json','audit.json','completion.json']:
 report=json.loads((p/name).read_text());assert report['passed'],name
assert json.loads((p/'result.json').read_text())['full_task_complete']
rows=json.loads((p/'trajectory.json').read_text());config=json.loads(Path('assembly/outputs/body_rebuild/table-review-interval-v205.json').read_text());finish=list(range(config['finish_start'],len(rows)));overview=list(range(0,len(rows),16));overview+=[] if overview[-1]==len(rows)-1 else [len(rows)-1];indices=sorted(set(finish+overview+config['preview_indices']));(out/'render-selection.json').write_text(json.dumps({'indices':indices,'finish_start':config['finish_start'],'end':len(rows)-1}));(out/'render_script.py').write_text(Path(__file__).read_text())
def render(shard):
 env={**os.environ,'PRODUCT':'table','PRODUCT_DATA':str(p),'PRODUCT_RENDER_OUTPUT':str(out),'VIEWS':'body','INDICES':','.join(map(str,indices[shard::2])),'HUMAN_SURFACE_NECK':'1','HUMAN_SURFACE_HEAD_GAZE':'1','HUMAN_SURFACE_FOREARMS':'1','CUDA_VISIBLE_DEVICES':str(shard),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'2'};env.pop('PRODUCT_VISUALS',None)
 with (out/f'render-{shard}.log').open('w') as log:subprocess.run(['/tmp/product-blender/blender','-b','-t','2','--python-exit-code','1','-P','assembly/sim_product/render.py'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('RENDERED',shard,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(render,range(2)))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
for name,chosen,speed,title in [('table-overview',overview,16,'TABLE | full task overview | 16x playback'),('table-final-handling',finish,1,'TABLE | final handling review | 1x playback')]:
 target=out/(name+'.mp4');encoder=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','25','-i','-','-an','-c:v','libx264','-threads','2','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],stdin=subprocess.PIPE)
 for i in chosen:
  im=Image.open(out/'body'/f'{i:06d}.jpg').convert('RGB');draw=ImageDraw.Draw(im);draw.rectangle((0,0,1280,38),fill='#101713');draw.text((15,6),title,font=font,fill='white');draw.rectangle((0,682,1280,720),fill='#101713');draw.text((15,689),rows[i]['stage'],font=font,fill='white');encoder.stdin.write(np.asarray(im).tobytes())
 encoder.stdin.close();assert encoder.wait()==0;subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','null','-'],check=True)
 (target.with_suffix('.json')).write_text(json.dumps({'full_source_task_accepted':True,'data':str(p),'indices':chosen,'playback_speed':speed,'trajectory_sha256':hashlib.sha256((p/'trajectory.json').read_bytes()).hexdigest(),'body_validation_sha256':hashlib.sha256((p/'body-validation.json').read_bytes()).hexdigest(),'file_sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2));print('VIDEO',target,flush=True)
