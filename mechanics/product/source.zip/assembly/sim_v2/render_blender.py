"""Cycles render of saved physics poses, not a substitute for physical fidelity."""
import bpy,json,math,random,os
from pathlib import Path
from mathutils import Vector,Quaternion
ROOT=Path(__file__).resolve().parent;OUT=Path(os.environ.get('ASSEMBLY_SCATTER_DIR',str(ROOT.parent/'outputs/bekvam_v2')));ASSET=ROOT/'assets/bekvam'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=True
try:
 prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='CUDA';prefs.get_devices()
 if any(d.type=='CUDA' for d in prefs.devices):
  for d in prefs.devices:d.use=d.type=='CUDA'
  scene.cycles.device='GPU'
except Exception:pass
scene.render.resolution_x=1600;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.world.color=(.25,.25,.25)
scene.view_settings.view_transform='AgX'
def material(name,color,roughness=.5,metallic=0,grain=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;nodes=m.node_tree.nodes;links=m.node_tree.links;bs=nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=roughness;bs.inputs['Metallic'].default_value=metallic
 if grain:
  tex=nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=8;tex.inputs['Detail'].default_value=3
  coord=nodes.new('ShaderNodeTexCoord');mapping=nodes.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(2,80,7);links.new(coord.outputs['Generated'],mapping.inputs[0]);links.new(mapping.outputs[0],tex.inputs['Vector'])
  ramp=nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(*[x*.72 for x in color],1);ramp.color_ramp.elements[1].color=(*color,1);links.new(tex.outputs['Fac'],ramp.inputs[0]);links.new(ramp.outputs[0],bs.inputs['Base Color'])
  bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.0005;links.new(tex.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs[0],bs.inputs['Normal'])
 return m
wood=material('Assumed natural timber finish - geometry source black BEKVAM',(.60,.40,.20),.38,grain=True)
steel=material('Steel',(.27,.30,.34),.24,.9);wall=material('Warm painted plaster',(.72,.74,.72),.85);trim=material('White skirting',(.82,.81,.76),.45);fabric=material('Woven teal upholstery',(.045,.11,.12),.98,grain=True);mat=material('Assembly mat',(.10,.14,.13),.95,grain=True)
def cube(name,loc,size,matl,bevel=.0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(matl)
 if bevel:
  mod=o.modifiers.new('Soft edges','BEVEL');mod.width=bevel;mod.segments=3;mod=o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
rng=random.Random(7)
for row in range(40):
 for col in range(5):
  x=-3+col*1.3+(row%2)*.65;y=-2.7+row*.14
  fm=material('Oak floor',(.40+rng.random()*.10,.25+rng.random()*.06,.12+rng.random()*.04),.42,grain=True)
  cube('Floor board',(x,y,-.022),(1.298,.138,.04),fm,.001)
cube('Back wall',(0,2.2,1.5),(7,.10,3),wall);cube('Left wall',(-2.2,0,1.5),(.10,5,3),wall)
cube('Back skirting',(0,2.13,.065),(7,.022,.13),trim,.002);cube('Left skirting',(-2.13,0,.065),(.022,5,.13),trim,.002)
cube('Assembly mat',(0,0,.005),(2.6,2.3,.01),mat,.004)
for x in [.1,1.1]:
 for y in [1.56,1.91]:cube('Sofa foot',(x,y,.09),(.05,.05,.18),wood,.003)
cube('Sofa lower',(.6,1.77,.31),(1.30,.56,.34),fabric,.055);cube('Sofa back',(.6,2.01,.68),(1.30,.19,.52),fabric,.06)
for x in [.29,.91]:cube('Seat cushion',(x,1.72,.54),(.60,.50,.15),fabric,.055)
parts=json.loads((ASSET/'parts.json').read_text())['parts'];poses=json.loads((OUT/'trajectory.json').read_text())[-1]['parts']
for part in parts:
 before=set(bpy.data.objects);bpy.ops.wm.obj_import(filepath=str(ASSET/part['visual']));new=set(bpy.data.objects)-before
 pos,quat=poses[part['name']]
 for o in new:
  o.name=part['name'];o.location=pos;o.rotation_mode='QUATERNION';o.rotation_quaternion=Quaternion((quat[3],quat[0],quat[1],quat[2]));o.data.materials.clear();o.data.materials.append(steel if part['hardware'] and not part['name'].startswith('101') else wood)
  # Source geometry retained exactly; shading normals only.
  for poly in o.data.polygons:poly.use_smooth=False
# Large area light approximates window illumination; no camera-perfect assumptions in physics.
bpy.ops.object.light_add(type='AREA',location=(1.0,-1.0,3.3));l=bpy.context.object;l.data.energy=550;l.data.shape='RECTANGLE';l.data.size=2.5;l.data.size_y=1.8
bpy.ops.object.light_add(type='AREA',location=(-1.5,1.5,2.5));l=bpy.context.object;l.data.energy=120;l.data.size=2
bpy.ops.object.camera_add(location=(2.1,-2.6,2.35));cam=bpy.context.object;direction=Vector((0,0,.07))-cam.location;cam.rotation_euler=direction.to_track_quat('-Z','Y').to_euler();cam.data.lens=43;scene.camera=cam
scene.render.filepath=str(OUT/'cycles_scatter.png');bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'scene.blend'));bpy.ops.render.render(write_still=True)
