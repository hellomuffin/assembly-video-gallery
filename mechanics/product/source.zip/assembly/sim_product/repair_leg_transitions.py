"""Propagate a safe later posture backward before a fast configuration switch."""
import numpy as np
from plan_legs import solve
from leg_clearance import boxes,interpolate_obstacles


def repair(rows,visuals,spec):
    result=list(visuals);obstacles=[boxes(r,spec) for r in rows]
    # Backward continuation stays on the later collision-free knee branch.
    # A weak reference term returns to the original comfortable posture where safe.
    q=np.array(result[-1]['leg_parameters'])
    for i in range(len(result)-2,-1,-1):
        v=result[i];feet={int(s):np.array(l[2]) for s,l in v['legs'].items()}
        original=np.array(v['leg_parameters']);target=.99*q+.01*original
        edge=(result[i+1],[interpolate_obstacles(obstacles[i],obstacles[i+1],u) for u in [.25,.5,.75]])
        new,lower,ok=solve(v,feet,obstacles[i],target,q,edge=edge)
        if not ok:
            new,lower,ok=solve(v,feet,obstacles[i],target,original,edge=edge)
        if not ok:raise RuntimeError(f'No safe backward transition pose at {i}')
        q=new;result[i]={**v,**lower}
    return result

if __name__=='__main__':
    import json,sys
    from pathlib import Path
    d=Path(__file__).resolve().parent.parent/'outputs/product_v1'/f'{sys.argv[1]}_1';rows=json.loads((d/'trajectory.json').read_text());vs=json.loads((d/'visuals-smooth.json').read_text());spec=json.loads((d/'asset.json').read_text());v=repair(rows,vs,spec);(d/'visuals-repaired.json').write_text(json.dumps(v,separators=(',',':')))
    for key in ['hip','knee','foot']:
        a=np.array([z['hip'] if key=='hip' else z['legs']['-1'][1 if key=='knee' else 2] for z in v]);d=np.linalg.norm(np.diff(a,axis=0),axis=1)/.04;i=int(d.argmax());print(key,float(d.max()),i,rows[i]['stage'])
