"""Fail-closed evidence checks, usable from Blender without scientific packages."""
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
SOURCES=['surface_constraints.py','final_motion.py','walk_route.py','contact_geometry.py','body_differentials.py','grasp_sites.py','body_geometry.py','carried_body.py','embodied_world.py','articulated_body.py','plan_body_motion.py','task_stance.py','task_hands.py','foot_contacts.py','validate_body_motion.py','prepare_visuals.py','body_proof.py','render.py','leg_clearance.py','audit_leg_surface.py','../sim_v5/human_surface.py','../sim_v5/assets/makehuman/base.obj','../sim_v5/assets/makehuman/default.mhskel','../sim_v5/assets/makehuman/default_weights.mhw','assets/hand_poses.json']

EXECUTION_SOURCES=['run_embodied.py','world.py','../sim_shared/engine.py','final_motion.py','walk_route.py','embodied_world.py','articulated_body.py','body_geometry.py','body_differentials.py','contact_geometry.py','carried_body.py','task_hands.py','task_stance.py','plan_body_motion.py','grasp_sites.py','foot_contacts.py','leg_clearance.py','../sim_v5/human_surface.py','../sim_v5/assets/makehuman/base.obj','../sim_v5/assets/makehuman/default.mhskel','../sim_v5/assets/makehuman/default_weights.mhw','assets/hand_poses.json']
EXECUTION_SOURCE_VERSIONS={1:tuple(EXECUTION_SOURCES)}
# Version 2 also uses exact visible-surface checks while planning placement.
# Historical executions retain their original, complete dependency manifest.
EXECUTION_SOURCES=[*EXECUTION_SOURCES,'validate_body_motion.py','audit_leg_surface.py']
EXECUTION_SOURCE_SCHEMA=2
EXECUTION_SOURCE_VERSIONS[EXECUTION_SOURCE_SCHEMA]=tuple(EXECUTION_SOURCES)
EXECUTION_SOURCES=[*EXECUTION_SOURCES,'body_proof.py']
EXECUTION_SOURCE_SCHEMA=3
EXECUTION_SOURCE_VERSIONS[EXECUTION_SOURCE_SCHEMA]=tuple(EXECUTION_SOURCES)
EXECUTION_SOURCE_SCHEMA=4
EXECUTION_SOURCE_VERSIONS[EXECUTION_SOURCE_SCHEMA]=tuple(EXECUTION_SOURCES)
EXECUTION_SOURCES=[*EXECUTION_SOURCES,'surface_constraints.py']
EXECUTION_SOURCE_SCHEMA=5
EXECUTION_SOURCE_VERSIONS[EXECUTION_SOURCE_SCHEMA]=tuple(EXECUTION_SOURCES)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def stamp(report,folder):
    files=['trajectory.json','asset.json','visuals.json']+(['result.json'] if report.get('recorded_execution') else [])
    report.update(full_trajectory=True,source_sha256={p:digest(H/p) for p in SOURCES},data_sha256={p:digest(folder/p) for p in files})
    (folder/'body-validation.json').write_text(json.dumps(report,indent=2))

def require_body_validation(folder):
    folder=Path(folder);path=folder/'body-validation.json'
    if not path.exists():raise RuntimeError('No accepted articulated motion: the rejected leg-only clearance proof cannot authorize rendering or publication')
    report=json.loads(path.read_text())
    if not report.get('passed') or not report.get('full_trajectory'):raise RuntimeError('Full articulated motion validation failed')
    for filename,value in report['source_sha256'].items():
        if digest(H/filename)!=value:raise RuntimeError('Stale articulated motion source: '+filename)
    if set(report['source_sha256'])!=set(SOURCES):raise RuntimeError('Incomplete articulated motion provenance')
    for filename,value in report['data_sha256'].items():
        if digest(folder/filename)!=value:raise RuntimeError('Stale articulated motion data: '+filename)
    expected={'trajectory.json','asset.json','visuals.json'}|({'result.json'} if report.get('recorded_execution') else set())
    if set(report['data_sha256'])!=expected:raise RuntimeError('Incomplete articulated motion data provenance')
    if report.get('recorded_execution'):verify_execution_sources(folder,json.loads((folder/'result.json').read_text()))
    return report


def archive_execution_sources(folder,sources):
    folder=Path(folder)
    for name,value in sources.items():
        source=(H/name).resolve()
        if digest(source)!=value:raise RuntimeError('Execution source changed during capture: '+name)
        target=folder/'execution_sources'/source.relative_to(H.parent)
        if target.exists() and digest(target)!=value:raise RuntimeError('Refusing to overwrite a different execution snapshot: '+str(target))
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())


def verify_execution_sources(folder,execution):
    folder=Path(folder)
    if (folder/'source-drift.json').exists():raise RuntimeError('Execution may have loaded edited sources; a frozen-source rerun is required')
    if execution.get('diagnostic_resume'):raise RuntimeError('A diagnostic continuation cannot authorize publication')
    expected=EXECUTION_SOURCE_VERSIONS.get(execution.get('source_schema',1))
    if expected is None or set(execution['source_sha256'])!=set(expected):raise RuntimeError('Incomplete body execution provenance')
    frozen=execution.get('source_schema',1)>=3
    if frozen and not execution.get('frozen_execution'):raise RuntimeError('Execution did not use its captured source snapshot')
    for name,value in execution['source_sha256'].items():
        current=(H/name).resolve();archived=folder/'execution_sources'/current.relative_to(H.parent)
        if frozen and not archived.exists():raise RuntimeError('Missing frozen execution source: '+name)
        source=archived if archived.exists() else current
        if digest(source)!=value:raise RuntimeError('Missing or changed execution source: '+name)
    if execution.get('continuation'):verify_continuation(folder,execution['continuation'])


CONTINUATION_FILES=['asset.json','trajectory.json','events.json','model.mjb','model.xml','integration-state.npy','controller-state.json','result.json']

def recording_digest(rows):
    return hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def capture_continuation(parent,folder,audit):
    """Preserve an audited frozen checkpoint and its exact restore inputs."""
    import shutil
    parent=Path(parent);folder=Path(folder);execution=json.loads((parent/'result.json').read_text())
    verify_execution_sources(parent,execution)
    if not execution.get('passed') or not execution.get('frozen_execution') or not audit.get('passed'):raise RuntimeError('Verified continuation requires an accepted frozen checkpoint and a passing full-prefix audit')
    target=folder/'execution_parent';target.mkdir(parents=True,exist_ok=True)
    for name in CONTINUATION_FILES:shutil.copy2(parent/name,target/name)
    for name in ['execution_sources','execution_parent']:
        if (parent/name).exists():shutil.copytree(parent/name,target/name,dirs_exist_ok=True)
    if (parent/'continuation-parent-audit.json').exists():shutil.copy2(parent/'continuation-parent-audit.json',target/'continuation-parent-audit.json')
    report=folder/'continuation-parent-audit.json';report.write_text(json.dumps(audit,indent=2))
    rows=json.loads((parent/'trajectory.json').read_text())
    return {'parent_directory':'execution_parent','prefix_frames':len(rows),'prefix_sha256':recording_digest(rows),'parent_data_sha256':{n:digest(target/n) for n in CONTINUATION_FILES},'parent_audit_sha256':digest(report)}

def verify_continuation(folder,continuation):
    if continuation.get('parent_directory')!='execution_parent':raise RuntimeError('Invalid continuation parent location')
    parent=folder/'execution_parent';hashes=continuation['parent_data_sha256']
    if set(hashes)!=set(CONTINUATION_FILES):raise RuntimeError('Incomplete checkpoint restore provenance')
    for name,value in hashes.items():
        if digest(parent/name)!=value:raise RuntimeError('Changed continuation parent: '+name)
    execution=json.loads((parent/'result.json').read_text());verify_execution_sources(parent,execution)
    if not execution.get('passed') or not execution.get('frozen_execution'):raise RuntimeError('Continuation parent was not an accepted frozen checkpoint')
    child=json.loads((folder/'result.json').read_text())
    for name in ['world.py','../sim_shared/engine.py']:
        if execution['source_sha256'][name]!=child['source_sha256'][name]:raise RuntimeError('Continuation changed the furniture physics backend')
    if json.loads((parent/'asset.json').read_text())!=json.loads((folder/'asset.json').read_text()):raise RuntimeError('Continuation changed the furniture or declared grasps')
    report=folder/'continuation-parent-audit.json'
    if digest(report)!=continuation['parent_audit_sha256'] or not json.loads(report.read_text()).get('passed'):raise RuntimeError('Continuation prefix audit changed or failed')
    rows=json.loads((parent/'trajectory.json').read_text());current=json.loads((folder/'trajectory.json').read_text());count=continuation['prefix_frames']
    if count!=len(rows) or continuation['prefix_sha256']!=recording_digest(rows) or recording_digest(current[:count])!=recording_digest(rows):raise RuntimeError('Continuation changed its recorded prefix')
    events=json.loads((parent/'events.json').read_text());current_events=json.loads((folder/'events.json').read_text())
    if current_events[:len(events)]!=events:raise RuntimeError('Continuation changed prior physics events')
