"""Geometric leg/recorded-part clearance, independent of the physics solver."""
import numpy as np
from scipy.spatial.transform import Rotation

THIGH_RADIUS = .095
CALF_RADIUS = .065
SHOE_RADIUS = .071
CLEARANCE = .008


def boxes(row, spec):
    parts = {p['id']: p for p in spec['parts']}
    names = list(row['parts'])
    centers = np.array([row['parts'][n][0] for n in names])
    rotations = Rotation.from_quat([row['parts'][n][1] for n in names], scalar_first=True).as_matrix()
    half = np.array([parts[n]['size'] for n in names]) / 2
    # The visible captive mounting brackets and driver rack are also obstacles.
    for connector in spec.get('connectors', []):
        if not connector.get('bracket'): continue
        carrier=connector['b'];parent=names.index(carrier)
        offset=(np.array(parts[connector['a']]['assembly_position'])
                +np.array(connector['tool_position'])-parts[carrier]['assembly_position'])
        sign=np.sign(parts[carrier]['assembly_position'][0])
        for label,delta,size in [('foot',[sign*.04,0,-.002],[.14,.045,.004]),
                                 ('upright',[sign*.105,0,.020],[.004,.045,.045])]:
            names.append(connector['id']+':bracket_'+label)
            centers=np.vstack([centers, centers[parent]+rotations[parent]@(offset+delta)])
            rotations=np.concatenate([rotations,rotations[parent:parent+1]])
            half=np.vstack([half,np.array(size)/2])
    names.append('driver_rack')
    centers=np.vstack([centers,[.65,-.7,.035]])
    rotations=np.concatenate([rotations,np.eye(3)[None]])
    half=np.vstack([half,[.085,.03,.035]])
    return names, centers, rotations, half


def segment_box_distances(a, b, obstacles):
    """Exact segment/OBB distance via piecewise quadratic minimization.

    Supports a batch of segments. Break points are the six slab crossings;
    each interval has a fixed set of clamped coordinates.
    """
    _, centers, rotations, half = obstacles
    a, b = np.atleast_2d(a), np.atleast_2d(b)
    start = np.einsum('sbi,bij->sbj', a[:, None] - centers, rotations)
    delta = np.einsum('si,bij->sbj', b-a, rotations)
    with np.errstate(divide='ignore', invalid='ignore'):
        cuts = np.concatenate([(-half-start)/delta, (half-start)/delta], axis=-1)
    cuts = np.nan_to_num(cuts, nan=0., posinf=1., neginf=0.)
    cuts = np.sort(np.clip(np.concatenate([np.zeros((*start.shape[:2],1)), cuts, np.ones((*start.shape[:2],1))],axis=-1),0,1),axis=-1)
    mid = (cuts[..., :-1] + cuts[..., 1:])/2
    sample = start[...,None,:] + mid[...,None]*delta[...,None,:]
    active = np.abs(sample) > half[None,:,None,:]
    offset = start[...,None,:] - np.sign(sample)*half[None,:,None,:]
    numerator = np.sum(np.where(active, delta[...,None,:]*offset, 0),axis=-1)
    denominator = np.sum(np.where(active, delta[...,None,:]**2, 0),axis=-1)
    t = np.clip(-numerator/np.maximum(denominator,1e-30), cuts[...,:-1], cuts[...,1:])
    points = start[...,None,:] + t[...,None]*delta[...,None,:]
    gap = np.maximum(np.abs(points)-half[None,:,None,:],0)
    return np.sqrt(np.min(np.sum(gap*gap,axis=-1),axis=-1))


def leg_segments(legs, back):
    starts, ends, radii, labels = [], [], [], []
    for side, (hip, knee, foot) in legs.items():
        hip,knee,foot = np.array([hip,knee,foot])
        for label,a,b,r in [('thigh',hip,knee,THIGH_RADIUS),('calf',knee,foot,CALF_RADIUS),('shoe',foot-np.array(back)*.06,foot+np.array(back)*.06,SHOE_RADIUS)]:
            starts.append(a);ends.append(b);radii.append(r);labels.append(side+':'+label)
    return np.array(starts),np.array(ends),np.array(radii),labels


def gaps(visual, obstacles):
    a,b,r,labels=leg_segments(visual['legs'],visual['back'])
    return segment_box_distances(a,b,obstacles)-r[:,None],labels


def audit(rows, visuals, spec):
    worst = {'gap_m':float('inf')};collisions=[]
    for i,(row,v) in enumerate(zip(rows,visuals)):
        obs=boxes(row,spec);dist,labels=gaps(v,obs);a,b=np.unravel_index(np.argmin(dist),dist.shape)
        hit=dict(frame=i,time_s=row['t'],stage=row['stage'],leg=labels[a],part=obs[0][b],gap_m=float(dist[a,b]))
        if hit['gap_m']<worst['gap_m']:worst=hit
        if hit['gap_m']<0:collisions.append(hit)
    return dict(passed=not collisions,frames=len(rows),colliding_frames=len(collisions),worst=worst,examples=collisions[::max(1,len(collisions)//12)],scope='Conservative thigh/calf/shoe capsules against every recorded oriented furniture box; sampled replay poses, not human dynamics.')

def interpolate_obstacles(a,b,u):
    names,ca,ra,half=a;_,cb,rb,_=b
    relative=Rotation.from_matrix(rb@ra.transpose(0,2,1)).as_rotvec()
    rot=Rotation.from_rotvec(relative*u).as_matrix()@ra
    return names,ca*(1-u)+cb*u,rot,half


if __name__=='__main__':
    import json,sys
    from pathlib import Path
    folder=Path(__file__).resolve().parent.parent/'outputs/product_v1'/sys.argv[1]
    report=audit(json.loads((folder/'trajectory.json').read_text()),json.loads((folder/'visuals.json').read_text()),json.loads((folder/'asset.json').read_text()))
    target=folder/(sys.argv[2] if len(sys.argv)>2 else 'leg-clearance.json')
    target.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
