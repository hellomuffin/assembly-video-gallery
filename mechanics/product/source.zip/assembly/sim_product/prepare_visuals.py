"""Retarget recorded physics to bounded hand poses and finite-length arm IK."""
import json,sys,numpy as np
from pathlib import Path
from scipy.spatial.transform import Rotation as R
H=Path(__file__).resolve().parent
def unit(v):
 v=np.asarray(v,float);return v/max(np.linalg.norm(v),1e-9)
def prepare(name,seed=1):
 out=H.parent/'outputs/product_v1'/f'{name}_{seed}';rows=json.loads((out/'trajectory.json').read_text());s=json.loads((out/'asset.json').read_text());parts={p['id']:p for p in s['parts']}
 lib=json.loads((H/'assets/hand_poses.json').read_text());wr=np.array(lib['wrist']);previous=None;eye=None;back=None;maxreach=0.;right_prev=None;visual=[];parked=False;feet={};swing=None;last_hip=None;next_side=-1;two_start=None;two_origin=None
 for row in rows:
  lp=np.array(row['gripper'][0]);lr=R.from_quat(row['gripper'][1],scalar_first=True)
  if row['two_hands']:
   parked=True
   if two_start is None:two_start=row['t'];two_origin=right_prev
   grasp=s['finish_second_grasp'];p,q=row['parts'][grasp['part']];r=R.from_quat(q,scalar_first=True)
   rp=np.array(p)+r.apply(grasp['position']);rr=r*R.from_quat(grasp['rotation'],scalar_first=True);close=row['closure']
  elif parked:
   rp=lp+[.23,0,.04];rr=lr;close=0.
  else:
   rp=np.array(row['tool'][0]);rr=R.from_quat(row['tool'][1],scalar_first=True)*R.from_rotvec(np.array([0,-row['stroke'],0]));close=1.
  # Smooth transition into/out of the second support grasp; normal tool strokes
  # are exact recorded poses, not filtered camera-dependent transforms.
  if row['two_hands'] and row['t']-two_start<.8 and two_origin is not None:
   a,ar=two_origin;u=np.clip((row['t']-two_start)/.8,0,1);v=u*u*(3-2*u)
   rp=a+(rp-a)*v+[0,0,.25*np.sin(np.pi*u)];rr=R.from_rotvec((rr*ar.inv()).as_rotvec()*v)*ar
  if parked and right_prev is not None and not row['two_hands']:
   prior_p,prior_r=right_prev;alpha=min(1.,.04/.18)
   rp=prior_p+(rp-prior_p)*alpha;rr=R.from_rotvec((rr*prior_r.inv()).as_rotvec()*alpha)*prior_r
  right_prev=(rp.copy(),rr)
  lwr=np.array(lib['board_wrist']) if row.get('grasp_profile')=='board' else wr
  rwr=np.array(lib['board_wrist']) if row['two_hands'] else wr
  lw=lp+lr.apply(lwr*np.array([-1,1,1]));rw=rp+rr.apply(rwr);focus=(lw+rw)/2
  # Approach the work from its outside, rather than retaining a front-only
  # stance that puts the hips inside a partly assembled cabinet.
  radial=np.r_[focus[:2],0.]
  raw_back=unit(radial) if np.linalg.norm(radial)>.08 else (back if back is not None else np.array([0.,-1,0]))
  if back is None:back=raw_back
  else:
   current_angle=np.arctan2(back[1],back[0]);target_angle=np.arctan2(raw_back[1],raw_back[0])
   delta=(target_angle-current_angle+np.pi)%(2*np.pi)-np.pi
   theta=current_angle+np.clip(delta,-.06,.06);back=np.array([np.cos(theta),np.sin(theta),0.])
  x=unit(np.cross(back,[0,0,1])) # shoulder left/right axis
  x=-x # rightward axis from the operator's backward vector
  shoulder=focus+back*.23+[0,0,.39-.15*np.clip((focus[2]-.5)/.6,0,1)]
  # Project the torso anchor into the intersection of both arm-reach balls.
  for _ in range(12):
   for wrist,sign in [(lw,-1),(rw,1)]:
    anchor=shoulder+x*sign*.18;dv=wrist-anchor;dd=np.linalg.norm(dv)
    if dd>.625:shoulder+=dv*(dd-.625)/dd
  desired_eye=shoulder-back*.085+[0,0,.24]
  eye=desired_eye
  arms={}
  for side,wrist,rot,sign in [('left',lw,lr,-1),('right',rw,rr,1)]:
   start=shoulder+x*sign*.18;delta=wrist-start;dist=np.linalg.norm(delta);maxreach=max(maxreach,dist)
   if dist>.645:raise RuntimeError(f'Hand reach exceeds arm length: {side} {dist} at {row["t"]}')
   u=unit(delta);a=.34;b=.31;along=(a*a-b*b+dist*dist)/(2*dist);radius=np.sqrt(max(0,a*a-along*along))
   preferred=back*.8+x*sign*.6+np.array([0,0,-.15]);bend=preferred-u*np.dot(preferred,u)
   if np.linalg.norm(bend)<.01:bend=back-u*np.dot(back,u)
   elbow=start+u*along+unit(bend)*radius
   arms[side]=[start.tolist(),elbow.tolist(),wrist.tolist()]
  target=focus+[0,0,-.04]
  hip_z=max(.30,shoulder[2]-.55);dz=shoulder[2]-hip_z
  hip=shoulder+back*np.sqrt(max(0,.56**2-dz**2));hip[2]=hip_z
  def clear_foot(goal):
   # Keep the shoe footprint outside low furniture and the assembly work area.
   for n,(bp,bq) in row['parts'].items():
    br=R.from_quat(bq,scalar_first=True).as_matrix();extent=np.abs(br)@np.array(parts[n]['size'])/2
    if bp[2]-extent[2]>.12:continue
    if np.all(np.abs(goal[:2]-np.array(bp[:2]))<extent[:2]+[.085,.15]):return False
   return not (abs(goal[0])<.45 and -.48<goal[1]<.48)
  def safe_goal(goal):
   offsets=sorted((back*depth+x*lateral for depth in [0,.12,.24,.36,.48,.60,.72] for lateral in [0,.13,-.13,.26,-.26,.39,-.39,.52,-.52]),key=lambda v:np.linalg.norm(v))
   for offset in offsets:
    candidate=goal+offset
    if clear_foot(candidate):return candidate
   raise RuntimeError('No safe foot landing near operator')
  legs={};desired_feet={}
  for sign in [-1,1]:
   h=hip+x*sign*.085;goal=h+back*.08+x*sign*.04;goal[2]=.055
   goal=safe_goal(goal);desired_feet[sign]=goal
   if sign not in feet:feet[sign]=goal.copy()
  if swing is None:
   eligible=[k for k in [-1,1] if np.linalg.norm((desired_feet[k]-feet[k])[:2])>.09]
   if eligible:
    side=next_side if next_side in eligible else eligible[0];next_side=-side
    velocity=np.zeros(3) if last_hip is None else (hip-last_hip)/.04
    goal=desired_feet[side]+np.r_[np.clip(velocity[:2]*.2,-.12,.12),0]
    goal=safe_goal(goal);swing=(side,row['t'],feet[side].copy(),goal)
  if swing is not None:
   side,t0,start,end=swing;u=min(1,(row['t']-t0)/.32);v=u*u*(3-2*u)
   feet[side]=start+(end-start)*v+[0,0,.11*np.sin(np.pi*u)]
   if u>=1:swing=None
  # Pelvis crouch adjusts to planted feet while limb lengths stay fixed.
  for sign in [-1,1]:
   h=hip+x*sign*.085;foot=feet[sign];horizontal=np.linalg.norm((h-foot)[:2])
   if horizontal>=1.02:raise RuntimeError('Foot landing exceeds leg span')
   hip[2]=min(hip[2],foot[2]+np.sqrt(1.02**2-horizontal**2))
  last_hip=hip.copy()
  for sign in [-1,1]:
   h=hip+x*sign*.085;foot=feet[sign];delta=foot-h;dist=np.linalg.norm(delta)
   if dist>1.035:raise RuntimeError(f'Leg reach {dist} at {row["t"]}')
   u=unit(delta);bend=-back-u*np.dot(-back,u);knee=(h+foot)/2+unit(bend)*np.sqrt(max(0,.52**2-dist**2/4))
   legs[str(sign)]=[h.tolist(),knee.tolist(),foot.tolist()]

  visual.append({'left':[lp.tolist(),lr.as_quat(scalar_first=True).tolist(),row['closure'],row.get('grasp_profile','tool')],
   'right':[rp.tolist(),rr.as_quat(scalar_first=True).tolist(),close,'board' if row['two_hands'] else 'tool'],
   'arms':arms,'eye':eye.tolist(),'look':target.tolist(),'shoulder':shoulder.tolist(),'hip':hip.tolist(),'legs':legs,'back':back.tolist()})
 (out/'visuals.json').write_text(json.dumps(visual,separators=(',',':')))
 low=np.min([np.array(p['assembly_position'])-np.array(p['size'])/2 for p in s['parts']],axis=0)
 high=np.max([np.array(p['assembly_position'])+np.array(p['size'])/2 for p in s['parts']],axis=0)
 inside=[i for i,r in enumerate(rows) if r['stage'].startswith('Tighten') and all(np.array(visual[i]['hip'])[:2]>low[:2]-.05) and all(np.array(visual[i]['hip'])[:2]<high[:2]+.05)]
 assert not inside,'Operator hips enter assembly area while tightening'
 (out/'visual-check.json').write_text(json.dumps({'max_shoulder_to_wrist_m':maxreach,'arm_lengths_m':[.34,.31],'hips_inside_assembly_footprint_during_tightening':len(inside),'passed':True,'scope':'Kinematic arm reach and tightening stance; not whole-body balance or collision certification'},indent=2))
 print(name,'frames',len(rows),'maximum reach',maxreach)
if __name__=='__main__':prepare(sys.argv[1])
