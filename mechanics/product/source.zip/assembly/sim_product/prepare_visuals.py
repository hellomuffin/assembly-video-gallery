"""Retarget recorded physics to bounded hand poses and finite-length arm IK."""
import json,sys,numpy as np
from pathlib import Path
from scipy.spatial.transform import Rotation as R
H=Path(__file__).resolve().parent
def unit(v):
 v=np.asarray(v,float);return v/max(np.linalg.norm(v),1e-9)
def prepare(name,seed=1):
 out=H.parent/'outputs/product_v1'/f'{name}_{seed}';rows=json.loads((out/'trajectory.json').read_text());s=json.loads((out/'asset.json').read_text());parts={p['id']:p for p in s['parts']}
 lib=json.loads((H/'assets/hand_poses.json').read_text());wr=np.array(lib['wrist']);eye=None;back=None;maxreach=0.;right_prev=None;visual=[];parked=False;two_start=None;two_origin=None
 for row in rows:
  lp=np.array(row['gripper'][0]);lr=R.from_quat(row['gripper'][1],scalar_first=True)
  if row['two_hands']:
   parked=True
   if two_start is None:two_start=row['t'];two_origin=right_prev
   grasp=s['finish_second_grasp'];p,q=row['parts'][grasp['part']];r=R.from_quat(q,scalar_first=True)
   rp=np.array(p)+r.apply(grasp['position']);rr=r*R.from_quat(grasp['rotation'],scalar_first=True);close=row['closure']
  elif parked:
   rp=lp+[.23,0,.04];rr=lr;close=0.
  else:
   rp=np.array(row['tool'][0]);rr=R.from_quat(row['tool'][1],scalar_first=True)*R.from_rotvec(np.array([0,-row['stroke'],0]));close=1.
  # Smooth transition into/out of the second support grasp; normal tool strokes
  # are exact recorded poses, not filtered camera-dependent transforms.
  if row['two_hands'] and row['t']-two_start<.8 and two_origin is not None:
   a,ar=two_origin;u=np.clip((row['t']-two_start)/.8,0,1);v=u*u*(3-2*u)
   rp=a+(rp-a)*v+[0,0,.25*np.sin(np.pi*u)];rr=R.from_rotvec((rr*ar.inv()).as_rotvec()*v)*ar
  if parked and right_prev is not None and not row['two_hands']:
   prior_p,prior_r=right_prev;alpha=min(1.,.04/.18)
   rp=prior_p+(rp-prior_p)*alpha;rr=R.from_rotvec((rr*prior_r.inv()).as_rotvec()*alpha)*prior_r
  right_prev=(rp.copy(),rr)
  lwr=np.array(lib['board_wrist']) if row.get('grasp_profile')=='board' else wr
  rwr=np.array(lib['board_wrist']) if row['two_hands'] else wr
  lw=lp+lr.apply(lwr*np.array([-1,1,1]));rw=rp+rr.apply(rwr);focus=(lw+rw)/2
  # Approach the work from its outside, rather than retaining a front-only
  # stance that puts the hips inside a partly assembled cabinet.
  radial=np.r_[focus[:2],0.]
  raw_back=unit(radial) if np.linalg.norm(radial)>.08 else (back if back is not None else np.array([0.,-1,0]))
  if back is None:back=raw_back
  else:
   current_angle=np.arctan2(back[1],back[0]);target_angle=np.arctan2(raw_back[1],raw_back[0])
   delta=(target_angle-current_angle+np.pi)%(2*np.pi)-np.pi
   theta=current_angle+np.clip(delta,-.06,.06);back=np.array([np.cos(theta),np.sin(theta),0.])
  x=unit(np.cross(back,[0,0,1])) # shoulder left/right axis
  x=-x # rightward axis from the operator's backward vector
  shoulder=focus+back*.23+[0,0,.39-.15*np.clip((focus[2]-.5)/.6,0,1)]
  # Project the torso anchor into the intersection of both arm-reach balls.
  for _ in range(12):
   for wrist,sign in [(lw,-1),(rw,1)]:
    anchor=shoulder+x*sign*.18;dv=wrist-anchor;dd=np.linalg.norm(dv)
    if dd>.625:shoulder+=dv*(dd-.625)/dd
  desired_eye=shoulder-back*.085+[0,0,.24]
  eye=desired_eye
  arms={}
  for side,wrist,rot,sign in [('left',lw,lr,-1),('right',rw,rr,1)]:
   start=shoulder+x*sign*.18;delta=wrist-start;dist=np.linalg.norm(delta);maxreach=max(maxreach,dist)
   if dist>.645:raise RuntimeError(f'Hand reach exceeds arm length: {side} {dist} at {row["t"]}')
   u=unit(delta);a=.34;b=.31;along=(a*a-b*b+dist*dist)/(2*dist);radius=np.sqrt(max(0,a*a-along*along))
   preferred=back*.8+x*sign*.6+np.array([0,0,-.15]);bend=preferred-u*np.dot(preferred,u)
   if np.linalg.norm(bend)<.01:bend=back-u*np.dot(back,u)
   elbow=start+u*along+unit(bend)*radius
   arms[side]=[start.tolist(),elbow.tolist(),wrist.tolist()]
  target=focus+[0,0,-.04]
  visual.append({'left':[lp.tolist(),lr.as_quat(scalar_first=True).tolist(),row['closure'],row.get('grasp_profile','tool')],
   'right':[rp.tolist(),rr.as_quat(scalar_first=True).tolist(),close,'board' if row['two_hands'] else 'tool'],
   'arms':arms,'eye':eye.tolist(),'look':target.tolist(),'shoulder':shoulder.tolist(),'back':back.tolist()})
 from plan_legs import plan
 from smooth_legs import smooth
 from repair_leg_transitions import repair
 from validate_legs import validate, stamp
 visual,failures=plan(rows,visual,s)
 (out/'leg-plan-failures.json').write_text(json.dumps(failures,indent=2))
 if failures:
  raise RuntimeError(f'Leg planning failed at {len(failures)} frames')
 visual=repair(rows,smooth(rows,visual,s),s)
 report=validate(rows,visual,s)
 if not report['passed']:
  (out/'leg-validation-rejected.json').write_text(json.dumps(report,indent=2))
  raise RuntimeError('Leg motion rejected; see leg-validation-rejected.json')
 low=np.min([np.array(p['assembly_position'])-np.array(p['size'])/2 for p in s['parts']],axis=0)
 high=np.max([np.array(p['assembly_position'])+np.array(p['size'])/2 for p in s['parts']],axis=0)
 inside=[i for i,r in enumerate(rows) if r['stage'].startswith('Tighten') and all(np.array(visual[i]['hip'])[:2]>low[:2]-.05) and all(np.array(visual[i]['hip'])[:2]<high[:2]+.05)]
 assert not inside,'Operator hips enter assembly area while tightening'
 pending=out/'visuals.accepted.tmp'
 pending.write_text(json.dumps(visual,separators=(',',':')))
 pending.replace(out/'visuals.json')
 stamp(report,out,out/'visuals.json')
 (out/'visual-check.json').write_text(json.dumps({'max_shoulder_to_wrist_m':maxreach,'arm_lengths_m':[.34,.31],'hips_inside_assembly_footprint_during_tightening':len(inside),'passed':True,'leg_clearance_passed':report['passed'],'scope':'Kinematic arm reach, tightening stance and independently audited leg/part clearance; not full-body balance or collision certification'},indent=2))
 print(name,'frames',len(rows),'maximum reach',maxreach)
if __name__=='__main__':prepare(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 1)
