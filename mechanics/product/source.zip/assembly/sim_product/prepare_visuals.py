"""Prepare a complete articulated replay, or reject the candidate.

The former independent hip/knee offset pipeline is deliberately not a fallback.
An infeasible grasp, stance, or transition must be replanned at task level.
"""
from pathlib import Path
import json,sys,os
import numpy as np
from articulated_body import Body
from plan_body_motion import plan,angle_delta
from task_hands import hand_constraints,attach_free_hands
from validate_body_motion import validate_parallel as validate
from body_proof import stamp,digest,H as SOURCE_ROOT,EXECUTION_SOURCES,verify_execution_sources
H=Path(__file__).resolve().parent


def prepare_postfit(name,seed=1):
    folder=Path(os.environ.get('PRODUCT_OUTPUT_ROOT',H.parent/'outputs/product_v1'))/f'{name}_{seed}'
    rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text())
    try:candidate=plan(rows,spec)
    except RuntimeError as error:
        (folder/'body-rejected.json').write_text(json.dumps({'passed':False,'reason':str(error)},indent=2));raise
    (folder/'body-candidate.json').write_text(json.dumps(candidate,separators=(',',':')))
    if not candidate['passed']:raise RuntimeError('Work stance or transition infeasible; see body-candidate.json. No visuals were accepted.')
    keys=candidate['keyframes'];body=Body(spec);visual=[];qs=[];previous=None;k=0
    for i,row in enumerate(rows):
        while k+1<len(keys)-1 and keys[k+1]['frame']<i:k+=1
        a,b=keys[k],keys[min(k+1,len(keys)-1)];u=(i-a['frame'])/max(1,b['frame']-a['frame'])
        nominal=np.array(a['q'])*(1-u)+np.array(b['q'])*u
        anchors={side:np.array(a['anchors'][side])*(1-u)+np.array(b['anchors'][side])*u for side in ['left','right']}
        yaws={side:a['foot_yaws'][side]+angle_delta(b['foot_yaws'][side],a['foot_yaws'][side])*u for side in ['left','right']}
        hands,targets=hand_constraints(row,spec)
        support=[side for side in anchors if anchors[side][2]<.066]
        if not support:raise RuntimeError('Candidate has no declared supporting foot')
        q,report=body.fit(targets,row,initial=nominal,nominal=nominal,anchors=anchors,foot_yaws=yaws,support_sides=support,continuity=previous,max_nfev=60)
        if not report['accepted']:
            (folder/'body-rejected.json').write_text(json.dumps(dict(frame=i,**report),indent=2));raise RuntimeError('Full-rate body motion failed; no visuals were accepted')
        previous=q;qs.append(q.tolist());v=body.landmarks(q);v.update(attach_free_hands(body,q,hands,targets))
        if not row.get('tool_parked') and 'right' not in targets:v['tool']=v['right'][:2]
        visual.append(v)
    report=validate(rows,qs,spec,subsamples=3)
    if not report['passed']:
        (folder/'body-rejected.json').write_text(json.dumps(report,indent=2));raise RuntimeError('Independent body or clothing audit rejected the motion')
    pending=folder/'visuals.articulated.tmp';pending.write_text(json.dumps(visual,separators=(',',':')));pending.replace(folder/'visuals.json');stamp(report,folder)
    (folder/'visual-check.json').write_text(json.dumps({'passed':True,'scope':report['scope'],'articulated_body':True},indent=2))
    print(name,'accepted articulated frames',len(rows),flush=True)

def prepare(name,seed=1):
    folder=Path(os.environ.get('PRODUCT_OUTPUT_ROOT',H.parent/'outputs/product_v1'))/f'{name}_{seed}'
    rows=json.loads((folder/'trajectory.json').read_text())
    if not any('body_q' in row for row in rows):return prepare_postfit(name,seed)
    if not all('body_q' in row and 'body_visual' in row for row in rows):raise RuntimeError('Incomplete recorded body execution')
    execution=json.loads((folder/'result.json').read_text())
    if not execution.get('passed') or not execution.get('full_task_complete'):raise RuntimeError('The body-driven task execution is incomplete')
    verify_execution_sources(folder,execution)
    spec=json.loads((folder/'asset.json').read_text());qs=[row['body_q'] for row in rows]
    report=validate(rows,qs,spec,subsamples=3)
    if not report['passed']:
        (folder/'body-rejected.json').write_text(json.dumps(report,indent=2));raise RuntimeError('Recorded body execution failed independent audit')
    report['recorded_execution']=True
    # Regenerate landmarks from audited joints; never trust cached visual limbs.
    body=Body(spec);visual=[]
    for row,q in zip(rows,qs):
        hands,targets=hand_constraints(row,spec);v=body.landmarks(q);v.update(attach_free_hands(body,q,hands,targets));v['tool']=row['tool'];visual.append(v)
    pending=folder/'visuals.articulated.tmp';pending.write_text(json.dumps(visual,separators=(',',':')));pending.replace(folder/'visuals.json');stamp(report,folder)
    (folder/'visual-check.json').write_text(json.dumps({'passed':True,'scope':report['scope'],'articulated_body':True,'recorded_execution':True},indent=2))
    print(name,'accepted recorded articulated frames',len(rows),flush=True)

if __name__=='__main__':prepare(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 1)
