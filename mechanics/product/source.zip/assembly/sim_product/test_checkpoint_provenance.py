"""Continuation must preserve the exact accepted history and restore inputs."""
import json
import tempfile
import unittest
from pathlib import Path
from body_proof import (H,EXECUTION_SOURCES,EXECUTION_SOURCE_SCHEMA,digest,
    archive_execution_sources,capture_continuation,verify_execution_sources)


class CheckpointProvenance(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory();self.addCleanup(self.directory.cleanup)
        root=Path(self.directory.name);self.parent=root/'parent';self.child=root/'child'
        sources={name:digest(H/name) for name in EXECUTION_SOURCES}
        self.result=dict(passed=True,full_task_complete=False,frozen_execution=True,
            source_schema=EXECUTION_SOURCE_SCHEMA,source_sha256=sources,diagnostic_resume=False)
        for folder in [self.parent,self.child]:
            archive_execution_sources(folder,sources)
            for name,value in {'asset.json':{'parts':[]},'trajectory.json':[{'t':.04}],
                'events.json':[{'action':'test','t':.04}],'controller-state.json':{},'result.json':self.result}.items():
                (folder/name).write_text(json.dumps(value))
            for name in ['model.mjb','model.xml','integration-state.npy']:(folder/name).write_bytes(b'unit-test restore data')
        continuation=capture_continuation(self.parent,self.child,{'passed':True,'checked_poses':1})
        (self.child/'result.json').write_text(json.dumps({**self.result,'continuation':continuation}))
        (self.child/'trajectory.json').write_text(json.dumps([{'t':.04},{'t':.08}]))

    def test_preserves_prefix_and_rejects_rewritten_history(self):
        execution=json.loads((self.child/'result.json').read_text())
        verify_execution_sources(self.child,execution)
        (self.child/'trajectory.json').write_text(json.dumps([{'t':.03},{'t':.08}]))
        with self.assertRaisesRegex(RuntimeError,'recorded prefix'):verify_execution_sources(self.child,execution)

    def test_rejects_modified_physics_restore_state(self):
        execution=json.loads((self.child/'result.json').read_text())
        (self.child/'execution_parent/integration-state.npy').write_bytes(b'changed state')
        with self.assertRaisesRegex(RuntimeError,'Changed continuation parent'):verify_execution_sources(self.child,execution)

    def test_diagnostic_history_cannot_authorize_a_continuation(self):
        (self.parent/'result.json').write_text(json.dumps({**self.result,'diagnostic_resume':True}))
        with self.assertRaisesRegex(RuntimeError,'diagnostic'):
            capture_continuation(self.parent,self.child,{'passed':True})


if __name__=='__main__':unittest.main()
