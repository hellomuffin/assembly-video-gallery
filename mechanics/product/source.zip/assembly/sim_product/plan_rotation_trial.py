"""Coupled bimanual rotation planning; object translation is a solved variable."""
import json,sys,copy
from pathlib import Path
import numpy as np
from articulated_body import Body,R
from carried_body import CarriedBody
from task_hands import hand_constraints,attach_free_hands
from validate_body_motion import validate

folder=Path(sys.argv[1]);rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text());plain=Body(spec)
reference=min([r for r in rows if r.get('two_hands') and r['stage']=='Carry top'],key=lambda r:abs(R.from_quat(r['parts']['top'][1],scalar_first=True).magnitude()-np.pi/2))
_,targets=hand_constraints(reference,spec);focus=np.mean(list(targets.values()),axis=0)
nominal=plain.seed('stand',focus[:2]-[0,.4],0);anchors={s:plain.point(s+'_ankle') for s in ['left','right']}
for s in anchors:anchors[s][2]=.065
initial,report=plain.fit(targets,reference,mode='stand',nominal=nominal,anchors=anchors,max_nfev=200)
if not report['accepted']:raise RuntimeError('Cannot initialize two-hand grasp: '+str(report))
body=CarriedBody(spec,reference,initial,bimanual=True);object_rotation=R.from_quat(reference['parts']['top'][1],scalar_first=True)
previous=initial;result=[];failures=[];out=folder/('coupled-rotation-away' if '--away' in sys.argv else 'coupled-rotation-trial');out.mkdir(exist_ok=True)
checkpoint=out/'candidate.partial.json'
if checkpoint.exists() and '--resume' in sys.argv:
    result=json.loads(checkpoint.read_text());previous=np.array(result[-1]['q']);failures=[dict(frame=i,**r['report']) for i,r in enumerate(result) if not r['report']['accepted']]
    print('RESUME',len(result),flush=True)
for i,angle in list(enumerate(np.linspace(0,-np.pi if '--away' in sys.argv else np.pi,101)))[len(result):]:
    body.hand_rotation_override=R.from_euler('x',angle)*object_rotation.inv()*body.reference_rotation
    q,report=body.fit({},reference,mode='stand',initial=previous,nominal=nominal,anchors=anchors,continuity=previous,max_nfev=150)
    predicted=copy.deepcopy(body.predicted_row);predicted['t']=reference['t']+i*.08;predicted['stage']='Coupled rotation planning prediction'
    v=body.landmarks(q);hands,targets=hand_constraints(predicted,spec);v.update(hands)
    result.append(dict(row=predicted,visual=v,q=q.tolist(),report=report));previous=q
    if not report['accepted']:failures.append(dict(frame=i,**report))
    if i%10==0 or not report['accepted']:
        print('ROTATE',i,round(float(predicted['parts']['top'][0][2]),3),report,flush=True)
        (out/'candidate.partial.json').write_text(json.dumps(result))
report={'passed':not failures,'requires_physics_execution':True,'failures':failures}
(out/'candidate.json').write_text(json.dumps(dict(report=report,frames=result)))
if not failures:
    report['geometry']=validate([r['row'] for r in result],[r['q'] for r in result],spec,subsamples=3)
    report['passed']=report['geometry']['passed']
(out/'candidate.json').write_text(json.dumps(dict(report=report,frames=result),indent=2))
for name,value in [('trajectory',[r['row'] for r in result]),('visuals',[r['visual'] for r in result]),('asset',spec),('validation',report)]:
    (out/(name+'.json')).write_text(json.dumps(value))
print('COUPLED_ROTATION',report,flush=True)
