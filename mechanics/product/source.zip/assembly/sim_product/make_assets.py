"""Original panel furniture with explicit preinstalled angle brackets."""
from pathlib import Path
import json,numpy as np
from scipy.spatial.transform import Rotation as R
H=Path(__file__).resolve().parent
def frame(x,y):
 x=np.array(x,float);y=np.array(y,float)
 return R.from_matrix(np.column_stack([x,y,np.cross(x,y)])).as_quat(scalar_first=True).tolist()
for name in ['table','shelf']:
 s=json.loads((H.parent/'sim_shared/assets'/f'{name}.json').read_text());s['id']=name+'_timber';s['description']='Original timber furniture; preinstalled mounting brackets; simplified ratcheting screw operations.'
 for p in s['parts']:
  if p['id']==s['base']:
   if name=='table':p['size'][2]=.035;p['assembly_position'][2]=.0225
   p['grasp_position']=[0,-p['size'][1]/2,0];p['grasp_profile']='board'
   p['grasp_rotation']=frame([1,0,0],[0,-1,0])
  elif name=='table':
   p['size'][:2]=[.04,.04];p['assembly_position'][2]=.26
   p['grasp_position']=[0,0,.12];p['grasp_rotation']=frame([0,0,1],[0,-1,0])
  elif p['id'] in ['left','right']:
   p['grasp_position']=[0,0,.14];p['grasp_profile']='board';p['grasp_rotation']=frame([0,1 if p['id']=='left' else -1,0],[0,0,1])
  else:
   p['grasp_position']=[0,0,.14];p['grasp_profile']='board';p['grasp_rotation']=frame([1,0,0],[0,0,1])
 for c in s['connectors']:
  c['required_turns']=1.0
  if name=='table':
   b=next(p for p in s['parts'] if p['id']==c['b']);x,y,_=b['assembly_position']
   # Bracket projects inward from the leg; screw enters the tabletop.
   c['tool_position']=[x- np.sign(x)*.12,y,.0175+.004]
   c['tool_axis']=[0,0,-1];c['bracket']=True
  elif c['a']=='back':
   sign=-1 if c['b']=='left' else 1
   c['tool_position']=[sign*.185,0,.0175+.004];c['tool_axis']=[0,0,-1];c['bracket']=True
  else:
   sign=-1 if c['a']=='left' else 1
   c['tool_position']=[sign*.019,c['tool_position'][1],.08]
   c['tool_axis']=[-sign,0,0];c['bracket']=False
 s['finish_grasp_part']='top' if name=='table' else 'left'
 s['finish_second_grasp']={'part':'top','position':[0,.275,0],'rotation':frame([-1,0,0],[0,1,0])} if name=='table' else {'part':'right','position':[0,0,.14],'rotation':frame([0,-1,0],[0,0,1])}
 s['finish_rotation']=R.from_euler('x',np.pi if name=='table' else np.pi/2).as_quat(scalar_first=True).tolist()
 # Base center height with the finished furniture standing on its feet/edge.
 s['finish_height']=.4575 if name=='table' else .425
 (H/'assets'/f'{name}.json').write_text(json.dumps(s,indent=2))
if __name__=='__main__':print('Wrote original table and shelf descriptions')
