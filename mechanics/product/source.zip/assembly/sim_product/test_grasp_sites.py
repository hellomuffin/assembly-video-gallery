"""Surface-grasp geometry and the two-hand floor-pickup regression."""
import json,unittest
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
from grasp_sites import candidates,paired_candidates,completed_assembly_pairs
from task_hands import wrist_offset


class GraspRegression(unittest.TestCase):
    def test_completed_shelf_pairs_keep_both_contacts_on_original_panels(self):
        spec=json.loads((Path(__file__).parent/'assets/shelf.json').read_text())
        before=json.dumps(spec,sort_keys=True);parts={p['id']:p for p in spec['parts']}
        options=completed_assembly_pairs(spec,'left')
        self.assertEqual(options[0]['position'],parts['left']['grasp_position'])
        self.assertEqual(options[1]['position'],[0.,-.1,.14])
        self.assertEqual(options[1]['paired']['position'],[0.,-.1,.14])
        for grip in options:
            self.assertEqual(grip['rotation'],parts['left']['grasp_rotation'])
            self.assertEqual(grip['paired']['rotation'],spec['finish_second_grasp']['rotation'])
            for name,contact in [('left',grip),('right',grip['paired'])]:
                point=np.asarray(contact['position']);half=np.asarray(parts[name]['size'])/2
                self.assertTrue(np.all(abs(point)<=half+1e-12))
                self.assertTrue(np.any(np.isclose(abs(point),half,atol=1e-12)))
            delta=np.array(parts['right']['assembly_position'])+grip['paired']['position']-np.array(parts['left']['assembly_position'])-grip['position']
            np.testing.assert_allclose(delta,[.615,0,0],atol=1e-12)
        self.assertEqual(json.dumps(spec,sort_keys=True),before)

    def test_same_panel_finish_candidates_are_unchanged(self):
        spec=json.loads((Path(__file__).parent/'assets/table.json').read_text())
        part=next(p for p in spec['parts'] if p['id']==spec['finish_grasp_part'])
        self.assertEqual(completed_assembly_pairs(spec,part['id']),paired_candidates(part,palm_pitch_degrees=(0,45,70)))

    def test_two_panel_floor_pickup_keeps_bent_elbows_and_native_clearance(self):
        from articulated_body import Body
        from validate_body_motion import validate_pose,ClothingAudit
        from task_hands import hand_constraints
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_two_panel_floor_pickup.json').read_text())
        row=fixture['row'];body=Body(fixture['spec'],comfortable=True);q=np.asarray(row['body_q'])
        self.assertEqual(validate_pose(body,q,row,ClothingAudit()),[])
        body.obstacles(row);body.set(q)
        _,targets=hand_constraints(row,fixture['spec'])
        for side in ['left','right']:
            self.assertLess(np.linalg.norm(body.point(side+'_wrist')-targets[side]),.003)
            self.assertGreater(q[body.index[side+'_elbow']],np.radians(10))

    def test_bracket_supported_panel_has_an_above_floor_surface_grasp(self):
        from grasp_sites import select
        from articulated_body import Body
        data=json.loads((Path(__file__).parent/'tests/fixtures/tilted_panel_grasp.json').read_text())
        part=data['part'];position,quat=data['pose'];rotation=R.from_quat(quat,scalar_first=True)
        spec=json.loads((Path(__file__).parent/'assets/shelf.json').read_text());body=Body(spec)
        minimum=float(body.m.geom_size[body.m.geom('left_forearm').id,0])+.012
        options=candidates(part)
        for grip in options[:5]:
            wrist=np.array(position)+rotation.apply(grip['position'])+(rotation*R.from_quat(grip['rotation'],scalar_first=True)).apply(wrist_offset('left','board'))
            self.assertLess(wrist[2],minimum)
        chosen=options[select(part,position,rotation,minimum)]
        point=np.asarray(chosen['position']);half=np.asarray(part['size'])/2
        self.assertTrue(np.all(np.abs(point)<=half+1e-12))
        self.assertEqual(np.count_nonzero(np.isclose(np.abs(point),half)),2)
        wrist=np.array(position)+rotation.apply(point)+(rotation*R.from_quat(chosen['rotation'],scalar_first=True)).apply(wrist_offset('left','board'))
        self.assertGreaterEqual(wrist[2],minimum)

    def test_paired_grasps_stay_on_panel_edges(self):
        part=json.loads((Path(__file__).parent/'assets/table.json').read_text())['parts'][0]
        self.assertFalse(any(g.get('purpose')=='two_hand_finish' for g in candidates(part)))
        for grip in paired_candidates(part):
            rotation=R.from_quat(grip['rotation'],scalar_first=True)
            for side,g in [('left',grip),('right',grip['paired'])]:
                point=np.array(g['position']);half=np.array(part['size'])/2
                self.assertTrue(np.all(abs(point)<=half+1e-12))
                self.assertGreaterEqual(np.count_nonzero(np.isclose(abs(point),half)),2)
                self.assertGreater(np.dot(rotation.apply(wrist_offset(side,'board')),rotation.apply([0,1,0])),.05)

    def test_pitched_panel_grasps_keep_the_same_surface_contacts(self):
        part=json.loads((Path(__file__).parent/'assets/table.json').read_text())['parts'][0]
        flat=paired_candidates(part);pitched=paired_candidates(part,palm_pitch_degrees=(45,70))
        for i,base in enumerate(flat):
            for candidate in pitched[2*i:2*i+2]:
                np.testing.assert_allclose(candidate['position'],base['position'])
                np.testing.assert_allclose(candidate['paired']['position'],base['paired']['position'])
                np.testing.assert_allclose(candidate['surface_normal'],base['surface_normal'])
                expected=R.from_quat(base['rotation'],scalar_first=True)*R.from_euler('x',candidate['palm_pitch_degrees'],degrees=True)
                actual=R.from_quat(candidate['rotation'],scalar_first=True)
                self.assertLess((expected.inv()*actual).magnitude(),1e-12)

    def test_pitched_pickup_and_setdown_keep_native_anatomy_clear(self):
        from articulated_body import Body
        from validate_body_motion import validate_pose,ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_pitched_endpoints.json').read_text())
        body=Body(fixture['spec'],comfortable=True);surface=ClothingAudit()
        for key in ['pickup','setdown']:
            row=fixture[key]
            self.assertEqual(validate_pose(body,row['body_q'],row,surface),[],key)

    def test_coupled_lowering_reaches_the_floor_without_forcing_a_hand_line(self):
        from types import SimpleNamespace
        from final_motion import lowering_plan
        from validate_body_motion import validate_pose,ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_pitched_endpoints.json').read_text())
        row={**fixture['upright'],'stage':'Set down completed furniture'}
        def pose(name):
            p,q=row['gripper'] if name=='gripper' else row['parts'][name]
            return np.asarray(p),R.from_quat(q,scalar_first=True)
        world=SimpleNamespace(spec=fixture['spec'],operator_q=np.asarray(row['body_q']),
            current_row=lambda:row,pose=pose,grasp_profile=row['grasp_profile'],
            anchors={s:np.asarray(a) for s,a in row['body_anchors'].items()},foot_yaws=row['body_foot_yaws'])
        body,records=lowering_plan(world,{'q':np.asarray(fixture['setdown']['body_q'])})
        surface=ClothingAudit()
        for q,rotation in records:
            body.hand_rotation_override=rotation;body.set(q)
            sample={**body.predicted_row,'body_anchors':world.anchors,'body_foot_yaws':world.foot_yaws}
            self.assertEqual(validate_pose(body,q,sample,surface),[])
        body.set(records[-1][0]);position=body.predicted_row['parts'][world.spec['base']][0]
        np.testing.assert_allclose(position,[0,0,world.spec['finish_height']],atol=.003)

    def test_twohand_floor_pickup_has_clear_native_body(self):
        from articulated_body import Body
        from validate_body_motion import validate_pose,ClothingAudit
        data=json.loads((Path(__file__).parent/'tests/fixtures/table_twohand_floor_pickup.json').read_text())
        errors=validate_pose(Body(data['spec']),data['q'],data['row'],ClothingAudit())
        self.assertEqual(errors,[])

    def test_pickup_goal_preserves_walking_yaw_revolution(self):
        from types import SimpleNamespace
        from unittest.mock import patch
        from articulated_body import Body
        from task_hands import hand_constraints,attach_free_hands
        from final_motion import reach_second_grasp
        data=json.loads((Path(__file__).parent/'tests/fixtures/table_twohand_floor_pickup.json').read_text())
        row={**data['row'],'two_hands':False};body=Body(data['spec']);goal=np.array(data['q']);current=goal.copy();current[3]+=2*np.pi
        hands,targets=hand_constraints(row,data['spec']);hands=attach_free_hands(body,current,hands,targets)
        world=SimpleNamespace(operator=body,operator_q=current,spec=data['spec'],current_row=lambda:dict(row),rows=[{'body_visual':hands}],anchors={s:np.array(a) for s,a in data['anchors'].items()},foot_yaws={s:data['yaw']+2*np.pi for s in data['anchors']})
        with patch('final_motion.joint_second_grasp') as execute:
            reach_second_grasp(world,goal_q=goal,allow_load_motion=False)
        aligned=execute.call_args.args[1]
        self.assertLess(abs(aligned[3]-current[3]),.2)
        self.assertGreater(aligned[3],np.pi)


if __name__=='__main__':unittest.main()
