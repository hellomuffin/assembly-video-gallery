"""Bounded anatomical poses for visual animation; does not claim finger dynamics."""
from pathlib import Path
import json,numpy as np,mujoco
from scipy.spatial.transform import Rotation as R
H=Path(__file__).resolve().parent;D=H.parent/'outputs/hand_v3'
geo=json.loads((D/'lift_geometry.json').read_text());frames=json.loads((D/'lift_frames.json').read_text())
m=mujoco.MjModel.from_xml_path(str(D/'contact_model.xml'));d=mujoco.MjData(m)
closed=np.array(frames[100]['qpos']);opened=np.array(frames[0]['qpos'])
assert len(closed)==m.nq
d.qpos[:]=closed;mujoco.mj_forward(m,d);bid=m.body('tool').id
center=d.xpos[bid].copy();reference=d.xmat[bid].reshape(3,3).copy()
rows=[];maximum_violation=0.
for u in np.linspace(0,1,21):
 d.qpos[:]=closed
 for i in range(m.njnt):
  n=m.joint(i).name;adr=m.jnt_qposadr[i]
  if n not in ['lift','base_x','base_y','tool_free','tool_turn','pro_sup_r','flexion_r','deviation_r']:
   q=opened[adr]*(1-u)+closed[adr]*u
   if m.jnt_limited[i]:q=np.clip(q,*m.jnt_range[i])
   d.qpos[adr]=q
 mujoco.mj_forward(m,d)
 rows.append({'closure':float(u),'xpos':((d.xpos-center)@reference).tolist(),'xmat':np.einsum('ij,njk->nik',reference.T,d.xmat.reshape(-1,3,3)).tolist()})
ci=geo['bodies'].index('capitate_r');wrist=(np.array(rows[-1]['xpos'][ci])+np.array(rows[-1]['xmat'][ci])@np.array([0,.012,0])).tolist()
(H/'assets/hand_poses.json').write_text(json.dumps({'bodies':geo['bodies'],'poses':rows,'wrist':wrist,'source':'MyoHub/myo_sim anatomical model (Apache-2.0); kinematic bounded joint interpolation'},separators=(',',':')))
print('Exported bounded hand poses',len(rows))
