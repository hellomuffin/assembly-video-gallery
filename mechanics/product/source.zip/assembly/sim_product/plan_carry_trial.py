"""Private coupled transport trial; predicted object poses are not replay data."""
from pathlib import Path
import json,sys,copy
import numpy as np
from articulated_body import Body,R
from carried_body import CarriedBody
from plan_body_motion import stance_seed,angle_delta
from foot_contacts import choose_landing,boxes
from task_hands import hand_constraints,attach_free_hands
from validate_body_motion import validate

folder=Path(sys.argv[1]);rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text());candidate=json.loads((folder/'body-candidate.json').read_text())
start=max((k for k in candidate['keyframes'] if rows[k['frame']]['stage']=='Raise leg 0' and k['report']['accepted']),key=lambda k:k['frame'])
reference=rows[start['frame']];template=np.array(start['q']);goal=candidate['stations']['fasten:mount_0'];goal_anchors={s:np.array(a) for s,a in goal['anchors'].items()};goal_yaw=goal['q'][3];goal_center=np.mean(list(goal_anchors.values()),axis=0)
body=CarriedBody(spec,reference,template);anchors={s:np.array(a) for s,a in start['anchors'].items()};foot_yaws=start['foot_yaws'];yaw=template[3];previous=template.copy();gait=None;next_side='left';result=[];failures=[]
for step in range(220):
    t=step*.2;foot_center=np.mean(list(anchors.values()),axis=0);delta=goal_center[:2]-foot_center[:2];distance=np.linalg.norm(delta)
    walking=distance>.20;desired_yaw=np.arctan2(-delta[0],delta[1]) if walking else goal_yaw
    yaw+=np.clip(angle_delta(desired_yaw,yaw),-.06,.06)
    support=['left','right']
    arrived=max(np.linalg.norm(goal_anchors[s]-anchors[s]) for s in anchors)<.03 and max(abs(angle_delta(goal_yaw,foot_yaws[s])) for s in anchors)<.10
    if gait is None and arrived and step>0:break
    if gait is None:
        for side in [next_side,'right' if next_side=='left' else 'left']:
            other='right' if side=='left' else 'left';sign=-1 if side=='left' else 1
            center=foot_center[:2]+delta/max(distance,1e-9)*min(.16,distance) if walking else goal_center[:2]
            target=center+R.from_euler('z',yaw).apply([sign*.13,0,0])[:2]
            if not walking and abs(angle_delta(goal_yaw,yaw))<.1:target=goal_anchors[side][:2]
            end=np.r_[target,.065];move=end-anchors[side]
            end=anchors[side]+move*min(1.,.4/max(np.linalg.norm(move),1e-9))
            try:end=choose_landing(end,yaw,boxes(body.predicted_row if result else reference,spec),side,anchors[other])
            except RuntimeError:continue
            gait=dict(t=t,side=side,other=other,start=anchors[side].copy(),end=end,yaw0=foot_yaws[side],yaw1=yaw);break
        if gait is None:failures.append(dict(step=step,reason='No clear step'));break
    elapsed=t-gait['t'];support=[gait['other']];u=np.clip((elapsed-.2)/.6,0,1);blend=u*u*(3-2*u)
    anchors[gait['side']]=gait['start']*(1-blend)+gait['end']*blend+[0,0,.10*np.sin(np.pi*u)]
    foot_yaws[gait['side']]=gait['yaw0']+angle_delta(gait['yaw1'],gait['yaw0'])*blend
    if elapsed>=1.:
        anchors[gait['side']]=gait['end'];next_side=gait['other'];gait=None;support=['left','right']
    nominal=stance_seed(body,1.0,yaw,anchors)
    for name,index in body.index.items():
        if any(x in name for x in ['shoulder','elbow','clavicle']):nominal[index]=template[index]
    q,report=body.fit({},reference,mode='stand',nominal=nominal,anchors=anchors,foot_yaws=foot_yaws,support_sides=support,initial=previous,continuity=previous,max_nfev=100)
    if not report['accepted']:
        failures.append(dict(step=step,**report));print('REJECT',step,report,flush=True);break
    previous=q.copy();v=body.landmarks(q);predicted=copy.deepcopy(body.predicted_row);predicted['t']=reference['t']+t;predicted['stage']='Coupled transport planning prediction'
    hands,targets=hand_constraints(predicted,spec);v.update(attach_free_hands(body,q,hands,targets));v['tool']=v['right'][:2]
    result.append(dict(row=predicted,visual=v,q=q.tolist(),report=report,anchors={s:a.tolist() for s,a in anchors.items()},foot_yaws=foot_yaws.copy()))
    if step%5==0:print('CARRY',step,round(distance,3),report,flush=True)
if not failures and not arrived:failures.append(dict(reason='Destination not reached within motion horizon'))
report={'passed':not failures,'requires_physics_execution':True,'failures':failures}
if not failures:report['geometry']=validate([r['row'] for r in result],[r['q'] for r in result],spec,subsamples=3)
report['passed']=report['passed'] and report.get('geometry',{}).get('passed',False)
out=folder/'coupled-carry-trial';out.mkdir(exist_ok=True)
(out/'candidate.json').write_text(json.dumps(dict(report=report,frames=result),indent=2))
print('COUPLED_CARRY',report,flush=True)
