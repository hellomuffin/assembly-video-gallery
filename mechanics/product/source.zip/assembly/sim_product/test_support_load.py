"""Physical regressions for grounded and airborne grasp loads."""
import json,tempfile,unittest
from pathlib import Path
import numpy as np
from world import AssemblyWorld
from reference_demo import place


class SupportLoadRegression(unittest.TestCase):
    def test_completed_placement_requires_actual_floor_contact(self):
        from embodied_world import EmbodiedWorld
        from world import World
        from final_motion import require_floor_placement,release_completed_when_supported
        spec=json.loads((Path(__file__).parent/'assets/table.json').read_text())
        spec['parts']=[p for p in spec['parts'] if p['id']=='top'];spec['connectors']=[]
        spec['finish_height']=spec['parts'][0]['size'][2]/2;spec['finish_rotation']=[1,0,0,0]
        with tempfile.TemporaryDirectory() as folder:
            asset=Path(folder)/'block.json';asset.write_text(json.dumps(spec));world=EmbodiedWorld(asset,1)
            world.advance(.5);require_floor_placement(world)
            World.move(world,*world.site('top'));World.grasp(world,'top')
            p,r=world.pose('gripper');World.move(world,p+[0,0,.3],r);world.advance(.4)
            with self.assertRaisesRegex(RuntimeError,'planned floor placement'):require_floor_placement(world)
            with self.assertRaisesRegex(RuntimeError,'planned floor placement'):release_completed_when_supported(world)
            self.assertEqual(world.held,'top')
            self.assertTrue(world.d.eq_active[world.m.equality('grasp_top').id])

    def test_supported_release_accepts_rest_and_rolls_back_airborne_drop(self):
        import mujoco
        from embodied_world import EmbodiedWorld
        from world import World
        spec=json.loads((Path(__file__).parent/'assets/table.json').read_text())
        spec['parts']=[p for p in spec['parts'] if p['id']=='top'];spec['connectors']=[]
        with tempfile.TemporaryDirectory() as folder:
            asset=Path(folder)/'block.json';asset.write_text(json.dumps(spec));world=EmbodiedWorld(asset,1)
            # Exercise actual finite-force furniture dynamics. Human clearance
            # is independently checked by the full task execution/audit.
            World.move(world,*world.site('top'));World.grasp(world,'top');world.advance(.4)
            self.assertTrue(world.release_if_supported());self.assertIsNone(world.held)
            World.grasp(world,'top');p,r=world.pose('gripper');World.move(world,p+[0,0,.3],r);world.advance(.4)
            kind=mujoco.mjtState.mjSTATE_INTEGRATION
            before=np.zeros(mujoco.mj_stateSize(world.m,kind));mujoco.mj_getState(world.m,world.d,before,kind)
            rows,events=len(world.rows),len(world.events)
            world.closure=.83
            self.assertFalse(world.release_if_supported());self.assertEqual(world.held,'top')
            self.assertEqual(world.closure,.83)
            after=np.zeros_like(before);mujoco.mj_getState(world.m,world.d,after,kind)
            np.testing.assert_array_equal(after,before)
            self.assertEqual((len(world.rows),len(world.events)),(rows,events))

    def test_designed_backboard_support_allows_contact_but_not_penetration(self):
        from articulated_body import Body
        from carried_body import CarriedBody
        from task_hands import wrist_offset
        spec=json.loads((Path(__file__).parent/'assets/shelf.json').read_text())
        human=Body(spec);q=human.seed('stand',[-1.5,-1.5],0.)
        row={'parts':{p['id']:[p['assembly_position'],[1,0,0,0]] for p in spec['parts']},
            'held':'shelf_0','fastened':[],'gripper':[(human.point('left_wrist')-wrist_offset('left','board')).tolist(),[1,0,0,0]],
            'tool':[[0,0,1],[1,0,0,0]],'grasp_profile':'board','stage':'Align shelf 0'}
        # Private geometry query of the declared design, not a task execution.
        body=CarriedBody(spec,row,q);body.set(q)
        ids=[body.m.geom('part_'+name).id for name in ['back','shelf_0']]
        pair=body.pair_index[tuple(sorted(ids))]
        self.assertGreater(body.collision_penalties()[0][pair],.0119)
        body.allow_mating_contacts=True
        self.assertLess(body.collision_penalties()[0][pair],1e-8)
        mocap=body.m.body('part_shelf_0').mocapid[0];body.d.mocap_pos[mocap,2]-=.005;body.forward()
        _,hits=body.collision_penalties()
        self.assertTrue(any({a,b}=={'part_back','part_shelf_0'} and distance<-.004 for a,b,distance in hits),hits)

    def test_declared_assembly_does_not_intersect_captive_hardware(self):
        import mujoco
        for asset in ['table','shelf']:
            world=AssemblyWorld(Path(__file__).parent/'assets'/(asset+'.json'),1)
            # Query the declared design directly, without claiming this is an
            # executed task. The previous mounting foot occupied the middle shelf.
            for part in world.parts.values():
                address=world.m.jnt_qposadr[world.m.body_jntadr[world.ids[part['id']]]]
                world.d.qpos[address:address+7]=[*part['assembly_position'],1,0,0,0]
            mujoco.mj_forward(world.m,world.d)
            self.assertGreaterEqual(min((c.dist for c in world.d.contact),default=0.),-1e-8)


    def test_captive_hardware_is_physical_and_starts_above_floor(self):
        import mujoco
        from leg_clearance import boxes
        for asset in ['table','shelf']:
            for seed in [1,7,19]:
                world=AssemblyWorld(Path(__file__).parent/'assets'/(asset+'.json'),seed)
                row={**world.rows[-1],'parts':{n:[p.tolist(),r.as_quat(scalar_first=True).tolist()] for n in world.parts for p,r in [world.pose(n)]}}
                names,centers,rotations,half=boxes(row,world.spec)
                signs=np.array(np.meshgrid([-1,1],[-1,1],[-1,1])).T.reshape(-1,3)
                count=0
                for part in world.parts.values():
                    self.assertAlmostEqual(world.m.body(part['id']).mass[0],part['mass'])
                    position,rotation=world.initial[part['id']]
                    for box in part.get('collision_boxes',[]):
                        count+=1;geom=world.m.geom('attachment_'+box['id']).id;index=names.index(box['id'])
                        np.testing.assert_allclose(world.d.geom_xpos[geom],centers[index],atol=1e-10,rtol=0)
                        np.testing.assert_allclose(world.d.geom_xmat[geom].reshape(3,3),rotations[index],atol=1e-10,rtol=0)
                        np.testing.assert_allclose(world.m.geom_size[geom],half[index],atol=1e-12)
                        corners=position+rotation.apply(np.asarray(box['position'])+signs*np.asarray(box['size'])/2)
                        self.assertGreater(corners[:,2].min(),.0029)
                        self.assertGreater(mujoco.mj_geomDistance(world.m,world.d,0,geom,10.,None),-.001)
                self.assertGreater(count,0)


    def test_visible_fixture_is_physical_and_scatter_avoids_it(self):
        import mujoco
        from leg_clearance import boxes
        for asset in ['table','shelf']:
            for seed in [1,7,19]:
                world=AssemblyWorld(Path(__file__).parent/'assets'/(asset+'.json'),seed)
                row=world.rows[-1];names,centers,rotations,half=boxes(row,world.spec)
                for fixture in world.spec['fixtures']:
                    geom=world.m.geom('fixture_'+fixture['id']).id;index=names.index(fixture['id'])
                    np.testing.assert_allclose(world.d.geom_xpos[geom],centers[index],atol=1e-12)
                    np.testing.assert_allclose(world.d.geom_xmat[geom].reshape(3,3),rotations[index],atol=1e-12)
                    np.testing.assert_allclose(world.m.geom_size[geom],half[index],atol=1e-12)
                    self.assertGreater(world.m.geom_contype[geom],0)
                    for name,(position,rotation) in world.initial.items():
                        extent=(np.abs(rotation.as_matrix())@np.array(world.parts[name]['size'])/2)[:2]
                        self.assertTrue(np.any(np.abs(position[:2]-centers[index,:2])>extent+half[index,:2]+.039))
                        distance=mujoco.mj_geomDistance(world.m,world.d,geom,world.m.geom('shape_'+name).id,10.,None)
                        self.assertGreater(distance,.03)

    def make_world(self,folder):
        spec=json.loads((Path(__file__).parent/'assets/table.json').read_text())
        spec['parts']=[p for p in spec['parts'] if p['id'] in ['top','leg_2']]
        spec['connectors']=[c for c in spec['connectors'] if c['id']=='mount_2']
        asset=Path(folder)/'table.json';asset.write_text(json.dumps(spec))
        return AssemblyWorld(asset,1)

    def test_surface_grasp_alignment_uses_measured_part_pose(self):
        import mujoco
        from scipy.spatial.transform import Rotation as R
        from embodied_world import EmbodiedWorld
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_alignment_compliance.json').read_text())
        with tempfile.TemporaryDirectory() as folder:
            asset=Path(folder)/'shelf.json';asset.write_text(json.dumps(fixture['spec']))
            world=EmbodiedWorld(asset,1)
            # Physics/controller regression only; no human trajectory is
            # claimed by this fixture. The task runner checks the body too.
            world.operator_q=None;world.m.eq_data[:]=fixture['eq_data']
            mujoco.mj_setState(world.m,world.d,np.asarray(fixture['integration_state']),mujoco.mjtState.mjSTATE_INTEGRATION)
            for name,value in fixture['controller'].items():
                if name=='fastened':value=set(value)
                elif name=='target':value=np.asarray(value)
                elif name=='target_rotation':value=R.from_quat(value,scalar_first=True)
                setattr(world,name,value)
            mujoco.mj_forward(world.m,world.d)
            self.assertGreater(world.mating_error('back_left')[0],.0039)
            world.align('back_left')
            distance,angle=world.mating_error('back_left')
            self.assertLess(distance,.002);self.assertLess(np.degrees(angle),.5)
            self.assertLessEqual(np.linalg.norm(world.d.xfrc_applied[world.ids['gripper'],:3]),world.max_force+1e-8)
            self.assertTrue(all(np.all(world.d.xfrc_applied[world.ids[n]]==0) for n in world.parts))

    def test_fastened_leg_stays_rigid_when_it_lifts_the_table(self):
        with tempfile.TemporaryDirectory() as folder:
            world=self.make_world(folder);p,r=world.pose('top')
            offset=np.asarray(world.parts['leg_2']['assembly_position'])-world.parts['top']['assembly_position']
            place(world,'leg_2',p+r.apply(offset),r);world.align('mount_2')
            for _ in range(4):
                tip,axis=world.tool_site('mount_2');world.turn('mount_2',.25,.4,tip,axis)
            world.max_force=160.;world.max_torque=32.
            p,r=world.pose('gripper');world.move(p+[0,0,.5],r,speed=.15);world.advance(1.)
            distance,angle=world.mating_error('mount_2')
            self.assertLess(distance,.001)
            self.assertLess(np.degrees(angle),.5)
            self.assertGreater(world.pose('top')[0][2],.2)
            self.assertLessEqual(np.linalg.norm(world.d.xfrc_applied[world.ids['gripper'],:3]),world.max_force+1e-8)
            self.assertTrue(all(np.all(world.d.xfrc_applied[world.ids[n]]==0) for n in world.parts))

    def test_fastening_grounded_assembly_does_not_lift_it(self):
        with tempfile.TemporaryDirectory() as folder:
            world=self.make_world(folder);p,r=world.pose('top')
            offset=np.array(world.parts['leg_2']['assembly_position'])-world.parts['top']['assembly_position']
            place(world,'leg_2',p+r.apply(offset),r);world.align('mount_2')
            hand=world.pose('gripper')[0];base=world.pose('top')[0];first=len(world.rows)
            for _ in range(4):
                tip,axis=world.tool_site('mount_2');world.turn('mount_2',.25,.4,tip,axis)
            world.advance(1.)
            self.assertIn('mount_2',world.fastened)
            drift=max(np.linalg.norm(np.array(row['gripper'][0])-hand) for row in world.rows[first:])
            self.assertLess(drift,.002)
            self.assertLess(np.linalg.norm(world.pose('top')[0]-base),.002)
            self.assertLess(world.mating_error('mount_2')[0],.002)
            self.assertLess(np.linalg.norm(world.d.xfrc_applied[world.ids['gripper'],:3]),world.max_force+1e-8)
            self.assertTrue(all(np.all(world.d.xfrc_applied[world.ids[n]]==0) for n in world.parts))

    def test_airborne_load_is_supported_then_falls_on_release(self):
        with tempfile.TemporaryDirectory() as folder:
            world=self.make_world(folder);p,r=world.pose('leg_2')
            world.move(p,r);world.grasp('leg_2');world.move(p+[0,0,.5],r);world.advance(.5)
            origin=world.pose('gripper')[0];force,torque=world.gravity_wrench(origin)
            weight=-world.m.opt.gravity;mass=world.parts['leg_2']['mass']
            np.testing.assert_allclose(force,(.2+mass)*weight,atol=1e-9)
            np.testing.assert_allclose(torque,np.cross(world.pose('leg_2')[0]-origin,mass*weight),atol=1e-9)
            height=world.pose('leg_2')[0][2];world.release();world.advance(.5)
            self.assertGreater(height-world.pose('leg_2')[0][2],.3)
            self.assertTrue(all(world.m.body_gravcomp[world.ids[n]]==0 for n in world.parts))


if __name__=='__main__':unittest.main()
