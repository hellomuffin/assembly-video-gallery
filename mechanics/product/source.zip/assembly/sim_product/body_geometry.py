"""Collision hulls derived from the visible native body, in joint coordinates."""
from functools import lru_cache
from pathlib import Path
import sys
import numpy as np
from scipy.spatial import ConvexHull
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'sim_v5'))
from human_surface import Surface,frame


@lru_cache(maxsize=1)
def core_hulls():
    surface=Surface(neck=True,forearms=True);up=np.array([[0,-1,0],[1,0,0],[0,0,1.]])
    hulls={}
    for name in ['pelvis','torso','head']:
        # Collar vertices with a tiny head weight follow the neck/torso blend;
        # treating them as rigid skull vertices creates a fictitious shoulder
        # collision. Use the rigid skull region and the separate neck shape.
        threshold=.5 if name=='head' else .05
        source=surface.used[surface.weights[surface.used,surface.names.index(name)]>threshold]
        a,b=surface.segments[name];old=frame(a,b,[0,1,0])
        points=(surface.rest[source]-a)@old@up.T
        hull=ConvexHull(points)
        hulls[name]=points[hull.vertices]
    return hulls
