"""Transport a complete ZIP in bounded, hash-verified downloadable parts."""
import hashlib
import html
import json
from pathlib import Path

REASSEMBLER = '''"""Put all recording parts and the manifest beside this script, then run it."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'recordings-manifest.json').read_text())
target=root/'recordings.zip'
if target.exists():raise SystemExit('recordings.zip already exists; move it before reassembling.')
pending=root/'recordings.zip.tmp';whole=hashlib.sha256()
try:
 with pending.open('wb') as out:
  for part in manifest['parts']:
   name=part['file']
   if Path(name).name!=name:raise ValueError('Invalid part filename')
   data=(root/name).read_bytes()
   if len(data)!=part['bytes'] or hashlib.sha256(data).hexdigest()!=part['sha256']:raise ValueError('Missing or corrupt part: '+name)
   out.write(data);whole.update(data)
 if whole.hexdigest()!=manifest['sha256']:raise ValueError('Complete archive checksum mismatch')
 pending.rename(target)
except BaseException:
 pending.unlink(missing_ok=True)
 raise
print('Verified recordings.zip; extract it to inspect the complete recordings and source history.')
'''


def stage_recording_downloads(archive, destination, part_bytes=90*1024*1024):
    archive=Path(archive);destination=Path(destination)
    if part_bytes<=0:raise ValueError('part_bytes must be positive')
    parts=[];whole=hashlib.sha256()
    with archive.open('rb') as source:
        while data:=source.read(part_bytes):
            name=f'recordings.zip.{len(parts)+1:03d}'
            (destination/name).write_bytes(data);whole.update(data)
            parts.append(dict(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    manifest=dict(format='concatenated-zip-parts',sha256=whole.hexdigest(),bytes=archive.stat().st_size,parts=parts)
    (destination/'recordings-manifest.json').write_text(json.dumps(manifest,indent=2))
    (destination/'reassemble_recordings.py').write_text(REASSEMBLER)
    links=''.join(f'<li><a href="{html.escape(p["file"])}">Part {i+1} · {p["bytes"]/1024**2:.1f} MiB</a></li>' for i,p in enumerate(parts))
    (destination/'recordings.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Assembly recordings</title><style>body{max-width:760px;margin:40px auto;padding:0 20px;background:#101713;color:#edf2e9;font:17px/1.6 system-ui}a{color:#c7e8a6}code{overflow-wrap:anywhere}</style><a href="./">← Assembly videos</a><h1>Complete simulation recordings</h1><p>The archive includes both layouts, the displayed articulated motion, validation results, frozen execution sources, and every continuation checkpoint used as evidence. It is divided into parts to keep each download below 100 MiB.</p><ol>'''+links+'''</ol><p>Save every part, the <a href="recordings-manifest.json">checksum manifest</a>, and <a href="reassemble_recordings.py">reassembly script</a> in one folder. Run <code>python reassemble_recordings.py</code> there. The script verifies all checksums and creates <code>recordings.zip</code>, which you can extract normally.</p><p>The script uses only the Python standard library and does not download or execute any simulation code.</p></html>''')
    # Old one-file downloads must not remain in the staged/published tree.
    if (destination/'recordings.zip').resolve()!=archive.resolve():
        (destination/'recordings.zip').unlink(missing_ok=True)
    names={p['file'] for p in parts}
    for old in destination.glob('recordings.zip.[0-9][0-9][0-9]'):
        if old.name not in names:old.unlink()
    return manifest


def use_recording_release(destination, certificate_file):
    """Keep the site small while retaining the same verified recording bytes."""
    destination=Path(destination);certificate_file=Path(certificate_file)
    release=json.loads(certificate_file.read_text());assert not release['draft']
    manifest_path=destination/'recordings-manifest.json';manifest=json.loads(manifest_path.read_text())
    assert manifest['sha256']==release['archive_sha256'] and manifest['bytes']==release['archive_bytes']
    remote={p['file']:p for p in release['parts']};assert set(remote)=={p['file'] for p in manifest['parts']}
    page_path=destination/'recordings.html';page=page_path.read_text()
    cache=certificate_file.parent/'recordings-parts';cache.mkdir(exist_ok=True)
    for part in manifest['parts']:
        hosted=remote[part['file']]
        assert hosted['bytes']==part['bytes'] and hosted['sha256']==part['sha256']
        url=hosted['url'];assert url.startswith('https://github.com/') and '/releases/download/' in url
        previous=part.get('url',part['file']);part['url']=url
        page=page.replace('href="'+html.escape(previous,quote=True)+'"','href="'+html.escape(url,quote=True)+'"')
        local=destination/part['file']
        if local.exists():
            assert hashlib.sha256(local.read_bytes()).hexdigest()==part['sha256']
            local.replace(cache/part['file'])
    manifest['release_url']=release['release_url']
    if 'The recording parts are hosted in this project’s GitHub release.' not in page:
        page=page.replace('</ol>','</ol><p>The recording parts are hosted in this project’s GitHub release. The videos remain on the gallery page.</p>',1)
    manifest_path.write_text(json.dumps(manifest,indent=2));page_path.write_text(page)
