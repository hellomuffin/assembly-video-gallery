"""Articulated body for planning *before* executing manipulation.

This is a kinematic feasibility model with MuJoCo collision geometry, not a
free-body dynamics controller. Fixed bone lengths and hinge knees replace
independently placed hip/knee/foot landmarks. A failed target is rejected.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import json
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation as R
from scipy.optimize import least_squares
from scipy.spatial import ConvexHull
from leg_clearance import boxes
from body_geometry import core_hulls
from body_differentials import problem_jacobian,COLLISION_WEIGHT
from contact_geometry import geometry as contact_geometry, crossing_contacts
from task_hands import hand_constraints,wrist_offset

H=Path(__file__).resolve().parent
THIGH=.42127764586582334
SHIN=.3817322959303417
TORSO=.47597060552622367
UPPER_ARM=.22761461690692786
FOREARM=.22631528156948438
HIP_HALF=.110365
SHOULDER_HALF=.1677125


def numbers(v):return ' '.join(str(float(x)) for x in v)


class Body:
    def __init__(self,spec,comfortable=False,scene_pairs=()):
        self.spec=spec;self.comfortable=comfortable
        root=ET.Element('mujoco',model='articulated_operator')
        ET.SubElement(root,'compiler',angle='degree',autolimits='true')
        ET.SubElement(root,'option',timestep='.002',gravity='0 0 -9.81')
        default=ET.SubElement(root,'default')
        ET.SubElement(default,'joint',limited='true',damping='2')
        ET.SubElement(default,'geom',friction='.8 .01 .001',margin='.025',gap='.025',condim='3',solref='.008 1')
        assets=ET.SubElement(root,'asset')
        for name,vertices in core_hulls().items():ET.SubElement(assets,'mesh',name=name+'_skin_hull',vertex=numbers(vertices.ravel()))
        world=ET.SubElement(root,'worldbody')
        ET.SubElement(world,'geom',name='floor',type='plane',size='5 5 .1')
        initial={'parts':{p['id']:[p['assembly_position'],[1,0,0,0]] for p in spec['parts']}}
        self.obstacle_names,_,_,half=boxes(initial,spec)
        for name,size in zip(self.obstacle_names,half):
            obstacle=ET.SubElement(world,'body',name='part_'+name,mocap='true',pos='0 0 -10')
            ET.SubElement(obstacle,'geom',name='part_'+name,type='box',size=numbers(size),mass='1')
        pelvis=ET.SubElement(world,'body',name='pelvis',pos='0 -1 1')
        ET.SubElement(pelvis,'freejoint',name='root')
        ET.SubElement(pelvis,'geom',name='pelvis',type='mesh',mesh='pelvis_skin_hull',mass='9')
        trunk=ET.SubElement(pelvis,'body',name='trunk')
        self._joint(trunk,'spine_yaw',[0,0,1],[-25,25])
        self._joint(trunk,'spine_roll',[0,1,0],[-10,10])
        self._joint(trunk,'spine_pitch',[-1,0,0],[-8,40])
        ET.SubElement(trunk,'geom',name='trunk',type='mesh',mesh='torso_skin_hull',mass='25')
        ET.SubElement(trunk,'site',name='shoulder',pos=numbers([0,0,TORSO]),size='.005')
        neck=ET.SubElement(trunk,'body',name='neck',pos=numbers([0,0,TORSO+.07]))
        self._joint(neck,'neck_yaw',[0,0,1],[-65,65])
        self._joint(neck,'neck_pitch',[-1,0,0],[-40,55])
        self._capsule(neck,'neck',[0,0,0],[0,0,.085],.04,1.)
        ET.SubElement(neck,'geom',name='head',type='mesh',mesh='head_skin_hull',pos='0 0 .165',mass='4.5')
        self._site(neck,'head_center',[0,0,.165])
        self._site(neck,'eye',[0,.08,.190])
        for side,sign in [('left',-1),('right',1)]:
            thigh=ET.SubElement(pelvis,'body',name=side+'_thigh',pos=numbers([sign*HIP_HALF,0,0]))
            self._joint(thigh,side+'_hip_yaw',[0,0,-sign],[-12,25])
            self._joint(thigh,side+'_hip_abduction',[0,-sign,0],[-8,22])
            self._joint(thigh,side+'_hip_flexion',[1,0,0],[-25,120])
            self._capsule(thigh,side+'_thigh',[0,0,0],[0,0,-THIGH],.095,7.)
            self._site(thigh,side+'_hip',[0,0,0])
            shin=ET.SubElement(thigh,'body',name=side+'_shin',pos=numbers([0,0,-THIGH]))
            self._joint(shin,side+'_knee',[1,0,0],[-160,0])
            self._capsule(shin,side+'_shin',[0,0,0],[0,0,-SHIN],.065,3.5)
            self._site(shin,side+'_knee',[0,0,0])
            foot=ET.SubElement(shin,'body',name=side+'_foot',pos=numbers([0,0,-SHIN]))
            self._joint(foot,side+'_ankle_pitch',[1,0,0],[-60,45])
            self._joint(foot,side+'_ankle_roll',[0,1,0],[-20,20])
            ET.SubElement(foot,'geom',name=side+'_shoe',type='box',pos='0 .04 -.025',size='.065 .13 .04',mass='1')
            self._site(foot,side+'_ankle',[0,0,0])
            clavicle=ET.SubElement(trunk,'body',name=side+'_clavicle',pos=numbers([sign*.026555,.05482,TORSO-.005445]))
            self._joint(clavicle,side+'_clavicle_protraction',[0,0,sign],[-15,30])
            self._joint(clavicle,side+'_clavicle_elevation',[0,-sign,0],[-10,25])
            shoulder_offset=[sign*(SHOULDER_HALF-.026555),-.05482,.005445]
            self._capsule(clavicle,side+'_clavicle',[0,0,0],shoulder_offset,.018,.5)
            arm=ET.SubElement(clavicle,'body',name=side+'_upperarm',pos=numbers(shoulder_offset))
            self._joint(arm,side+'_shoulder_yaw',[0,0,-sign],[-90,90])
            self._joint(arm,side+'_shoulder_abduction',[0,-sign,0],[-15,100])
            self._joint(arm,side+'_shoulder_flexion',[1,0,0],[-50,160])
            self._capsule(arm,side+'_upperarm',[0,0,0],[0,0,-UPPER_ARM],.039,2.)
            self._site(arm,side+'_shoulder',[0,0,0])
            forearm=ET.SubElement(arm,'body',name=side+'_forearm',pos=numbers([0,0,-UPPER_ARM]))
            self._joint(forearm,side+'_elbow',[1,0,0],[0,150])
            self._capsule(forearm,side+'_forearm',[0,0,0],[0,0,-FOREARM],.027,1.5)
            self._site(forearm,side+'_wrist',[0,0,-FOREARM])
            self._site(forearm,side+'_elbow',[0,0,0])
            if side=='right':
                # The idle driver follows the native forearm, exactly as in
                # attach_free_hands. Its bit must clear carried panels too.
                grip=R.from_euler('x',np.pi/2)
                offset=np.array([0,0,-FOREARM])-grip.apply(wrist_offset('right','tool'))
                for name,a,b,radius in [('handle',[-.07,0,0],[.07,0,0],.017),('bit',[0,-.02,0],[0,-.14,0],.003)]:
                    self._capsule(forearm,'free_driver_'+name,offset+grip.apply(a),offset+grip.apply(b),radius,0.)
        contact=ET.SubElement(root,'contact')
        for a,b in scene_pairs:
            # Carried and scene boxes are mocap bodies in this query model.
            # MuJoCo's automatic static-body filtering omits their mutual
            # contacts, including the floor, unless pairs are explicit.
            ET.SubElement(contact,'pair',geom1=a,geom2=b,margin='.025',gap='.025')
        # These are directly connected anatomical volumes, not scene exceptions.
        for side in ['left','right']:
            ET.SubElement(contact,'exclude',body1='trunk',body2=side+'_thigh')
            ET.SubElement(contact,'exclude',body1='trunk',body2=side+'_upperarm')
        self.xml=ET.tostring(root,encoding='unicode')
        self.m=mujoco.MjModel.from_xml_string(self.xml)
        self.explicit_scene_contacts=bool(scene_pairs)
        self.d=mujoco.MjData(self.m)
        self.joints=[self.m.joint(i).name for i in range(1,self.m.njnt)]
        self.index={name:6+i for i,name in enumerate(self.joints)}
        self.working_posture_upper={4:np.radians(20),self.index['spine_pitch']:np.radians(35)}
        # World yaw is a free orientation, not an anatomical joint. Keep it
        # continuous through repeated walking turns without an artificial stop.
        self.bounds=(np.r_[[-3,-3,.17,-np.inf,np.radians(-10),np.radians(-8)],self.m.jnt_range[1:,0]],np.r_[[3,3,1.15,np.inf,np.radians(45),np.radians(8)],self.m.jnt_range[1:,1]])
        self.root_id=self.m.body('pelvis').id
        self.site_ids={self.m.site(i).name:i for i in range(self.m.nsite)}
        self.human_geoms=np.array([i for i in range(self.m.ngeom) if self.m.geom_bodyid[i]>=self.root_id])
        self.m.geom_contype[:]=1;self.m.geom_conaffinity[:]=2
        self.m.geom_contype[self.human_geoms]=2;self.m.geom_conaffinity[self.human_geoms]=3
        self.geom_names=[self.m.geom(i).name for i in range(self.m.ngeom)]
        self.free_tool_geoms=np.array([self.m.geom('free_driver_'+name).id for name in ['handle','bit']])
        self.m.geom_contype[self.free_tool_geoms]=0;self.m.geom_conaffinity[self.free_tool_geoms]=0
        self.pairs=[(a,b) for a in self.human_geoms for b in range(a) if self.m.geom_bodyid[a]!=self.m.geom_bodyid[b]]
        self.pair_index={tuple(sorted(pair)):i for i,pair in enumerate(self.pairs)}
        self.capsule_scene_pairs=np.array([(int(a),b) for a in self.human_geoms if self.m.geom_type[a]==mujoco.mjtGeom.mjGEOM_CAPSULE for b in range(self.m.ngeom) if self.m.geom_bodyid[b]<self.root_id and self.m.geom_type[b]==mujoco.mjtGeom.mjGEOM_BOX],dtype=int).reshape(-1,2)
        self.nvars=len(self.index)+6

    @staticmethod
    def _joint(body,name,axis,limits):ET.SubElement(body,'joint',name=name,type='hinge',axis=numbers(axis),range=numbers(limits))
    @staticmethod
    def _capsule(body,name,a,b,radius,mass):ET.SubElement(body,'geom',name=name,type='capsule',fromto=numbers([*a,*b]),size=str(radius),mass=str(mass))
    @staticmethod
    def _site(body,name,pos):ET.SubElement(body,'site',name=name,pos=numbers(pos),size='.005')

    def obstacles(self,row):
        self.row=row
        free_tool=not row.get('tool_parked') and not getattr(self,'bimanual',False) and 'right' not in hand_constraints(row,self.spec)[1]
        # Furniture is type 1, carried furniture type 4, human type 2.
        # This attachment checks the tool against furniture and the floor;
        # its intentional contact with its own hand/forearm is not a clash.
        self.m.geom_contype[self.free_tool_geoms]=8 if free_tool else 0
        self.m.geom_conaffinity[self.free_tool_geoms]=5 if free_tool else 0
        names,centers,rotations,_=boxes(row,self.spec)
        for name,p,r in zip(names,centers,rotations):
            i=self.m.body('part_'+name).mocapid[0]
            self.d.mocap_pos[i]=p;self.d.mocap_quat[i]=R.from_matrix(r).as_quat(scalar_first=True)

    def set(self,q):
        self.d.qpos[:3]=q[:3];self.d.qpos[3:7]=(R.from_euler('z',q[3])*R.from_euler('y',q[5])*R.from_euler('x',-q[4])).as_quat(scalar_first=True)
        self.d.qpos[7:]=q[6:];self.forward()

    def forward(self):
        # This model is a geometric query, not the furniture dynamics world.
        # Kinematics, mass centers and contacts provide every value consumed by
        # the body solver. Assembling/solving forces here is unused work (and
        # invalid for explicit static/static scene pairs).
        mujoco.mj_kinematics(self.m,self.d)
        mujoco.mj_comPos(self.m,self.d)
        mujoco.mj_collision(self.m,self.d)

    def point(self,name):return self.d.site_xpos[self.site_ids[name]].copy()

    def seed(self,mode='stand',xy=(0,0),yaw=0):
        q=np.zeros(self.nvars);q[:2]=xy;q[3]=yaw
        hip,knee,ankle,spine=(10,-20,10,8) if mode=='stand' else (100,-135,45,35) if mode=='squat' else (65,-155,-60,20)
        for side in ['left','right']:
            for name,value in [('hip_flexion',hip),('knee',knee),('ankle_pitch',ankle),('hip_abduction',4),('shoulder_abduction',12),('shoulder_flexion',15),('elbow',55)]:q[self.index[side+'_'+name]]=np.radians(value)
        q[4]=np.radians(10 if mode=='squat' else 0)
        q[self.index['spine_pitch']]=np.radians(spine)
        q[2]=.065+THIGH*np.cos(np.radians(hip)-q[4])+SHIN*np.cos(np.radians(hip+knee)-q[4])
        if mode=='kneel':q[2]=.075+THIGH*np.cos(np.radians(hip))
        self.set(q)
        return q

    def contact_constraint(self,contact,clearance=.012):
        a,b=sorted(contact.geom);index=self.pair_index.get((a,b))
        if index is None or not self.collision_pair_enabled(a,b):return None
        support=a==0 and self.geom_names[b].endswith(('_shoe','_shin'))
        return index,0. if support else clearance

    def collision_contacts(self):
        yield from self.d.contact
        a,b=self.capsule_scene_pairs.T
        enabled=((self.m.geom_contype[a]&self.m.geom_conaffinity[b]) | (self.m.geom_contype[b]&self.m.geom_conaffinity[a]))!=0
        yield from crossing_contacts(self.m,self.d,self.capsule_scene_pairs[enabled])

    def collision_pair_enabled(self,a,b):
        return bool((self.m.geom_contype[a]&self.m.geom_conaffinity[b]) or (self.m.geom_contype[b]&self.m.geom_conaffinity[a]))

    def collision_penalties(self,clearance=.012):
        residual=np.zeros(len(self.pairs));hits=[]
        for contact in self.collision_contacts():
            constraint=self.contact_constraint(contact,clearance)
            if constraint is None:continue
            index,margin=constraint;distance,a,_,b,_,_=contact_geometry(self.m,self.d,contact);residual[index]=max(residual[index],margin-distance)
            if distance<-.001:hits.append((self.geom_names[a],self.geom_names[b],distance))
        return residual,hits

    def load_center(self):
        mass=float(self.m.body_subtreemass[self.root_id]);moment=mass*self.d.subtree_com[self.root_id]
        row=getattr(self,'row',{})
        held=row.get('held')
        if held:
            group={held}
            while True:
                before=len(group)
                for key in row.get('fastened',[]):
                    c=next(c for c in self.spec['connectors'] if c['id']==key)
                    if c['a'] in group or c['b'] in group:group.update([c['a'],c['b']])
                if before==len(group):break
            for part in self.spec['parts']:
                if part['id'] in group:
                    load=part['mass'];mass+=load;moment+=load*np.array(row['parts'][part['id']][0])
        return moment/mass

    def support_gap(self):
        points=[]
        for contact in self.d.contact:
            a,b=sorted(contact.geom)
            if a!=0 or contact.dist>.001:continue
            name=self.geom_names[b]
            if name.endswith('_shoe'):points.append(contact.pos[:2])
            elif name.endswith(('_thigh','_shin')):
                # A declared 15 mm contact patch at a supported knee.
                points.extend(contact.pos[:2]+delta for delta in [[.015,0],[-.015,0],[0,.015],[0,-.015]])
        if len(points)<3:return -1.
        try:
            hull=ConvexHull(np.array(points))
        except Exception:return -1.
        return float(np.min(-(hull.equations[:,:2]@self.load_center()[:2]+hull.equations[:,2])))

    def landmarks(self,q):
        q=np.asarray(q,dtype=float)
        self.set(q)
        legs={str(sign):[self.point(side+'_'+joint).tolist() for joint in ['hip','knee','ankle']] for side,sign in [('left',-1),('right',1)]}
        arms={side:[self.point(side+'_'+joint).tolist() for joint in ['shoulder','elbow','wrist']] for side in ['left','right']}
        forward=R.from_euler('z',q[3]).apply([0,1,0])
        down=np.array([[0,1,0],[1,0,0],[0,0,-1.]])
        up=np.array([[0,-1,0],[1,0,0],[0,0,1.]])
        rotation=lambda name:self.d.xmat[self.m.body(name).id].reshape(3,3)
        clavicles={side:[self.d.xpos[self.m.body(side+'_clavicle').id].tolist(),self.point(side+'_shoulder').tolist()] for side in ['left','right']}
        frames={'pelvis':(rotation('pelvis')@up).tolist(),'torso':(rotation('trunk')@up).tolist(),'head':(rotation('neck')@up).tolist()}
        for side,suffix in [('left','L'),('right','R')]:
            offset=np.array([(-1 if side=='left' else 1)*(SHOULDER_HALF-.026555),-.05482,.005445]);z=offset/np.linalg.norm(offset);x=np.array([0,1,0])-z*z[1];x/=np.linalg.norm(x);rest=np.column_stack([x,np.cross(z,x),z])
            frames['clavicle.'+suffix]=(rotation(side+'_clavicle')@rest).tolist()
            for bone,body in [('arm','upperarm'),('forearm','forearm'),('thigh','thigh'),('shin','shin')]:frames[bone+'.'+suffix]=(rotation(side+'_'+body)@down).tolist()
        eye=self.point('eye');head_forward=rotation('neck')[:,1]
        camera=np.column_stack([rotation('neck')[:,0],rotation('neck')[:,2],-head_forward])
        return dict(clavicles=clavicles,segment_frames=frames,eye=eye.tolist(),look=(eye+head_forward).tolist(),head=self.point('head_center').tolist(),neck_base=self.d.xpos[self.m.body('neck').id].tolist(),camera_quaternion=R.from_matrix(camera).as_quat(scalar_first=True).tolist(),hip=self.d.xpos[self.root_id].tolist(),shoulder=self.point('shoulder').tolist(),legs=legs,arms=arms,back=(-forward).tolist(),joint_angles=dict(zip(self.joints,np.degrees(q[6:]).tolist())),q=q.tolist(),foot_rotation={str(sign):self.d.xmat[self.m.body(side+'_foot').id].reshape(3,3).tolist() for side,sign in [('left',-1),('right',1)]},center_of_mass=self.d.subtree_com[self.root_id].tolist())

    def dynamic_targets(self):return {}

    def working_posture_valid(self,q):
        return all(q[index]<=limit+1e-7 for index,limit in self.working_posture_upper.items())

    def surface_checker(self):
        if not hasattr(self,'_surface_checker'):
            from surface_constraints import SurfaceConstraints
            self._surface_checker=SurfaceConstraints()
        return self._surface_checker

    def fit(self,targets,row,mode='squat',xy=None,yaw=0,initial=None,max_nfev=150,nominal=None,anchors=None,support_sides=None,continuity=None,foot_yaws=None,analytic=True,motion_dt=None,balance_center=None,surface=True,posture_weight=1.):
        self.obstacles(row)
        focus=np.mean(list(targets.values()),axis=0) if targets else np.array([0,-.5,1.])
        if xy is None:xy=focus[:2]-R.from_euler('z',yaw).apply([0,.42,0])[:2]
        nominal=self.seed(mode,xy,yaw) if nominal is None else nominal.copy();q0=nominal if initial is None else initial.copy()
        self.set(nominal)
        if not targets or row.get('stage','').startswith(('Carry ','Walk ','Approach ','Stand ')):
            if row.get('stage','').startswith(('Carry ','Walk ','Approach ','Stand ')) or not row.get('held'):
                focus=self.point('eye')+R.from_euler('z',nominal[3]).apply([0,2.,-.2])
            else:
                focus=np.mean([self.point('left_wrist'),*self.dynamic_targets().values()],axis=0)
        anchors=anchors or {side:self.point(side+('_knee' if mode=='kneel' else '_ankle')) for side in ['left','right']}
        support_sides=support_sides or ['left','right']
        foot_yaws=foot_yaws or {side:nominal[3] for side in ['left','right']}
        foot_rotations={side:R.from_euler('z',foot_yaws[side]).as_matrix() for side in foot_yaws}
        support_vertices=[]
        for side in support_sides:
            rotation=foot_rotations[side]
            for x in [-.065,.065]:
                for y in [-.09,.17]:support_vertices.append((anchors[side]+rotation@np.array([x,y,0]))[:2])
        support_equations=ConvexHull(np.array(support_vertices)).equations
        weights=np.ones(self.nvars)*.7;weights[:2]=2.;weights[2]=1.5;weights[3]=3.;weights[4:6]=2.
        for name,i in self.index.items():
            if any(key in name for key in ['abduction','hip_yaw','spine_roll','spine_yaw']):weights[i]=3.
            elif any(key in name for key in ['hip_flexion','knee','ankle_pitch','spine_pitch']):weights[i]=2.
        posture_weight=np.broadcast_to(np.asarray(posture_weight,float),weights.shape)
        if not np.isfinite(posture_weight).all() or np.any(posture_weight<=0):raise ValueError('Posture weights must be finite and positive')
        weights*=posture_weight
        def residual(q):
            self.set(q);out=[]
            current_targets={**targets,**self.dynamic_targets()}
            # Task contact must dominate the soft posture preference. With a
            # weaker weight the solver can settle in a straight-arm local
            # minimum several millimeters away from a reachable handle.
            for side,target in current_targets.items():out.extend((self.point(side+'_wrist')-target)*2000)
            for side,anchor in anchors.items():
                out.extend((self.point(side+('_knee' if mode=='kneel' else '_ankle'))-anchor)*20000)
                if mode!='kneel':
                    foot=self.d.xmat[self.m.body(side+'_foot').id].reshape(3,3)
                    out.extend(((foot-foot_rotations[side])*20000).ravel())
            head_forward=self.d.xmat[self.m.body('neck').id].reshape(3,3)[:,1]
            gaze=focus-self.point('eye');gaze/=max(np.linalg.norm(gaze),1e-9)
            out.extend((head_forward-gaze)*2.)
            support=np.mean([anchors[side] for side in support_sides],axis=0) if balance_center is None else balance_center
            # Prefer the physical mass center over the contact support region.
            center=self.load_center()
            out.extend((center[:2]-support[:2])*(25 if balance_center is None else 100))
            out.extend(np.maximum(support_equations[:,:2]@center[:2]+support_equations[:,2]+.025,0)*600)
            # Pose tracking must not trade away the accepted 5 mm support
            # margin. Use a separate, high-priority constraint with a 1 mm
            # numerical reserve, while retaining the wider comfort preference.
            out.extend(np.maximum(support_equations[:,:2]@center[:2]+support_equations[:,2]+.006,0)*20000)
            out.extend((q-nominal)*weights)
            if continuity is not None:out.extend((q-continuity)*2.)
            out.extend(self.collision_penalties()[0]*COLLISION_WEIGHT)
            return np.array(out)
        def jacobian(q):return problem_jacobian(self,q,targets,anchors,foot_rotations,mode,focus,support_equations,weights,continuity,balance_weight=25 if balance_center is None else 100)
        self.last_problem=(residual,jacobian)
        lower,upper=(a.copy() for a in self.bounds)
        if self.comfortable:
            # Working-posture limits, separate from anatomical joint ranges.
            # Otherwise a low wrist target can spend both the pelvis and spine
            # flexion ranges and fold the trunk almost horizontal. The task
            # planner must find a crouch/stance that reaches without that fold.
            for index,limit in self.working_posture_upper.items():upper[index]=min(upper[index],limit)
        if motion_dt is not None:
            if continuity is None or motion_dt<=0:raise ValueError('Motion bounds require a preceding pose and positive time')
            step=np.r_[np.full(3,.8),np.full(self.nvars-3,np.pi/2)]*motion_dt
            lower=np.maximum(lower,continuity-step);upper=np.minimum(upper,continuity+step)
        start=np.clip(q0,lower+1e-8,upper-1e-8)
        options=dict(bounds=(lower,upper),max_nfev=max_nfev,ftol=1e-6,xtol=1e-6,gtol=1e-5)
        numerical_fallback=False
        try:result=least_squares(residual,start,jac=jacobian if analytic else '3-point',**options)
        except np.linalg.LinAlgError:
            if not analytic or not np.isfinite(residual(start)).all():raise
            # Re-evaluate the same bounded problem with independent numerical
            # derivatives if a contact Jacobian factorization breaks down.
            # All geometric and acceptance constraints remain unchanged.
            numerical_fallback=True
            result=least_squares(residual,start,jac='3-point',**options)
        surface_hits={};surface_rounds=0
        self.set(result.x)
        base_targets={**targets,**self.dynamic_targets()};base_pen,base_hits=self.collision_penalties()
        base_feasible=(max((np.linalg.norm(self.point(s+'_wrist')-t) for s,t in base_targets.items()),default=0.)<.008
            and max(np.linalg.norm(self.point(s+('_knee' if mode=='kneel' else '_ankle'))-a) for s,a in anchors.items())<.008
            and not base_hits and base_pen.max()<.004 and self.support_gap()>=.005
            and np.min(-(support_equations[:,:2]@self.load_center()[:2]+support_equations[:,2]))>=.005)
        # An infeasible rigid-body candidate should be replanned, not spend
        # time refining its skin. Surface refinement preserves a feasible
        # task/contact solution and removes the remaining blend intersections.
        if surface and base_feasible:
            result.x,surface_hits,extra,surface_rounds=self.surface_checker().repair(self,result.x,residual,jacobian,(lower,upper),max_nfev=min(max_nfev,100))
            result.nfev+=extra;values=residual(result.x);result.cost=float(values@values/2)
        self.set(result.x);current_targets={**targets,**self.dynamic_targets()};errors={side:float(np.linalg.norm(self.point(side+'_wrist')-target)) for side,target in current_targets.items()};pen,hits=self.collision_penalties()
        anchor_error=max(np.linalg.norm(self.point(side+('_knee' if mode=='kneel' else '_ankle'))-a) for side,a in anchors.items())
        support=self.support_gap()
        intended_support=float(np.min(-(support_equations[:,:2]@self.load_center()[:2]+support_equations[:,2])))
        accepted=support>=.005 and intended_support>=.005 and max(errors.values(),default=0.)<.008 and anchor_error<.008 and not hits and pen.max()<.004 and not surface_hits and (not surface or base_feasible)
        return result.x,dict(accepted=bool(accepted),mode=mode,wrist_error_m=errors,anchor_error_m=float(anchor_error),support_margin_m=float(support),intended_support_margin_m=intended_support,max_clearance_violation_m=float(pen.max()),contacts=hits,nfev=result.nfev,cost=float(result.cost),numerical_jacobian_fallback=numerical_fallback,surface_intersections=surface_hits,surface_repair_iterations=surface_rounds,surface_checked=bool(surface and base_feasible))
