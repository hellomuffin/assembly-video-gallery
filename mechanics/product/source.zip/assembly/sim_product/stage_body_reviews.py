"""Stage source-bound normal-speed handling reviews beside the full task videos."""
import hashlib,json,shutil
from pathlib import Path


def stage_body_reviews(output,destination):
    output=Path(output);destination=Path(destination)
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    inputs=json.loads((output/'body-review-inputs.json').read_text())
    assert {item['furniture'] for item in inputs}=={'table','shelf'} and len(inputs)==2
    records=[]
    for item in inputs:
        name=item['furniture'];data=output/(name+'_1');folder=Path(item['directory'])
        file=name+'-final-handling.mp4';video=folder/file;sidecar=video.with_suffix('.json')
        original=json.loads(sidecar.read_text());body_sha=sha(data/'body-validation.json')
        assert original['full_source_task_accepted'] and original['playback_speed']==1
        assert original['trajectory_sha256']==sha(data/'trajectory.json')
        assert original['file_sha256']==sha(video)
        indices=original['indices'];assert indices==list(range(indices[0],indices[-1]+1))
        result=json.loads((data/'result.json').read_text());assert result['passed'] and result['full_task_complete']
        if original['body_validation_sha256']!=body_sha:
            proof=json.loads((folder/'current-revalidation.json').read_text());assert proof['passed']
            matches=[r for r in proof['videos'] if r['file']==file];assert len(matches)==1
            r=matches[0];assert r['current_body_validation_sha256']==body_sha
            assert r['original_sidecar_sha256']==sha(sidecar) and r['video_sha256']==original['file_sha256']
            assert r['trajectory_sha256']==original['trajectory_sha256']
        shutil.copy2(video,destination/file)
        records.append(dict(furniture=name,file=file,playback_speed=1,duration_seconds=len(indices)/25,
            indices=indices,sha256=original['file_sha256'],trajectory_sha256=original['trajectory_sha256'],
            body_validation_sha256=body_sha,original_body_validation_sha256=original['body_validation_sha256']))
    (destination/'body-reviews.json').write_text(json.dumps({'scope':'Normal-speed final handling excerpts from the independently accepted complete task recordings.','videos':records},indent=2))
