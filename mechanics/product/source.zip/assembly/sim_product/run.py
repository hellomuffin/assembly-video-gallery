"""A known-correct demonstration policy, distinct from the shared executor."""
from pathlib import Path
import json,sys,time,hashlib
import numpy as np
from world import World,R
H=Path(__file__).resolve().parent
def run(name,seed=1):
 out=H.parent/'outputs/product_v1'/f'{name}_{seed}';start=time.time();w=World(H/'assets'/f'{name}.json',seed)
 assembled={w.spec['base']};remaining=list(w.connectors)
 while remaining:
  key=next(k for k in remaining if w.connectors[k]['a'] in assembled);c=w.connectors[key]
  if c['b'] not in assembled:
   w.pickup(c['b']);p,r=w.pose(c['a'])
   offset=np.array(w.parts[c['b']]['assembly_position'])-w.parts[c['a']]['assembly_position']
   w.carry(c['b'],p+r.apply(offset),r)
  if w.held==c['b']:
   try:w.align(key)
   except Exception:
    print('FAILED_ALIGNMENT',key,w.mating_error(key),w.pose(c['b'])[0],w.target,flush=True);w.save(out);raise
  print('ALIGN',name,key,w.mating_error(key),flush=True)
  w.fasten(key);assert key in w.fastened
  w.release();w.advance(.4);assembled.add(c['b']);remaining.remove(key)
 w.finish();w.save(out)
 errs={k:float(w.mating_error(k)[0]) for k in w.connectors}
 desired=R.from_quat(w.spec['finish_rotation'],scalar_first=True)
 current=w.pose(w.spec['base'])[1]
 zmin=min(w.pose(n)[0][2]-abs(w.pose(n)[1].as_matrix()[2])@np.array(w.parts[n]['size'])/2 for n in w.parts)
 checks={'all_fastened':len(w.fastened)==len(w.connectors),'all_hands_released':w.held is None,
 'upright_tilt_under_2deg':bool(np.dot(current.apply(desired.inv().apply([0,0,1])),[0,0,1])>np.cos(np.radians(2))),
 'no_floor_penetration_over_2mm':bool(zmin>-.002),'connections_aligned':max(errs.values())<.006,
 'gravity_enabled':bool(np.allclose(w.m.opt.gravity,[0,0,-9.81]))}
 report={'passed':all(checks.values()),'checks':checks,'sim_seconds':w.d.time,'wall_seconds':time.time()-start,'alignment_m':errs,'final_floor_clearance_m':zmin,
 'source_hashes':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [H/'world.py',H/'run.py',H/'assets'/f'{name}.json',H.parent/'sim_shared/engine.py']},
 'scope':'Original furniture with supplied assembly metadata; assisted surface grasps and ideal ratchet/screw groups. Kinematic hands and operator; not exact finger contact or balanced human dynamics.'}
 (out/'result.json').write_text(json.dumps(report,indent=2));(out/'asset.json').write_text(json.dumps(w.spec,indent=2));print(json.dumps(report),flush=True)
 assert report['passed']
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 1)
