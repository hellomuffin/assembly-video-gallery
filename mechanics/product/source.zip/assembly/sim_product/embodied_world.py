"""Assembly execution with a body-driven manipulation controller.

The furniture is still advanced by the finite-force physics executor. Planned
body poses generate transport commands; recorded poses are then solved against
the *actual* gripper and furniture state before they can be accepted.
"""
import copy,json
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation as R
from world import World,mixrot
from articulated_body import Body
from carried_body import CarriedBody
from task_hands import hand_constraints,attach_free_hands,wrist_offset
from task_stance import plan_stance
from plan_body_motion import stance_seed,angle_delta
from foot_contacts import choose_landing,boxes,plan_swing,swing_pose,choose_step
from grasp_sites import candidates as grasp_candidates,select as select_grasp
from walk_route import plan_route


class EmbodiedWorld(World):
    def __init__(self,asset,seed=1):
        self.second_grasp=None;self.finish_grasp=None
        self.segment_support=None;self.second_hand_blend=None;self.walk_target=None;self.last_body_time=None;self.rejected_rollouts=[];self._progress_frame=0;self.selected_grasps={};self.active_grasp_part=None;self.operator=None;self.operator_q=None;self.contact_segment=None;self.contact_nominal=None;self.reaching=False
        super().__init__(asset,seed)
        for part in self.parts.values():part['grasp_candidates']=grasp_candidates(part)
        self.operator=Body(self.spec,comfortable=True);self.anchors=None;self.foot_yaws=None;self.operator_yaw=0.

    def site(self,part):
        if self.finish_grasp is not None and self.finish_grasp['part']==part:
            grasp=self.finish_grasp;p,r=self.pose(part)
            return p+r.apply(grasp['position']),r*R.from_quat(grasp['rotation'],scalar_first=True)
        if part not in self.selected_grasps:return super().site(part)
        grasp=self.parts[part]['grasp_candidates'][self.selected_grasps[part]];p,r=self.pose(part)
        return p+r.apply(grasp['position']),r*R.from_quat(grasp['rotation'],scalar_first=True)

    def current_row(self):
        row=copy.deepcopy(self.rows[-1])
        row.update(parts={n:[p.tolist(),r.as_quat(scalar_first=True).tolist()] for n in self.parts for p,r in [self.pose(n)]},gripper=[self.pose('gripper')[0].tolist(),self.pose('gripper')[1].as_quat(scalar_first=True).tolist()],held=self.held,fastened=sorted(self.fastened),tool=copy.deepcopy(self.tool),stage=self.stage,tool_parked=self.tool_parked,two_hands=self.two_hands,closure=self.closure,grasp_profile=self.grasp_profile,t=float(self.d.time))
        row.update(stroke=self.stroke,connector=self.connector,tool_engaged=self.tool_engaged,tool_control=self.tool_control,engagement=self.engagement.copy())
        if self.second_hand_blend is None:row.pop('second_hand_blend',None)
        else:row['second_hand_blend']=copy.deepcopy(self.second_hand_blend)
        if self.second_grasp is not None:row['second_grasp']=copy.deepcopy(self.second_grasp)
        return row

    def advance(self,seconds):
        start=len(self.rows);super().advance(seconds)
        if self.operator_q is None:return
        for row_index in range(start,len(self.rows)):
            row=self.rows[row_index]
            if self.second_grasp is not None:row['second_grasp']=copy.deepcopy(self.second_grasp)
            if self.walk_target is not None:row['walk_target']=copy.deepcopy(self.walk_target)
            if self.active_grasp_part is not None:row['grasp_selection']={'part':self.active_grasp_part,'candidate':self.selected_grasps[self.active_grasp_part]}
            if self.finish_grasp is not None:
                row['finish_grasp']=copy.deepcopy(self.finish_grasp)
                if self.active_grasp_part==self.finish_grasp['part']:row['grasp_selection']={'part':self.active_grasp_part,'kind':'paired_finish','candidate':self.finish_grasp['candidate']}
            if self.second_hand_blend is not None:row['second_hand_blend']=copy.deepcopy(self.second_hand_blend)
            hands,targets=hand_constraints(row,self.spec)
            if self.reaching:
                p,r=row['gripper'];targets['left']=np.array(p)+R.from_quat(r,scalar_first=True).apply(wrist_offset('left',row['grasp_profile']))
            anchors=self.anchors;yaws=self.foot_yaws
            if self.contact_segment is not None:
                a,b,t0,t1,aa,bb,ya,yb=self.contact_segment;u=np.clip((row['t']-t0)/max(t1-t0,1e-8),0,1)
                nominal=a*(1-u)+b*u
                if self.contact_nominal is not None:nominal=self.contact_nominal.copy()
                anchors={s:aa[s]*(1-u)+bb[s]*u for s in aa}
                yaws={s:ya[s]+angle_delta(yb[s],ya[s])*u for s in ya}
            else:
                height=float(np.mean([v[2] for v in targets.values()])) if targets else 1.
                nominal=stance_seed(self.operator,height,self.operator_yaw,anchors)
            support=[s for s,a in anchors.items() if a[2]<.066]
            if self.segment_support is not None:
                sides,defer=self.segment_support
                if not defer or row['t']>=self.contact_segment[3]-1e-7:support=sides
            if not support:raise RuntimeError('No supporting foot during physics execution')
            self.operator.obstacles(row)
            balance_center=None
            if self.contact_segment is not None:
                self.operator.set(nominal);balance_center=self.operator.load_center().copy()
            # A validated commanded pose must remain the tracking reference.
            # The ordinary stance prior is deliberately weak for free IK, but
            # using it for execution can leave the hips almost stationary
            # while the command calls for a substantial coordinated crouch.
            posture_weight=20. if self.contact_segment is not None else 1.
            self.operator.set(self.operator_q)
            wrist_errors={s:float(np.linalg.norm(self.operator.point(s+'_wrist')-target)) for s,target in targets.items()}
            penalties,hits=self.operator.collision_penalties()
            stationary=self.contact_segment is None and max(wrist_errors.values(),default=0.)<.0005 and not hits and penalties.max()<.004 and self.operator.support_gap()>=.005
            if self.operator.comfortable and not self.operator.working_posture_valid(self.operator_q):stationary=False
            if stationary and self.operator.surface_checker().contacts(self.operator,self.operator_q)[1]:stationary=False
            planned=False
            if self.contact_segment is not None:
                # Keep a planned pose when it already satisfies the actual
                # scene. Re-solving every feasible frame can drift along the
                # redundant IK manifold while the carried object follows the
                # original trajectory, eventually separating body and load.
                from validate_body_motion import validate_pose
                dt=row['t']-self.last_body_time
                step=np.r_[np.full(3,.8),np.full(self.operator.nvars-3,np.pi/2)]*dt
                sample={**row,'body_anchors':anchors,'body_foot_yaws':yaws,'body_support':support}
                if np.all(np.abs(nominal-self.operator_q)<=step+1e-9) and not validate_pose(self.operator,nominal,sample):
                    planned=not self.operator.surface_checker().contacts(self.operator,nominal)[1]
                if planned:
                    q=nominal.copy();self.operator.set(q)
                    errors={s:float(np.linalg.norm(self.operator.point(s+'_wrist')-target)) for s,target in targets.items()}
                    report=dict(accepted=True,mode='planned',wrist_error_m=errors,
                        anchor_error_m=max(float(np.linalg.norm(self.operator.point(s+'_ankle')-a)) for s,a in anchors.items()),
                        support_margin_m=self.operator.support_gap(),max_clearance_violation_m=float(self.operator.collision_penalties()[0].max()),
                        contacts=[],nfev=0,cost=0.,surface_checked=True)
            if planned:pass
            elif stationary:
                q=self.operator_q.copy();report=dict(accepted=True,mode='hold',wrist_error_m=wrist_errors,anchor_error_m=0.,support_margin_m=self.operator.support_gap(),max_clearance_violation_m=float(penalties.max()),contacts=[],nfev=0,cost=0.)
            else:
                q,report=self.operator.fit(targets,row,initial=self.operator_q,nominal=nominal,anchors=anchors,foot_yaws=yaws,support_sides=support,continuity=self.operator_q,max_nfev=35,motion_dt=row['t']-self.last_body_time,balance_center=balance_center,posture_weight=posture_weight)
            if not report['accepted']:
                q2,r2=self.operator.fit(targets,row,initial=nominal,nominal=nominal,anchors=anchors,support_sides=support,foot_yaws=yaws,continuity=self.operator_q,max_nfev=120,motion_dt=row['t']-self.last_body_time,balance_center=balance_center,posture_weight=posture_weight)
                if (not r2['accepted'],r2['cost'])<(not report['accepted'],report['cost']):q,report=q2,r2
            if report['accepted'] and self.contact_segment is not None:
                tracked=[3,4,5,*[i for name,i in self.operator.index.items() if not name.startswith('neck_')]]
                translation=float(np.linalg.norm(q[:3]-nominal[:3]));angle=float(np.max(np.abs(q[tracked]-nominal[tracked])))
                report={**report,'body_tracking_error_m':translation,'body_tracking_error_deg':float(np.degrees(angle))}
            if not report['accepted']:
                row['body_rejected']=report
                row['body_debug']={'anchors':{s:a.tolist() for s,a in anchors.items()},'foot_yaws':yaws,'nominal':nominal.tolist(),'previous':self.operator_q.tolist()}
                raise RuntimeError('Actual physics/body state rejected at '+self.stage+': '+str(report))
            # Endpoints alone cannot certify the rendered motion. A skin
            # triangle can cross a panel between two otherwise valid poses.
            # Reject the rollout so execute_pose retries it at a lower speed.
            from validate_body_motion import validate_transition
            sample={**row,'body_anchors':anchors,'body_foot_yaws':yaws,'body_support':support}
            previous=self.rows[row_index-1] if row_index else None
            if previous is not None and 'body_q' in previous:
                crossing=validate_transition(self.operator,previous,sample,q)
                if crossing:
                    row['body_transition_rejected']=crossing
                    raise RuntimeError('Between-frame body motion rejected at '+self.stage+': '+str(crossing))
            self.operator_q=q;self.last_body_time=row['t']
            v=self.operator.landmarks(q);v.update(attach_free_hands(self.operator,q,hands,targets))
            if not self.tool_parked and 'right' not in targets:
                self.tool=v['right'][:2];row['tool']=copy.deepcopy(self.tool);v['tool']=copy.deepcopy(self.tool)
            from task_hands import driver_tool_clear
            tool_rotation=R.from_quat(row['tool'][1],scalar_first=True)*R.from_rotvec([0,-row.get('stroke',0.),0])
            if not driver_tool_clear([row['tool'][0],tool_rotation.as_quat(scalar_first=True).tolist()],boxes(row,self.spec)):
                row['tool_rejected']=True
                raise RuntimeError('Actual driver intersects furniture, fixture or floor at '+self.stage)
            row.update(body_q=q.tolist(),body_visual=v,body_check=report,body_support=support,body_anchors={s:a.tolist() for s,a in anchors.items()},body_foot_yaws=dict(yaws))
            if len(self.rows)>=self._progress_frame+200:
                self._progress_frame=len(self.rows);print('BODY_EXECUTION',len(self.rows),round(row['t'],2),self.stage,flush=True)

    def install_station(self,station):
        self.anchors={s:np.array(a) for s,a in station['anchors'].items()};self.operator_yaw=station['yaw'];self.foot_yaws={s:self.operator_yaw for s in self.anchors}
        nominal=stance_seed(self.operator,1.,self.operator_yaw,self.anchors)
        q,report=self.operator.fit({},self.current_row(),nominal=nominal,anchors=self.anchors,foot_yaws=self.foot_yaws,max_nfev=150)
        if not report['accepted']:raise RuntimeError('Initial operator station rejected: '+str(report))
        self.operator_q=q;self.last_body_time=float(self.rows[-1]['t'])
        # The initial settling records precede any manipulation. The person
        # starts at this planned station; there is no teleport during a task.
        for row in self.rows:
            if self.second_hand_blend is not None:row['second_hand_blend']=copy.deepcopy(self.second_hand_blend)
            hands,targets=hand_constraints(row,self.spec);v=self.operator.landmarks(q);v.update(attach_free_hands(self.operator,q,hands,targets))
            v['tool']=v['right'][:2];row['tool']=copy.deepcopy(v['tool']);self.tool=copy.deepcopy(v['tool'])
            row.update(body_q=q.tolist(),body_visual=v,body_check=report,body_support=['left','right'],body_anchors={s:a.tolist() for s,a in self.anchors.items()},body_foot_yaws=dict(self.foot_yaws))

    def execute_pose(self,q,anchors,yaws,duration=.2,carried=None,support_goal=None,defer_support=False,hand_blend=None,tool_motion=None,track_load=False):
        duration=max(duration,float(np.max(np.abs(q[3:]-self.operator_q[3:])))/np.radians(60))
        start_q=self.operator_q.copy();start_anchors={s:a.copy() for s,a in self.anchors.items()};start_yaws=self.foot_yaws.copy();t0=float(self.d.time)
        if carried is not None:
            carried_override=carried.hand_rotation_override
            carried_start_rotation=self.pose('gripper')[1]
            carried.set(q);carried_goal_rotation=R.from_quat(carried.planned_gripper[1],scalar_first=True)
        state_kind=mujoco.mjtState.mjSTATE_INTEGRATION
        state=np.zeros(mujoco.mj_stateSize(self.m,state_kind));mujoco.mj_getState(self.m,self.d,state,state_kind)
        old=(len(self.rows),len(self.events),self.steps,self.target.copy(),self.target_rotation,copy.deepcopy(self.tool),self.operator_yaw,self.last_body_time,copy.deepcopy(self.second_hand_blend))
        factors=[1.,2.,4.,8.,16.] if carried is not None else [1.,2.,4.]
        for factor in factors:
            if factor!=1.:
                mujoco.mj_setState(self.m,self.d,state,state_kind);mujoco.mj_forward(self.m,self.d)
                nrows,nevents,self.steps,self.target,self.target_rotation,self.tool,self.operator_yaw,self.last_body_time,self.second_hand_blend=copy.deepcopy(old)
                del self.rows[nrows:];del self.events[nevents:]
                self.operator_q=start_q.copy();self.anchors={s:a.copy() for s,a in start_anchors.items()};self.foot_yaws=start_yaws.copy()
            dt=float(self.m.opt.timestep);stride=round(.04/dt);steps=int(np.ceil(duration*factor/dt));steps+=(-(self.steps+steps))%stride
            span=steps*dt;self.segment_support=None if support_goal is None else (support_goal,defer_support)
            self.contact_segment=(start_q,q,t0,t0+span,start_anchors,anchors,start_yaws,yaws)
            try:
                completed=0;projected=start_q.copy()
                while completed<steps:
                    batch=min(round(.02/dt),steps-completed);completed+=batch
                    u=completed/steps;candidate=start_q*(1-u)+q*u
                    if tool_motion is not None:
                        a,ar=tool_motion['start'];b,br=tool_motion['goal']
                        rotation=mixrot(R.from_quat(ar,scalar_first=True),R.from_quat(br,scalar_first=True),u)
                        self.tool=[(np.asarray(a)*(1-u)+np.asarray(b)*u).tolist(),rotation.as_quat(scalar_first=True).tolist()]
                    if hand_blend is not None:
                        self.second_hand_blend={**copy.deepcopy(hand_blend),'fraction':hand_blend['from']*(1-u)+hand_blend['to']*u}
                        self.second_hand_blend.pop('from',None);self.second_hand_blend.pop('to',None)
                    if carried is not None:
                        # Synchronize the grasp rotation with the body segment.
                        # Applying the endpoint rotation at its first timestep
                        # sweeps a board through obstacles before the body lifts.
                        carried.hand_rotation_override=mixrot(carried_start_rotation,carried_goal_rotation,u)
                        # Joint interpolation does not preserve planted feet or
                        # clearance. Project it onto the loaded contact constraints
                        # before deriving a physical gripper command.
                        sample_anchors={s:start_anchors[s]*(1-u)+anchors[s]*u for s in anchors}
                        sample_yaws={s:start_yaws[s]+angle_delta(yaws[s],start_yaws[s])*u for s in yaws}
                        support=[s for s,a in sample_anchors.items() if a[2]<.066]
                        if support_goal is not None and (not defer_support or completed==steps):support=support_goal
                        sample_row=self.current_row();carried.refresh_reference(sample_row,self.operator_q)
                        candidate,projection=carried.project(sample_row,candidate,projected,sample_anchors,sample_yaws,support,batch*dt,track_wrist=track_load)
                        if not projection['accepted']:raise RuntimeError('Loaded interpolation rejected: '+str(projection))
                        projected=candidate.copy();self.contact_nominal=projected
                        carried.set(candidate);p,r=carried.planned_gripper;self.target=np.array(p);self.target_rotation=R.from_quat(r,scalar_first=True)
                    self.advance(batch*dt)
                self.contact_segment=None;self.contact_nominal=None;self.segment_support=None;self.anchors={s:a.copy() for s,a in anchors.items()};self.foot_yaws=yaws.copy();self.operator_yaw=q[3]
                if carried is not None:carried.hand_rotation_override=carried_override
                return
            except RuntimeError as error:
                self.contact_nominal=None
                if carried is not None:carried.hand_rotation_override=carried_override
                self.rejected_rollouts.append({'time_s':t0,'duration_s':span,'reason':str(error),'last_frame':copy.deepcopy(self.rows[-1])})
                print('REPLAN_SLOWER',self.stage,span,str(error),flush=True)
                if factor==factors[-1]:self.contact_segment=None;self.segment_support=None;raise

    def save(self,out):
        mujoco.mj_forward(self.m,self.d)
        super().save(out)
        from pathlib import Path
        out=Path(out)
        (out/'execution-retries.json').write_text(json.dumps(self.rejected_rollouts,indent=2))
        if self.operator_q is not None:
            kind=mujoco.mjtState.mjSTATE_INTEGRATION;state=np.zeros(mujoco.mj_stateSize(self.m,kind));mujoco.mj_getState(self.m,self.d,state,kind)
            np.save(out/'integration-state.npy',state)
            names=['held','fastened','engagement','steps','max_force','max_torque','stage','tool','tool_control','tool_parked','stroke','tool_engaged','closure','two_hands','second_hand_blend','second_grasp','finish_grasp','connector','grasp_profile','operator_yaw','last_body_time','selected_grasps','active_grasp_part','reaching']
            controller={n:(sorted(getattr(self,n)) if isinstance(getattr(self,n),set) else getattr(self,n)) for n in names}
            controller.update(operator_q=self.operator_q.tolist(),anchors={s:a.tolist() for s,a in self.anchors.items()},foot_yaws=self.foot_yaws,target=self.target.tolist(),target_rotation=self.target_rotation.as_quat(scalar_first=True).tolist())
            (out/'controller-state.json').write_text(json.dumps(controller,indent=2))
            (out/'asset.json').write_text(json.dumps(self.spec,indent=2))

    def tool_move(self,position,rotation,duration=1.):
        """Retiming changes tool speed while preserving all body speed limits."""
        kind=mujoco.mjtState.mjSTATE_INTEGRATION;state=np.zeros(mujoco.mj_stateSize(self.m,kind));mujoco.mj_getState(self.m,self.d,state,kind)
        names=['steps','tool','operator_q','last_body_time','operator_yaw','anchors','foot_yaws','target','target_rotation']
        original={name:copy.deepcopy(getattr(self,name)) for name in names};nrows,nevents=len(self.rows),len(self.events)
        for factor in [1.,2.,4.,8.]:
            if factor!=1.:
                mujoco.mj_setState(self.m,self.d,state,kind);mujoco.mj_forward(self.m,self.d)
                for name,value in original.items():setattr(self,name,copy.deepcopy(value))
                del self.rows[nrows:];del self.events[nevents:]
            try:return super().tool_move(position,rotation,duration*factor)
            except RuntimeError as error:
                self.rejected_rollouts.append({'time_s':float(self.d.time),'duration_s':duration*factor,'reason':str(error),'last_frame':copy.deepcopy(self.rows[-1])})
                print('RETIME_TOOL',self.stage,duration*factor,str(error),flush=True)
                if factor==8.:raise

    @classmethod
    def restore(cls,folder):
        from pathlib import Path
        folder=Path(folder);world=cls(folder/'asset.json',1)
        world.m=mujoco.MjModel.from_binary_path(str(folder/'model.mjb'));world.d=mujoco.MjData(world.m)
        mujoco.mj_setState(world.m,world.d,np.load(folder/'integration-state.npy'),mujoco.mjtState.mjSTATE_INTEGRATION);mujoco.mj_forward(world.m,world.d)
        world.rows=json.loads((folder/'trajectory.json').read_text());world.events=json.loads((folder/'events.json').read_text());state=json.loads((folder/'controller-state.json').read_text())
        for name,value in state.items():
            if name in ['operator_q','target']:value=np.array(value)
            elif name=='target_rotation':value=R.from_quat(value,scalar_first=True)
            elif name=='anchors':value={s:np.array(a) for s,a in value.items()}
            elif name=='fastened':value=set(value)
            setattr(world,name,value)
        world._progress_frame=len(world.rows);world.xml=(folder/'model.xml').read_text()
        return world

    def walk_to(self,station,carried=None):
        goal={side:np.array(a) for side,a in station['anchors'].items()};goal_center=np.mean(list(goal.values()),axis=0);goal_yaw=station['yaw']
        planner=carried or self.operator;template=self.operator_q.copy();next_side='left';arriving=False
        def static_obstacles(row):
            obstacles=boxes(row,self.spec)
            if carried is not None:
                keep=[i for i,n in enumerate(obstacles[0]) if n not in carried.carried_names]
                obstacles=([obstacles[0][i] for i in keep],*[a[keep] for a in obstacles[1:]])
            return obstacles
        route=plan_route(np.mean(list(self.anchors.values()),axis=0),goal_center,static_obstacles(self.current_row()));route_index=0
        self.walk_target={'anchors':{s:a.tolist() for s,a in goal.items()},'yaw':float(goal_yaw),'route':[p.tolist() for p in route]}
        for step in range(160):
            row=self.current_row();center=np.mean(list(self.anchors.values()),axis=0)
            while route_index<len(route)-1 and np.linalg.norm(route[route_index]-center[:2])<.18:route_index+=1
            distance=np.linalg.norm(goal_center[:2]-center[:2])
            if step%10==0:print('WALK_STEP',step,'remaining_m',round(float(distance),3),'foot_error_m',round(max(float(np.linalg.norm(goal[s]-self.anchors[s])) for s in goal),3),flush=True)
            if route_index==len(route)-1 and distance<.2:arriving=True
            if max(np.linalg.norm(goal[s]-self.anchors[s]) for s in goal)<.025 and max(abs(angle_delta(goal_yaw,self.foot_yaws[s])) for s in goal)<.08:
                self.walk_target=None;return
            travel=(goal_center[:2] if arriving else route[route_index])-center[:2];length=np.linalg.norm(travel)
            desired_yaw=goal_yaw if arriving else np.arctan2(-travel[0],travel[1]);obstacles=static_obstacles(row);selected=None;rejections=[]
            # Exhaust shorter steps for the alternating foot before moving
            # the same foot again. Scale-first search could repeat a full
            # stride with one foot forever despite a clear shorter other step.
            for side in [next_side,'right' if next_side=='left' else 'left']:
                for scale in [1.,.65,.35]:
                    other='right' if side=='left' else 'left';sign=-1 if side=='left' else 1
                    yaw=self.foot_yaws[other]+np.clip(angle_delta(desired_yaw,self.foot_yaws[other]),-.35*scale,.35*scale)
                    midpoint=goal_center[:2] if arriving else center[:2]+travel/max(length,1e-9)*min(.22*scale,length)
                    target=np.r_[midpoint+R.from_euler('z',yaw).apply([sign*.13,0,0])[:2],.065]
                    if arriving and abs(angle_delta(goal_yaw,yaw))<.1:target=goal[side].copy()
                    try:end,height=choose_step(self.anchors[side],target,self.foot_yaws[side],yaw,obstacles,side,self.anchors[other],other_yaw=self.foot_yaws[other])
                    except RuntimeError as error:rejections.append(str(error));continue
                    previous=self.operator_q.copy();poses=[]
                    # Plan the complete weight transfer, swing and landing
                    # before moving either foot in the actual simulation.
                    for u in np.linspace(0,1,9):
                        anchors={s:a.copy() for s,a in self.anchors.items()};yaws=self.foot_yaws.copy()
                        anchors[side],yaws[side]=swing_pose(self.anchors[side],end,self.foot_yaws[side],yaw,height,u)
                        support=[other];heading=yaws['left']+.5*angle_delta(yaws['right'],yaws['left'])
                        nominal=stance_seed(planner,1.,heading,anchors)
                        if carried is not None:
                            for name,index in planner.index.items():
                                if any(k in name for k in ['shoulder','elbow','clavicle']):nominal[index]=template[index]
                        q,report=planner.fit({},row,nominal=nominal,anchors=anchors,foot_yaws=yaws,support_sides=support,initial=previous,continuity=previous,max_nfev=120)
                        if not report['accepted']:
                            alternative,other_report=planner.fit({},row,nominal=nominal,anchors=anchors,foot_yaws=yaws,support_sides=support,initial=nominal,continuity=previous,max_nfev=180)
                            if (not other_report['accepted'],other_report['cost'])<(not report['accepted'],report['cost']):q,report=alternative,other_report
                        if not report['accepted']:
                            rejections.append({'side':side,'swing_fraction':u,'report':report});break
                        poses.append((q.copy(),anchors,yaws));previous=q
                    if len(poses)==9:selected=(side,other,poses);break
                if selected is not None:break
            if selected is None:raise RuntimeError('No complete articulated step is feasible: '+str(rejections[-3:]))
            side,other,poses=selected
            for i,(q,anchors,yaws) in enumerate(poses):self.execute_pose(q,anchors,yaws,duration=.3 if i==0 else .15,carried=carried,support_goal=[other],defer_support=i==0)
            next_side=other
        raise RuntimeError('Contact planner did not reach work station')

    def stand_empty(self):
        if self.held:raise RuntimeError('Cannot stand unladen while holding furniture')
        start=self.operator_q.copy();standing=stance_seed(self.operator,1.,self.operator_yaw,self.anchors)
        self.stage='Stand before walking'
        for u in np.linspace(0,1,21)[1:]:
            nominal=start*(1-u)+standing*u
            q,report=self.operator.fit({},self.current_row(),nominal=nominal,initial=self.operator_q,anchors=self.anchors,foot_yaws=self.foot_yaws,continuity=self.operator_q,max_nfev=100)
            if not report['accepted']:raise RuntimeError('Unladen standing transition rejected: '+str(report))
            self.execute_pose(q,self.anchors,self.foot_yaws)

    def pickup(self,part,yaw_hint=None,center_hint=None,grasp_pose=None,station=None):
        self.stage='Approach '+part.replace('_',' ');self.connector=None;self.grasp_profile=self.parts[part].get('grasp_profile','tool')
        p,r=self.pose(part);radius=float(self.operator.m.geom_size[self.operator.m.geom('left_forearm').id,0]);self.selected_grasps[part]=select_grasp(self.parts[part],p,r,radius+.012);self.active_grasp_part=part
        if grasp_pose is None and station is None and not any(part in [self.connectors[k]['a'],self.connectors[k]['b']] for k in self.fastened):
            from grasp_sites import choose_task_grasp
            choice=choose_task_grasp(self,part,radius+.012)
            if choice is not None:self.selected_grasps[part],station=choice
        if grasp_pose is not None:self.finish_grasp={**copy.deepcopy(grasp_pose),'part':part}
        p,r=self.site(part);goal=self.current_row();goal.update(stage='Grasp '+part.replace('_',' '),gripper=[p.tolist(),r.as_quat(scalar_first=True).tolist()],grasp_profile=self.grasp_profile)
        station=station or plan_stance(self.operator,goal,self.spec,yaw_hint=yaw_hint,center_hint=center_hint)
        if self.operator_q is None:self.install_station(station)
        else:
            self.stand_empty();self.stage='Approach '+part.replace('_',' ');self.walk_to(station)
        # Position the unladen virtual gripper at the real hand before reaching.
        self.operator.set(self.operator_q);start=self.operator.point('left_wrist')-r.apply(wrist_offset('left',self.grasp_profile))
        self.move(start,r);self.stage='Reach for '+part.replace('_',' ');self.reaching=True
        self.move(p,r,speed=.18);self.stage='Grasp '+part.replace('_',' ');self.fingers(1);self.grasp(part);self.reaching=False

    def carry(self,part,goal,rotation):
        # Select the eventual fastening stance before moving the load.
        key=next(k for k,c in self.connectors.items() if c['b']==part and k not in self.fastened)
        hp,hr=self.pose('gripper');p,r=self.pose(part);local=hr.inv().apply(p-hp);relative=hr.inv()*r
        desired=rotation*relative.inv();target=np.array(goal)-desired.apply(local)
        synthetic=self.current_row();synthetic['parts'][part]=[list(goal),rotation.as_quat(scalar_first=True).tolist()];synthetic['gripper']=[target.tolist(),desired.as_quat(scalar_first=True).tolist()]
        tip,axis=self.tool_site(key);tool_rotation=self.tool_rotation(axis);synthetic.update(stage='Tighten clockwise',connector=key,tool=[(tip-axis*.14).tolist(),tool_rotation.as_quat(scalar_first=True).tolist()],stroke=0.)
        station=plan_stance(self.operator,synthetic,self.spec)
        self.stage='Raise '+part.replace('_',' ');carried=CarriedBody(self.spec,self.current_row(),self.operator_q,comfortable=True);carried.allow_floor_contact=True;start=self.operator_q.copy();standing=stance_seed(carried,1.,self.operator_yaw,self.anchors)
        for u in np.linspace(0,1,21)[1:]:
            nominal=start*(1-u)+standing*u
            q,report=carried.fit({},self.current_row(),nominal=nominal,anchors=self.anchors,foot_yaws=self.foot_yaws,initial=self.operator_q,continuity=self.operator_q,max_nfev=100)
            if not report['accepted']:raise RuntimeError('Body-driven lift rejected: '+str(report))
            self.execute_pose(q,self.anchors,self.foot_yaws,carried=carried)
        # Put the long axis upright before walking. A horizontal floor pickup
        # can otherwise require a fully extended arm throughout transport.
        carried.allow_floor_contact=False
        self.stage='Orient '+part.replace('_',' ')+' for carrying'
        size=np.array(self.parts[part]['size']);long_axis=int(np.argmax(size));thin_axis=int(np.argmin(size));remaining=3-long_axis-thin_axis
        frame=np.zeros((3,3));frame[:,long_axis]=[0,0,1];frame[:,thin_axis]=[0,1,0];frame[:,remaining]=[1,0,0]
        if np.linalg.det(frame)<0:frame[:,remaining]*=-1
        current_hand=self.pose('gripper')[1];current_part=self.pose(part)[1]
        carry_rotation=R.from_euler('z',self.operator_yaw)*R.from_matrix(frame)*(current_hand.inv()*current_part).inv()
        for u in np.linspace(0,1,21)[1:]:
            carried.hand_rotation_override=mixrot(current_hand,carry_rotation,u)
            nominal=stance_seed(carried,1.,self.operator_yaw,self.anchors)
            q,report=carried.fit({},self.current_row(),nominal=nominal,anchors=self.anchors,foot_yaws=self.foot_yaws,initial=self.operator_q,continuity=self.operator_q,max_nfev=120)
            if not report['accepted']:raise RuntimeError('Comfortable carry orientation rejected: '+str(report))
            self.execute_pose(q,self.anchors,self.foot_yaws,carried=carried)
        carried=CarriedBody(self.spec,self.current_row(),self.operator_q,comfortable=True)
        self.stage='Carry '+part.replace('_',' ');self.walk_to(station,carried)
        if getattr(self,'before_place',None) is not None:self.before_place(part,target,desired)
        self.place(part,target,desired)
        self.advance(.4)

    def align(self,key):
        """Close the alignment loop on the measured part, not an ideal weld.

        The assisted grasp has finite compliance. At an off-center surface
        grasp, repeating the ideal hand pose can leave a persistent mating
        error even though the hand reaches its command. Correct the observed
        part transform while preserving the current physical grasp relation.
        """
        from world import ActionRejected
        c=self.connectors[key]
        if self.held!=c['b']:raise ActionRejected('Hold the requested moving component before aligning')
        self.stage='Align '+c['b'].replace('_',' ')
        offset=np.asarray(self.parts[c['b']]['assembly_position'])-self.parts[c['a']]['assembly_position']
        for _ in range(20):
            error,angle=self.mating_error(key)
            if error<.002 and angle<np.radians(.5):return
            ap,ar=self.pose(c['a']);bp,br=self.pose(c['b']);gp,gr=self.pose('gripper')
            correction=ar*br.inv()
            self.move(ap+ar.apply(offset)+correction.apply(gp-bp),correction*gr)
            self.advance(.2)
        raise ActionRejected('Measured-part alignment did not converge against the moving receiver')

    def place(self,part,target,desired):
        """Plan the entire placement before moving the held part.

        A shortest quaternion interpolation can swing a board through the
        operator even when both endpoints are clear. Try separate rotation
        and lowering phases in both directions, allowing the wrist to move
        around the body during rotation. Anatomy and collision constraints
        remain identical for every candidate.
        """
        from validate_body_motion import ClothingAudit
        surface=ClothingAudit()
        row=self.current_row();start_p,start_r=self.pose('gripper');rejections=[]
        def visible_clear(body,q,report):
            if not report['accepted']:return False
            hits=surface.collisions(body.landmarks(q),boxes(body.predicted_row,self.spec))
            if hits:report.update(accepted=False,rendered_surface=hits)
            return report['accepted']
        vector=(desired*start_r.inv()).as_rotvec();angle=np.linalg.norm(vector)
        routes=[('direct',None),('rotate_short',vector)]
        if angle>1e-5:routes.append(('rotate_long',vector*(1-2*np.pi/angle)))
        receivers={c['a'] for c in self.connectors.values() if c['b']==part}
        if len(receivers)>1:
            # A shelf entering between two side panels must reach its mating
            # orientation before insertion. Simultaneous rotation and lowering
            # can wedge its opposite corners in the finite-force simulation.
            routes=[route for route in routes if route[0]!='direct']
        for label,rotation_vector in routes:
            body=CarriedBody(self.spec,row,self.operator_q,comfortable=True)
            # Keep normal furniture clearance while rotating. Mating contact
            # is appropriate only after the board reaches its insertion angle.
            body.allow_mating_contacts=rotation_vector is None
            previous=self.operator_q.copy();records=[];failed=False;position=start_p.copy()
            if rotation_vector is not None:
                row['stage']='Rotate '+part.replace('_',' ')+' clear of the body'
                count=max(60,int(np.ceil(np.linalg.norm(rotation_vector)/np.radians(3))))
                for u in np.linspace(0,1,count+1)[1:]:
                    rotation=R.from_rotvec(rotation_vector*u)*start_r;body.hand_rotation_override=rotation
                    nominal=stance_seed(body,1.,self.operator_yaw,self.anchors)
                    q,report=body.fit({},row,nominal=nominal,anchors=self.anchors,foot_yaws=self.foot_yaws,initial=previous,continuity=previous,max_nfev=200)
                    if not visible_clear(body,q,report):
                        rejections.append((label,'rotation',float(u),report));failed=True;break
                    records.append((q.copy(),rotation,'Rotate '+part.replace('_',' ')+' clear of the body',False));previous=q
                if failed:continue
                position=np.array(body.planned_gripper[0])
            segments=[(target,True)]
            if len(receivers)>1:
                # Center a divider above the assembled sides before entering
                # the opening. A diagonal descent reaches their height while
                # its opposite edge still lies outside the available slot.
                body.hand_rotation_override=desired;body.set(previous)
                names,centers,rotations,half=boxes(body.predicted_row,self.spec)
                low=centers[:,2]-np.einsum('ij,ij->i',np.abs(rotations[:,2,:]),half)
                high=centers[:,2]+np.einsum('ij,ij->i',np.abs(rotations[:,2,:]),half)
                carried=np.array([name in body.carried_names for name in names])
                relative_bottom=float(np.min(low[carried])-position[2])
                clearance_height=max(float(position[2]),float(np.max(high[~carried]))+.02-relative_bottom)
                raised=position.copy();raised[2]=clearance_height
                above=np.array(target,copy=True);above[2]=clearance_height
                segments=[(raised,False),(above,False),(target,True)]
            for endpoint,mating in segments:
                body.allow_mating_contacts=mating
                row['stage']=('Align ' if mating else 'Center above opening ')+part.replace('_',' ')
                for u in np.linspace(0,1,41)[1:]:
                    rotation=mixrot(start_r,desired,u) if rotation_vector is None else desired
                    body.hand_rotation_override=rotation;wrist=position*(1-u)+endpoint*u+rotation.apply(body.offset)
                    nominal=stance_seed(body,float(wrist[2]),self.operator_yaw,self.anchors)
                    q,report=body.fit({'left':wrist},row,nominal=nominal,anchors=self.anchors,foot_yaws=self.foot_yaws,initial=previous,continuity=previous,max_nfev=200)
                    if not visible_clear(body,q,report):
                        rejections.append((label,row['stage'],float(u),report));failed=True;break
                    records.append((q.copy(),rotation,row['stage'],mating));previous=q
                if failed:break
                position=np.asarray(endpoint).copy()
            if failed:continue
            print('PLACEMENT_ROUTE',part,label,len(records),flush=True)
            previous_stage=None
            for q,rotation,stage,mating in records:
                if previous_stage and previous_stage.startswith('Rotate ') and not stage.startswith('Rotate '):
                    relative=start_r.inv()*R.from_quat(row['parts'][part][1],scalar_first=True)
                    wanted=rotation*relative
                    for _ in range(10):
                        if (wanted.inv()*self.pose(part)[1]).magnitude()<np.radians(.5):break
                        self.advance(.15)
                    else:raise RuntimeError('Actual held component did not finish rotating before insertion')
                self.stage=stage;body.hand_rotation_override=rotation;body.allow_mating_contacts=mating
                self.execute_pose(q,self.anchors,self.foot_yaws,carried=body)
                previous_stage=stage
            return
        raise RuntimeError('No complete body-driven placement route: '+str(rejections))

    def release_if_supported(self,stage='Check resting support before fastening'):
        """Try a real resting contact phase; roll back an unstable release.

        Furniture stays dynamic under gravity. Only a stable executed release
        permits walking away from the supporting grasp to use the driver.
        """
        if self.held is None:return False
        group=self.group(self.held);before={name:self.pose(name) for name in group}
        kind=mujoco.mjtState.mjSTATE_INTEGRATION
        state=np.zeros(mujoco.mj_stateSize(self.m,kind));mujoco.mj_getState(self.m,self.d,state,kind)
        names=['held','closure','stage','steps','tool','operator_q','operator_yaw','last_body_time']
        original={name:copy.deepcopy(getattr(self,name)) for name in names};nrows,nevents=len(self.rows),len(self.events)
        try:
            self.stage=stage;self.release();self.advance(.6)
            for name,(position,rotation) in before.items():
                p,r=self.pose(name);velocity=np.zeros(6)
                mujoco.mj_objectVelocity(self.m,self.d,mujoco.mjtObj.mjOBJ_BODY,self.ids[name],velocity,0)
                if np.linalg.norm(p-position)>.002 or (r*rotation.inv()).magnitude()>np.radians(.5) or np.linalg.norm(velocity[:3])>.05 or np.linalg.norm(velocity[3:])>.01:
                    raise RuntimeError('Released component lacks stable resting support')
            print('RESTING_SUPPORT_CONFIRMED',sorted(group),flush=True)
            return True
        except RuntimeError:
            mujoco.mj_setState(self.m,self.d,state,kind);mujoco.mj_forward(self.m,self.d)
            for name,value in original.items():setattr(self,name,value)
            del self.rows[nrows:];del self.events[nevents:]
            if self.operator_q is not None:
                self.operator.obstacles(self.current_row());self.operator.set(self.operator_q)
            return False

    def fasten(self,key,direction=1):
        if self.held is None:
            tip,axis=self.tool_site(key);rotation=self.tool_rotation(axis);synthetic=self.current_row()
            synthetic.update(stage='Tighten clockwise',connector=key,tool=[(tip-axis*.14).tolist(),rotation.as_quat(scalar_first=True).tolist()],stroke=0.)
            station=plan_stance(self.operator,synthetic,self.spec)
            self.stand_empty();self.stage='Walk to fastener '+key.replace('_',' ');self.walk_to(station)
        from task_hands import prepare_driver,driver_route,WorkPostureUnavailable
        self.connector=key;self.stroke=0.;self.tool_engaged=False
        try:prepare_driver(self,key)
        except WorkPostureUnavailable:
            if self.held is None or not self.release_if_supported():raise
            return self.fasten(key,direction)
        return_route=[(self.operator_q.copy(),copy.deepcopy(self.tool))]
        records=driver_route(self,key);return_route.extend(records);self.tool_control=True;self.stage='Position driver at '+key.replace('_',' ')
        for q,tool in records:self.execute_pose(q,self.anchors,self.foot_yaws,duration=.12,tool_motion={'start':self.tool,'goal':tool})
        return self.operate_fastener(key,direction,return_route)

    def operate_fastener(self,key,direction=1,return_route=None):
        if not return_route:raise RuntimeError('Fastening requires a checked driver return route')
        self.tool_control=True;self.connector=key;c=self.connectors[key];pos,axis=self.tool_site(key);rot=self.tool_rotation(axis)
        # The anatomical approach has already seated the driver. Keep the same
        # guarded torque/turn operations as the shared atomic controller.
        handle=pos-axis*.14
        for i in range(15):
            self.stroke=-direction*np.pi/4*(i+1)/15;self.advance(.02)
        self.tool_engaged=True
        remaining=c['required_turns'] if direction>0 else .25
        while remaining>1e-8:
            step=min(.25,remaining);self.stage=('Tighten clockwise · ' if direction>0 else 'Loosen counterclockwise · ')+key.replace('_',' ')
            self.stroke=-direction*np.pi/4
            # Rotate through 90 degrees; return stroke uses an ideal one-way ratchet.
            count=40
            for i in range(count):
                pos,axis=self.tool_site(key);rot=self.tool_rotation(axis)
                self.stroke=direction*(-np.pi/4+(i+1)/count*2*np.pi*step)
                self.tool=[(pos-axis*.14).tolist(),rot.as_quat(scalar_first=True).tolist()]
                actual_tip=np.array(self.tool[0])+rot.apply([0,-.14,0])
                increment=direction*step/count
                if direction>0 and remaining<=.25+1e-8 and i==count-1:increment=c['required_turns']-self.engagement[key]
                self.turn(key,increment,c['minimum_torque']*1.2,actual_tip,axis)
                self.advance(.018)
            self.stage='Reset ratchet · '+key.replace('_',' ')
            initial=self.stroke
            for i in range(20):
                self.stroke=float(initial+(-direction*np.pi/4-initial)*(i+1)/20);self.advance(.02)
            remaining-=step
        self.tool_engaged=False;initial=self.stroke
        for i in range(15):
            self.stroke=initial*(1-(i+1)/15);self.advance(.02)
        self.stage='Withdraw driver'
        # Retrace the body-and-tool approach, including its axial standoff.
        # A generic return toward the supporting gripper can cross an adjacent
        # table leg even when the wrist and the body remain collision-free.
        for q,tool in reversed(return_route):
            self.execute_pose(q,self.anchors,self.foot_yaws,duration=.12,tool_motion={'start':self.tool,'goal':tool})
        # End the active right-hand task before returning to arm-attached tool
        # tracking. Keeping the "Withdraw" stage would constrain that hand to
        # the shared controller's legacy gripper-relative idle-tool position.
        self.stage='Release supported part';self.connector=None;self.tool_control=False


    def finish(self):
        from final_motion import finish
        return finish(self)
