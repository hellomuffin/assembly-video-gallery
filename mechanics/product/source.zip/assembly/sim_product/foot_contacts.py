"""Geometric landing checks for explicitly planned foot contacts."""
import numpy as np
from scipy.spatial.transform import Rotation as R
from leg_clearance import boxes


def obb_overlap(center_a,rotation_a,half_a,center_b,rotation_b,half_b):
    axes=np.concatenate([rotation_a.T,rotation_b.T,np.cross(rotation_a.T[:,None,:],rotation_b.T[None,:,:]).reshape(-1,3)])
    axes=axes[np.linalg.norm(axes,axis=1)>1e-8]
    projected=np.abs(axes@(center_b-center_a))
    radius_a=np.abs(axes@rotation_a)@half_a;radius_b=np.abs(axes@rotation_b)@half_b
    return bool(np.all(projected<=radius_a+radius_b))


def landing_clear(ankle,yaw,obstacles,margin=.012):
    rotation=R.from_euler('z',yaw).as_matrix();center=np.array(ankle)+rotation@np.array([0,.04,-.025]);half=np.array([.065,.13,.04])
    names,centers,rotations,sizes=obstacles
    return not any(obb_overlap(center,rotation,half,p,r,h+margin) for p,r,h in zip(centers,rotations,sizes))


def choose_landing(target,yaw,obstacles,side,other=None,max_shift=.32):
    candidates=[];right=R.from_euler('z',yaw).apply([1,0,0]);sign=-1 if side=='left' else 1
    for radius in np.arange(0,max_shift+.001,.04):
        for angle in np.linspace(0,2*np.pi,24,endpoint=False):
            point=np.array(target,float)+[radius*np.cos(angle),radius*np.sin(angle),0]
            if other is not None and not stance_valid(point,yaw,side,other):continue
            if landing_clear(point,yaw,obstacles):candidates.append(point)
        if candidates:return min(candidates,key=lambda p:np.linalg.norm(p-target))
    raise RuntimeError('No collision-free foot landing within the allowed step search')


def stance_valid(point,yaw,side,other):
    right=R.from_euler('z',yaw).apply([1,0,0]);sign=-1 if side=='left' else 1
    width=sign*np.dot(np.asarray(point)-other,right)
    return .22-1e-9<=width<=.38+1e-9 and np.linalg.norm(np.asarray(point)-other)<=.5+1e-9


def swing_pose(start,end,yaw0,yaw1,height,u):
    """Lift vertically, advance above obstacles, then lower onto clear contact."""
    from math import atan2,sin,cos
    turn=atan2(sin(yaw1-yaw0),cos(yaw1-yaw0))
    u=float(np.clip(u,0,1));travel=float(np.clip((u-.25)/.5,0,1));blend=travel*travel*(3-2*travel)
    ankle=np.array(start)*(1-blend)+np.array(end)*blend
    lift=min(u/.25,(1-u)/.25,1.);lift=lift*lift*(3-2*lift)
    ankle[2]+=height*lift
    return ankle,yaw0+turn*blend


def plan_swing(start,end,yaw0,yaw1,obstacles):
    for height in np.arange(.10,.261,.02):
        if all(landing_clear(*swing_pose(start,end,yaw0,yaw1,height,u),obstacles,margin=.012) for u in np.linspace(0,1,41)):
            return float(height)
    raise RuntimeError('No clear foot swing within anatomical step-height limit')


def choose_step(start,target,yaw0,yaw1,obstacles,side,other,max_shift=.32,other_yaw=None):
    """Select a reachable landing and its entire swing as one operation."""
    start=np.asarray(start);other=np.asarray(other);right=R.from_euler('z',yaw1).apply([1,0,0]);sign=-1 if side=='left' else 1
    other_rotation=R.from_euler('z',yaw0 if other_yaw is None else other_yaw).as_matrix()
    other_center=other+other_rotation@np.array([0,.04,-.025])
    obstacles=([*obstacles[0],'planted_shoe'],np.vstack([obstacles[1],other_center]),np.concatenate([obstacles[2],other_rotation[None]]),np.vstack([obstacles[3],[.065,.13,.04]]))
    options=[]
    for radius in np.arange(0,max_shift+.001,.04):
        for angle in np.linspace(0,2*np.pi,24,endpoint=False):
            point=np.asarray(target)+[radius*np.cos(angle),radius*np.sin(angle),0]
            if not stance_valid(point,yaw1,side,other) or np.linalg.norm(point-start)>.45:continue
            if np.linalg.norm(point-start)<.01 and abs(np.arctan2(np.sin(yaw1-yaw0),np.cos(yaw1-yaw0)))<.03:continue
            if landing_clear(point,yaw1,obstacles):options.append(point)
        for point in sorted(options,key=lambda p:np.linalg.norm(p-target)):
            try:return point,plan_swing(start,point,yaw0,yaw1,obstacles)
            except RuntimeError:pass
        options=[]
    raise RuntimeError('No complete step meets clearance, stride and stance-width constraints')
