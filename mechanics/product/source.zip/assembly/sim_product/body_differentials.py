"""Kinematic and signed-contact Jacobians for constrained body motion.

Use MuJoCo's joint Jacobians rather than re-running collision detection for
finite differences of every joint. Carried rigid bodies share the hand's
translation and the explicitly planned grasp rotation.
"""
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation as R
from contact_geometry import geometry as contact_geometry
COLLISION_WEIGHT=5000.


def skew(v):
    x,y,z=v;return np.array([[0.,-z,y],[z,0.,-x],[-y,x,0.]])


class Kinematics:
    def __init__(self,body,q):
        self.b=body;self.q=np.array(q);self.sites={};self.bodies={}
        m,d=body.m,body.d;self.mapping=np.eye(m.nv,body.nvars)
        eps=1e-6
        for j in range(3,6):
            poses=[]
            for sign in [-1,1]:
                value=self.q.copy();value[j]+=sign*eps;pose=d.qpos.copy()
                pose[3:7]=(R.from_euler('z',value[3])*R.from_euler('y',value[5])*R.from_euler('x',-value[4])).as_quat(scalar_first=True);poses.append(pose)
            velocity=np.zeros(m.nv);mujoco.mj_differentiatePos(m,velocity,2*eps,*poses);self.mapping[:,j]=velocity

    def site(self,name):
        if name not in self.sites:
            p=np.zeros((3,self.b.m.nv));r=np.zeros_like(p);mujoco.mj_jacSite(self.b.m,self.b.d,p,r,self.b.site_ids[name])
            self.sites[name]=(p@self.mapping,r@self.mapping)
        return self.sites[name]

    def body(self,index):
        if index not in self.bodies:
            p=np.zeros((3,self.b.m.nv));r=np.zeros_like(p);mujoco.mj_jacBody(self.b.m,self.b.d,p,r,index)
            self.bodies[index]=(p@self.mapping,r@self.mapping)
        return self.bodies[index]

    def carried_point(self,point):
        b=self.b;jacobian=self.site(b.carry_side+'_wrist')[0].copy()
        if b.hand_rotation_override is None:
            omega=np.zeros((3,b.nvars));omega[2,3]=1.
            jacobian-=skew(np.array(point)-b.point(b.carry_side+'_wrist'))@omega
        return jacobian

    def geom_point(self,index,point):
        b=self.b
        if getattr(b,'coupling',False) and index in b.carried_geoms:return self.carried_point(point)
        body=int(b.m.geom_bodyid[index]);p,r=self.body(body)
        return p-skew(np.array(point)-b.d.xpos[body])@r

    def load_center(self):
        b=self.b;jac=np.zeros((3,b.m.nv));mujoco.mj_jacSubtreeCom(b.m,b.d,jac,b.root_id)
        human_mass=float(b.m.body_subtreemass[b.root_id]);total=human_mass;result=human_mass*(jac@self.mapping)
        if getattr(b,'coupling',False):
            for name,mass in b.part_masses.items():
                total+=mass;result+=mass*self.carried_point(b.d.xpos[b.m.body('part_'+name).id])
        elif b.row.get('held'):
            group={b.row['held']}
            while True:
                before=len(group)
                for c in b.spec['connectors']:
                    if c['id'] in b.row.get('fastened',[]) and (c['a'] in group or c['b'] in group):group.update([c['a'],c['b']])
                if before==len(group):break
            total+=sum(p['mass'] for p in b.spec['parts'] if p['id'] in group)
        return result/total

    def collisions(self,clearance=.012):
        b=self.b;result=np.zeros((len(b.pairs),b.nvars));largest=np.zeros(len(b.pairs))
        for contact in b.collision_contacts():
            constraint=b.contact_constraint(contact,clearance)
            if constraint is None:continue
            index,margin=constraint;distance,a,point_a,c,point_b,normal=contact_geometry(b.m,b.d,contact);amount=margin-distance
            if amount<=largest[index]:continue
            largest[index]=amount
            result[index]=-normal@(self.geom_point(int(c),point_b)-self.geom_point(int(a),point_a))
        return result

    def dynamic_targets(self):
        b=self.b
        if getattr(b,'bimanual',False):return {name:self.carried_point(point) for name,point in b.dynamic_targets().items()}
        return {}


def problem_jacobian(body,q,targets,anchors,foot_rotations,mode,focus,support_equations,weights,continuity,balance_weight=25):
    body.set(q);kin=Kinematics(body,q);out=[];dynamic=kin.dynamic_targets()
    for side in {**targets,**body.dynamic_targets()}:
        out.append((kin.site(side+'_wrist')[0]-dynamic.get(side,0))*2000)
    for side in anchors:
        out.append(kin.site(side+('_knee' if mode=='kneel' else '_ankle'))[0]*20000)
        if mode!='kneel':
            index=body.m.body(side+'_foot').id;foot=body.d.xmat[index].reshape(3,3);angular=kin.body(index)[1]
            derivative=np.stack([-skew(foot[:,j])@angular for j in range(3)],axis=1)
            out.append(derivative.reshape(9,body.nvars)*20000)
    head=body.m.body('neck').id;forward=body.d.xmat[head].reshape(3,3)[:,1];gaze=focus-body.point('eye');length=max(np.linalg.norm(gaze),1e-9);gaze/=length
    out.append((-skew(forward)@kin.body(head)[1]+(np.eye(3)-np.outer(gaze,gaze))@kin.site('eye')[0]/length)*2.)
    center=body.load_center();center_jac=kin.load_center()
    out.append(center_jac[:2]*balance_weight)
    active=(support_equations[:,:2]@center[:2]+support_equations[:,2]+.025)>0
    out.append((support_equations[:,:2]@center_jac[:2])*active[:,None]*600)
    active=(support_equations[:,:2]@center[:2]+support_equations[:,2]+.006)>0
    out.append((support_equations[:,:2]@center_jac[:2])*active[:,None]*20000)
    out.append(np.diag(weights))
    if continuity is not None:out.append(np.eye(body.nvars)*2.)
    out.append(kin.collisions()*COLLISION_WEIGHT)
    return np.vstack(out)
