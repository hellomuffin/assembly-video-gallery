"""Task hand constraints shared by preflight planning and rendering.

Only hands doing work constrain the body. A free hand follows its articulated
arm; it must not pin the torso to a stale grasp after an object is released.
"""
from pathlib import Path
import json
import numpy as np
from scipy.spatial.transform import Rotation as R

LIB=json.loads((Path(__file__).parent/'assets/hand_poses.json').read_text())


def wrist_offset(side,profile):
    offset=np.array(LIB['board_wrist' if profile=='board' else 'wrist'])
    return offset*np.array([-1,1,1]) if side=='left' else offset


def hand_constraints(row,spec):
    lp,lq=row['gripper'];profile=row.get('grasp_profile','tool')
    hands={'left':[lp,lq,row.get('closure',0.),profile]}
    if row.get('two_hands') or row.get('second_hand_blend'):
        grip=row.get('second_grasp') or spec['finish_second_grasp'];p,q=row['parts'][grip['part']];r=R.from_quat(q,scalar_first=True)
        hands['right']=[(np.array(p)+r.apply(grip['position'])).tolist(),(r*R.from_quat(grip['rotation'],scalar_first=True)).as_quat(scalar_first=True).tolist(),row.get('closure',1.),'board']
    else:
        p,q=row['tool'];r=R.from_quat(q,scalar_first=True)*R.from_rotvec([0,-row.get('stroke',0.),0])
        hands['right']=[p,r.as_quat(scalar_first=True).tolist(),0. if row.get('tool_parked') else 1.,'board' if row.get('tool_parked') else 'tool']
    if row.get('second_hand_blend'):
        blend=row['second_hand_blend'];fraction=float(np.clip(blend['fraction'],0,1));nodes=[blend['start'],*blend.get('via',[]),hands['right']]
        delta=R.identity()
        if blend.get('reference'):
            # Approach points travel with the held assembly. This permits the
            # supporting arm to reposition the load during the free-hand reach.
            p,q=blend['reference'];delta=R.from_quat(row['gripper'][1],scalar_first=True)*R.from_quat(q,scalar_first=True).inv()
            nodes=[[(np.array(row['gripper'][0])+delta.apply(np.array(n[0])-p)).tolist(),(delta*R.from_quat(n[1],scalar_first=True)).as_quat(scalar_first=True).tolist()] for n in nodes[:-1]]+[nodes[-1]]
        scaled=fraction*(len(nodes)-1);index=min(int(scaled),len(nodes)-2);u=scaled-index
        a,b=nodes[index:index+2];ar=R.from_quat(a[1],scalar_first=True);br=R.from_quat(b[1],scalar_first=True)
        rotation=R.from_rotvec((br*ar.inv()).as_rotvec()*u)*ar
        position=np.array(a[0])*(1-u)+np.array(b[0])*u
        if blend.get('wrist_space'):
            offset=wrist_offset('right','board')
            position+=(1-u)*ar.apply(offset)+u*br.apply(offset)-rotation.apply(offset)
        position+=np.sin(np.pi*fraction)*delta.apply(blend.get('arc',[0,0,0]))
        hands['right']=[position.tolist(),rotation.as_quat(scalar_first=True).tolist(),fraction,'board']
    stage=row.get('stage','')
    active=[]
    if row.get('held') or stage.startswith(('Grasp ','Reach for ')):active.append('left')
    if row.get('two_hands') or row.get('second_hand_blend') or row.get('tool_engaged') or stage.startswith(('Position driver','Tighten ','Loosen ','Reset ratchet','Withdraw driver','Set driver')):active.append('right')
    targets={side:np.array(hands[side][0])+R.from_quat(hands[side][1],scalar_first=True).apply(wrist_offset(side,hands[side][3])) for side in active}
    return hands,targets


def attach_free_hands(body,q,hands,targets):
    body.set(q)
    for side in ['left','right']:
        if side in targets:continue
        rotation=R.from_matrix(body.d.xmat[body.m.body(side+'_forearm').id].reshape(3,3))*R.from_euler('x',np.pi/2)
        profile=hands[side][3]
        position=body.point(side+'_wrist')-rotation.apply(wrist_offset(side,profile))
        hands[side]=[position.tolist(),rotation.as_quat(scalar_first=True).tolist(),hands[side][2],profile]
    return hands


class WorkPostureUnavailable(RuntimeError):
    """The held-contact mode has no complete feasible driver preparation."""


def prepare_driver(world,key):
    """Reach a working crouch with the free tool attached to the actual arm."""
    from plan_body_motion import stance_seed
    from task_stance import fit_work_contact
    body=world.operator;start=world.operator_q.copy();tip,axis=world.tool_site(key);rotation=world.tool_rotation(axis)
    final={**world.current_row(),'stage':'Position driver at '+key,'connector':key,'stroke':0.,'tool':[(tip-axis*.14).tolist(),rotation.as_quat(scalar_first=True).tolist()]}
    _,targets=hand_constraints(final,world.spec);height=float(np.mean([p[2] for p in targets.values()]));candidates=[]
    heights=[.25,.35,.45,.55,.65,.75] if height<=.55 else [height,.65,.75,.9]
    for height in heights:
        nominal=stance_seed(body,height,world.operator_yaw,world.anchors)
        for initial in [nominal,start]:
            q,report=body.fit(targets,final,initial=initial,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,max_nfev=300)
            error=max(report['wrist_error_m'].values(),default=0.)
            if report['accepted'] and error<.004:candidates.append((error,q.copy()))
    if not candidates:raise WorkPostureUnavailable('No precise driver working posture at the actual foot contacts')
    world.stage='Prepare driver posture';world.tool_control=False;row=world.current_row();_,targets=hand_constraints(row,world.spec)
    for _,goal in sorted(candidates,key=lambda item:item[0]):
        for name,index in body.index.items():
            if name.startswith('right_') and any(t in name for t in ['shoulder','elbow','clavicle']):goal[index]=start[index]
        previous=start.copy();poses=[]
        for u in np.linspace(0,1,41)[1:]:
            nominal=start*(1-u)+goal*u
            q,report=fit_work_contact(body,targets,row,initial=previous,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=180,posture_weight=20.)
            if not report['accepted']:break
            poses.append(q.copy());previous=q
        if len(poses)!=40:continue
        for q in poses:world.execute_pose(q,world.anchors,world.foot_yaws,duration=.15)
        return
    raise WorkPostureUnavailable('No complete body preparation clears the furniture with the free driver')


def driver_route(world,key):
    """Plan wrist paths outside the body and furniture, with dense checks.

    Rotating a handle along a straight Cartesian path also swings the wrist
    around the handle. Interpolate the wrist instead, then derive the handle.
    The raised outside routes let the arm pass around the torso and table legs.
    """
    from world import mixrot
    from leg_clearance import boxes
    from validate_body_motion import ClothingAudit,validate_pose
    body=world.operator;start_q=world.operator_q.copy();row=world.current_row()
    row.update(stage='Position driver at '+key,connector=key,stroke=0.,tool_control=True)
    tip,axis=world.tool_site(key);rotation=world.tool_rotation(axis);handle=tip-axis*.14
    initial_rotation=R.from_quat(row['tool'][1],scalar_first=True);offset=wrist_offset('right','tool')
    first=np.array(row['tool'][0])+initial_rotation.apply(offset);last=handle+rotation.apply(offset);standoff=last-axis*.15
    body.set(start_q);shoulder=body.point('right_shoulder');frame=R.from_euler('z',start_q[3]);right=frame.apply([1,0,0]);forward=frame.apply([0,1,0])
    routes=[[first,standoff,last]]
    for lateral in [.25,.15,.35]:
        for drop in [-.2,-.1,0.,.1]:
            routes.append([first,shoulder+right*lateral+forward*.05-[0,0,drop],shoulder+right*.12+forward*.30-[0,0,drop],standoff,last])
    obstacles=boxes(row,world.spec)
    def tool_clear(tool):return driver_tool_clear(tool,obstacles)
    surface=ClothingAudit()
    for route_index,nodes in enumerate(routes):
        previous=start_q.copy();previous_tool=row['tool'];records=[];failed=False;legs=len(nodes)-1
        for leg,(a,z) in enumerate(zip(nodes,nodes[1:])):
            for u in np.linspace(0,1,31)[1:]:
                fraction=(leg+u)/legs;r=mixrot(initial_rotation,rotation,min(1.,fraction*2));point=a*(1-u)+z*u
                tool=[(point-r.apply(offset)).tolist(),r.as_quat(scalar_first=True).tolist()]
                if not tool_clear(tool):failed=True;break
                sample={**row,'tool':tool};_,targets=hand_constraints(sample,world.spec)
                q,report=body.fit(targets,sample,initial=previous,nominal=start_q,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=160)
                if not report['accepted']:failed=True;break
                ar=R.from_quat(previous_tool[1],scalar_first=True)
                for t in [.25,.5,.75]:
                    intermediate=[(np.array(previous_tool[0])*(1-t)+np.array(tool[0])*t).tolist(),mixrot(ar,r,t).as_quat(scalar_first=True).tolist()]
                    if not tool_clear(intermediate) or validate_pose(body,previous+(q-previous)*t,{**row,'tool':intermediate},surface):failed=True;break
                if failed:break
                records.append((q.copy(),tool));previous=q;previous_tool=tool
            if failed:break
        if failed:continue
        print('BODY_DRIVER_ROUTE',route_index,len(records),'poses',flush=True);return records
    raise RuntimeError('No complete driver route clears both the native body and the furniture')


def driver_tool_clear(tool,obstacles):
    """Check both tool capsules against furniture, brackets, rack and floor."""
    local=np.r_[np.c_[np.linspace(-.07,.07,31),np.zeros(31),np.zeros(31)],np.c_[np.zeros(41),np.linspace(-.02,-.14,41),np.zeros(41)]]
    radii=np.r_[np.full(31,.017),np.full(41,.003)];_,centers,rotations,half=obstacles
    position,quat=tool;points=R.from_quat(quat,scalar_first=True).apply(local)+position
    if np.min(points[:,2]-radii)<-.001:return False
    delta=np.abs(np.einsum('pbi,bij->pbj',points[:,None]-centers,rotations))-half
    gap=np.linalg.norm(np.maximum(delta,0),axis=2)+np.minimum(np.max(delta,axis=2),0)-radii[:,None]
    return bool(np.min(gap)>=-.004)
