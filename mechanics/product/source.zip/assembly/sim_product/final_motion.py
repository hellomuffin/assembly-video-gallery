"""Body-driven final lift, two-hand turn and physical setdown.

Planning copies never substitute for the executed furniture state. Every command
is checked again by EmbodiedWorld against actual physics and fixed foot contacts.
"""
import copy
import numpy as np
from scipy.spatial.transform import Rotation as R
from carried_body import CarriedBody
from task_stance import plan_stance,fit_work_contact
from plan_body_motion import stance_seed,angle_delta
from task_hands import wrist_offset,hand_constraints
from world import mixrot


def turn_plan(world):
    row=world.current_row();base=world.spec['base'];actual=R.from_quat(row['parts'][base][1],scalar_first=True);desired=R.from_quat(world.spec['finish_rotation'],scalar_first=True)
    delta=(desired*actual.inv()).as_rotvec();alternatives=[delta]
    if abs(np.linalg.norm(delta)-np.pi)<.1:alternatives.append(delta*(1-2*np.pi/np.linalg.norm(delta)))
    solutions=[]
    for vector in alternatives:
        body=CarriedBody(world.spec,row,world.operator_q,bimanual=True,comfortable=True)
        nominal=stance_seed(body,1.,world.operator_yaw,world.anchors);body.hand_rotation_override=R.from_rotvec(vector*.5)*body.reference_rotation
        midpoint,report=body.fit({},row,initial=world.operator_q,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,max_nfev=220)
        if not report['accepted']:continue
        records={};failed=False
        for indices in [range(50,-1,-1),range(51,101)]:
            previous=midpoint.copy()
            for i in indices:
                rotation=R.from_rotvec(vector*i/100)*body.reference_rotation;body.hand_rotation_override=rotation
                q,report=body.fit({},row,initial=previous,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=120)
                if not report['accepted']:failed=True;break
                records[i]=(q.copy(),rotation,float(body.predicted_row['parts'][base][0][2]),report['cost']);previous=q
            if failed:break
        if not failed:
            ordered=[records[i] for i in range(101)];score=max(r[2] for r in ordered)*10+np.mean([r[3] for r in ordered])
            solutions.append((score,body,ordered))
    if not solutions:raise RuntimeError('No collision-free bimanual turn from the selected work stance')
    _,body,records=min(solutions,key=lambda item:item[0]);return body,records


def finish(world):
    if len(world.fastened)!=len(world.connectors):raise RuntimeError('Finish requires every connector to be fastened')
    world.connector=None;world.tool_engaged=False
    # Walk to the tool rack before reaching down to it.
    park=np.array([.65,-.7,.086]);park_rotation=R.from_euler('x',np.pi)
    synthetic=world.current_row();synthetic.update(stage='Set driver in the rack',tool=[park.tolist(),park_rotation.as_quat(scalar_first=True).tolist()],stroke=0.)
    station=plan_stance(world.operator,synthetic,world.spec)
    world.stand_empty();world.stage='Walk to driver rack';world.walk_to(station)
    # Approach palm-up: the palm-down offset placed the wrist against the rack,
    # so no body posture could satisfy the actual forearm clearance.
    world.tool_control=True;world.stage='Set driver in the rack';world.tool_move(park+[0,0,.25],park_rotation,2.);world.tool_move(park,park_rotation,2.)
    world.tool_parked=True;world.tool_control=False
    base=world.spec['base'];carrier=world.spec.get('finish_grasp_part',base);second=world.spec['finish_second_grasp']
    paired=paired_floor_pickup(world,carrier)
    if not paired:
        left,_=world.site(carrier);p,r=world.pose(second['part']);right=p+r.apply(second['position']);direction=right-left
        yaw=float(np.arctan2(direction[1],direction[0]));center=(left+right)/2
        world.pickup(carrier,yaw_hint=yaw,center_hint=center[:2])
    lift_completed(world)
    if paired:
        turn_and_set_down(world);return
    same_panel=second['part']==carrier
    if same_panel:position_for_setdown(world,require_exit=False)
    goal_q=prepare_turn(world,track_left=same_panel)
    reach_second_grasp(world,goal_q=goal_q if same_panel else None)
    turn_and_set_down(world)


def position_for_setdown(world,require_exit=True):
    """Move from the pickup stance to one that reaches the final two grasps."""
    row=world.current_row();base=world.spec['base'];bp,br=world.pose(base)
    desired=R.from_quat(world.spec['finish_rotation'],scalar_first=True);delta=desired*br.inv();origin=np.array([0.,0.,world.spec['finish_height']])
    future=copy.deepcopy(row)
    future['parts']={name:[(origin+delta.apply(np.array(p)-bp)).tolist(),(delta*R.from_quat(q,scalar_first=True)).as_quat(scalar_first=True).tolist()] for name,(p,q) in row['parts'].items()}
    gp,gr=world.pose('gripper');future.update(stage='Set down completed furniture',two_hands=True,gripper=[(origin+delta.apply(gp-bp)).tolist(),(delta*gr).as_quat(scalar_first=True).tolist()])
    _,targets=hand_constraints(future,world.spec);direction=targets['right']-targets['left'];yaw=float(np.arctan2(direction[1],direction[0]))
    def exit_check(q,anchors,heading):
        try:
            path=standing_path(world.operator,future,q,anchors,{s:heading for s in anchors},heading)
            return {'accepted':True,'standing_samples':len(path)}
        except RuntimeError as error:return {'accepted':False,'reason':str(error)}
    # A flip can reverse the hand ordering without changing the person's
    # facing direction. Preserve a feasible existing stance before inferring
    # a new heading from the grasp vector or asking the feet to move.
    nominal=stance_seed(world.operator,float(np.mean([p[2] for p in targets.values()])),world.operator_yaw,world.anchors)
    q,report=fit_work_contact(world.operator,targets,future,initial=nominal,nominal=nominal,
        anchors=world.anchors,foot_yaws=world.foot_yaws,max_nfev=220)
    if report['accepted']:
        try:
            if require_exit:standing_path(world.operator,future,q,world.anchors,world.foot_yaws,world.operator_yaw)
            print('FINAL_WORK_STANCE_CURRENT',world.operator_yaw,flush=True)
            return dict(q=q,report=report,anchors={s:a.copy() for s,a in world.anchors.items()},yaw=world.operator_yaw)
        except RuntimeError:pass
    station=None;errors=[]
    for heading in [world.operator_yaw,yaw]:
        try:
            station=plan_stance(world.operator,future,world.spec,yaw_hint=heading,
                center_hint=np.mean(list(targets.values()),axis=0)[:2],candidate_check=exit_check if require_exit else None,
                distances=[.25,.30,.35,.40,.45,.50,.55,.60,.65,.70,.75,.80,.85,.90] if require_exit else None)
            break
        except RuntimeError as error:errors.append(str(error))
    if station is None:raise RuntimeError('No setdown stance and standing exit: '+str(errors))
    print('FINAL_WORK_STANCE',station['yaw'],{s:a.tolist() for s,a in station['anchors'].items()},flush=True)
    carried=CarriedBody(world.spec,world.current_row(),world.operator_q,bimanual=world.two_hands,comfortable=True)
    # Before turning, let the load follow the walking heading. Holding it
    # fixed in world orientation forces the person to walk around its corners.
    if require_exit:carried.hand_rotation_override=carried.reference_rotation
    world.stage='Carry completed furniture to working stance';world.walk_to(station,carried)
    return station


def standing_path(body,row,start,anchors,yaws,yaw):
    """Require a continuous, skin-clear route to an actual upright posture.

    A feasible crouch is not necessarily connected to standing beside a low
    panel. Check the resting furniture, fixed feet and intermediate skin before
    selecting the setdown stance. Small bounded steps preserve the IK branch.
    """
    from validate_body_motion import ClothingAudit,validate_pose
    released={**row,'held':None,'two_hands':False,'stage':'Stand before walking',
        'body_anchors':{s:np.asarray(a).tolist() for s,a in anchors.items()},'body_foot_yaws':dict(yaws),'body_support':list(anchors)}
    released.pop('second_hand_blend',None)
    nominal=stance_seed(body,1.,yaw,anchors)
    if row.get('tool_parked'):
        # Once both objects are released, use resting arms rather than the
        # bent-elbow seed used while carrying the driver.
        for side in anchors:
            for name,degrees in [('shoulder_flexion',5),('shoulder_abduction',6),('elbow',15)]:
                nominal[body.index[side+'_'+name]]=np.radians(degrees)
    goal,report=body.fit({},released,initial=nominal,nominal=nominal,anchors=anchors,foot_yaws=yaws,max_nfev=220)
    upright=lambda q:q[2]>=nominal[2]-.06 and all(q[body.index[s+'_knee']]>=np.radians(-40) for s in anchors)
    if not report['accepted'] or not upright(goal):raise RuntimeError('No upright endpoint at the setdown stance')
    surface=ClothingAudit();previous=np.array(start,copy=True);path=[]
    arm_indices=[i for name,i in body.index.items() if any(s in name for s in ['shoulder','elbow','clavicle'])]
    if validate_pose(body,previous,released,surface):raise RuntimeError('Released starting posture is not clear of the resting furniture')
    for _ in range(80):
        for dt in [.1,.05,.025]:
            q,report=body.fit({},released,initial=previous,nominal=goal,anchors=anchors,foot_yaws=yaws,continuity=previous,motion_dt=dt,max_nfev=120,posture_weight=20. if upright(previous) else 1.)
            if report['accepted'] and all(not validate_pose(body,previous+(q-previous)*u,released,surface) for u in [.25,.5,.75,1.]):break
        else:raise RuntimeError('No continuous clearance while standing from the setdown stance')
        path.append(q.copy())
        # Finish the release gesture as well as raising the pelvis. Stopping
        # at the first upright sample leaves the arms in their grasping pose.
        if upright(q) and np.max(np.abs(q[arm_indices]-goal[arm_indices]))<.12:return path
        if np.max(np.abs(q-previous))<1e-4:raise RuntimeError('Standing path remains trapped in a crouch')
        previous=q
    raise RuntimeError('Standing path did not reach an upright posture')


def prepare_turn(world,track_left=False):
    planned,records=turn_plan(world);world.stage='Prepare two-hand turn';start=world.operator_q.copy()
    body=CarriedBody(world.spec,world.current_row(),world.operator_q,comfortable=True);body.hand_rotation_override=records[0][1]
    for u in np.linspace(0,1,31)[1:]:
        nominal=start*(1-u)+records[0][0]*u
        body.set(nominal);targets={'left':body.point('left_wrist').copy()} if track_left else {}
        q,report=body.fit(targets,world.current_row(),initial=world.operator_q,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=world.operator_q,max_nfev=150)
        if not report['accepted']:raise RuntimeError('Turn preparation rejected: '+str(report))
        world.execute_pose(q,world.anchors,world.foot_yaws,carried=body)
    return records[0][0]


def lift_completed(world):
    world.max_force=160.;world.max_torque=32.
    world.stage='Lift completed furniture';body=CarriedBody(world.spec,world.current_row(),world.operator_q,bimanual=world.two_hands,comfortable=True);body.allow_floor_contact=True
    start=world.operator_q.copy();standing=stance_seed(body,1.,world.operator_yaw,world.anchors)
    for u in np.linspace(0,1,31)[1:]:
        nominal=start*(1-u)+standing*u
        q,report=body.fit({},world.current_row(),nominal=nominal,initial=world.operator_q,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=world.operator_q,max_nfev=150)
        if not report['accepted']:raise RuntimeError('Completed assembly lift rejected: '+str(report))
        world.execute_pose(q,world.anchors,world.foot_yaws,carried=body)


def paired_floor_pickup(world,carrier):
    """Acquire reachable surface grasps on the resting connected assembly."""
    from grasp_sites import completed_assembly_pairs
    p,r=world.pose(carrier);candidates=[]
    for i,grasp in enumerate(completed_assembly_pairs(world.spec,carrier)):
        rotation=r*R.from_quat(grasp['rotation'],scalar_first=True)
        normals=grasp.get('surface_normals') or [grasp['surface_normal']]
        if max(r.apply(normal)[2] for normal in normals)<.9:continue
        left=p+r.apply(grasp['position']);rp,rr=world.pose(grasp['paired']['part'])
        right=rp+rr.apply(grasp['paired']['position']);right_rotation=rr*R.from_quat(grasp['paired']['rotation'],scalar_first=True)
        if min((left+rotation.apply(wrist_offset('left','board')))[2],(right+right_rotation.apply(wrist_offset('right','board')))[2])<.039:continue
        center=(left+right)/2;stance_center=center+rotation.apply([0,.4,0])
        rank=grasp.get('priority',float(np.linalg.norm(stance_center[:2]-world.operator_q[:2])))
        candidates.append((rank,i,grasp,left,right,rotation))
    for _,index,grasp,left,right,rotation in sorted(candidates,key=lambda v:v[0]):
        row=world.current_row();row.update(stage='Grasp '+carrier,gripper=[left.tolist(),rotation.as_quat(scalar_first=True).tolist()],grasp_profile='board',two_hands=True,second_grasp=grasp['paired'])
        direction=right-left;yaw=float(np.arctan2(direction[1],direction[0]))
        # A floor grasp is useful only if the same stance can release the
        # upright assembly. A near edge can become the unreachable far edge
        # during a flip, despite an entirely clear lift and turn.
        base=world.spec['base'];bp,br=world.pose(base);desired=R.from_quat(world.spec['finish_rotation'],scalar_first=True)
        delta=desired*br.inv();origin=np.array([0.,0.,world.spec['finish_height']]);final=copy.deepcopy(row)
        final['parts']={name:[(origin+delta.apply(np.array(p)-bp)).tolist(),(delta*R.from_quat(q,scalar_first=True)).as_quat(scalar_first=True).tolist()] for name,(p,q) in row['parts'].items()}
        cp,cq=final['parts'][carrier];cr=R.from_quat(cq,scalar_first=True)
        final.update(stage='Set down completed furniture',held=carrier,gripper=[(np.array(cp)+cr.apply(grasp['position'])).tolist(),(cr*R.from_quat(grasp['rotation'],scalar_first=True)).as_quat(scalar_first=True).tolist()])
        _,targets=hand_constraints(final,world.spec)
        def setdown_check(q,anchors,heading):
            nominal=stance_seed(world.operator,float(np.mean([p[2] for p in targets.values()])),heading,anchors)
            endpoint,check=fit_work_contact(world.operator,targets,final,initial=nominal,nominal=nominal,
                anchors=anchors,foot_yaws={s:heading for s in anchors},max_nfev=220)
            if check['accepted']:
                try:standing_path(world.operator,final,endpoint,anchors,{s:heading for s in anchors},heading)
                except RuntimeError as error:return {'accepted':False,'reason':str(error)}
            return check
        try:
            station=plan_stance(world.operator,row,world.spec,yaw_hint=yaw,center_hint=((left+right)/2)[:2],candidate_check=setdown_check)
        except RuntimeError:
            print('PAIRED_GRASP_SETDOWN_REJECTED',carrier,index,flush=True);continue
        world.second_grasp=copy.deepcopy(grasp['paired']);print('PAIRED_FLOOR_GRASP',carrier,index,flush=True)
        world.pickup(carrier,grasp_pose={**grasp,'candidate':index},station=station)
        reach_second_grasp(world,allow_load_motion=False,goal_q=station['q']);return True
    return False


def reach_second_grasp(world,allow_load_motion=True,goal_q=None):
    """Plan the free hand around panel edges before engaging its final grasp."""
    from validate_body_motion import ClothingAudit
    from leg_clearance import boxes
    surface=ClothingAudit();row=world.current_row();row.pop('second_hand_blend',None)
    start=copy.deepcopy(world.rows[-1]['body_visual']['right']);goal_row={**row,'two_hands':True}
    hands,_=hand_constraints(goal_row,world.spec);goal=hands['right'];rotation=R.from_quat(goal[1],scalar_first=True)
    if goal_q is not None:
        # Walking stores continuous yaw, while a newly searched station uses
        # a principal angle. Keep equivalent poses on the same revolution.
        goal_q=np.array(goal_q,copy=True)
        goal_q[3]=world.operator_q[3]+angle_delta(goal_q[3],world.operator_q[3])
        _,targets=hand_constraints(goal_row,world.spec)
        goal_q,report=world.operator.fit(targets,goal_row,initial=goal_q,nominal=goal_q,anchors=world.anchors,foot_yaws=world.foot_yaws,max_nfev=220)
        if not report['accepted']:raise RuntimeError('Actual two-hand pickup endpoint rejected: '+str(report))
        if allow_load_motion and panel_second_grasp(world,goal_q):return
        return joint_second_grasp(world,goal_q)
    normal=rotation.apply(wrist_offset('right','board'));normal[2]=0.;normal/=max(np.linalg.norm(normal),1e-9)
    part=(row.get('second_grasp') or world.spec['finish_second_grasp'])['part'];p,quat=row['parts'][part];pr=R.from_quat(quat,scalar_first=True)
    top=float(p[2]+abs(pr.as_matrix()[2])@np.array(world.parts[part]['size'])/2)
    routes=[[]]
    for height in [.12,.25]:
        for clearance in [.12,.22]:
            high=max(start[0][2],top+height);outside=np.array(goal[0])+normal*clearance
            first=np.array(start[0]);first[2]=high;above=outside.copy();above[2]=high
            routes.append([[first.tolist(),start[1]],[above.tolist(),goal[1]],[outside.tolist(),goal[1]]])
    failures=[]
    for route in routes:
        previous=world.operator_q.copy();records=[];start_q=previous.copy()
        for u in np.linspace(0,1,81)[1:]:
            nominal=start_q if goal_q is None else start_q*(1-u)+goal_q*u
            sample={**row,'stage':'Reach second support grasp','second_hand_blend':{'start':start,'via':route,'wrist_space':goal_q is not None,'fraction':float(u)}}
            _,targets=hand_constraints(sample,world.spec)
            q,report=world.operator.fit(targets,sample,initial=previous,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=160)
            if not report['accepted'] and goal_q is not None:
                alternate,check=world.operator.fit(targets,sample,initial=nominal,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=220)
                if (not check['accepted'],check['cost'])<(not report['accepted'],report['cost']):q,report=alternate,check
            hits=surface.collisions(world.operator.landmarks(q),boxes(sample,world.spec)) if report['accepted'] else {}
            if not report['accepted'] or hits:
                failures.append({'fraction':float(u),'report':report,'surface':hits});break
            records.append((float(u),q.copy()));previous=q
        if len(records)!=80:continue
        print('SECOND_GRASP_ROUTE',len(route),'waypoints',flush=True);world.stage='Reach second support grasp';previous_fraction=0.
        for u,q in records:
            world.execute_pose(q,world.anchors,world.foot_yaws,duration=.08,hand_blend={'start':start,'via':route,'wrist_space':goal_q is not None,'from':previous_fraction,'to':u});previous_fraction=u
        world.two_hands=True;world.second_hand_blend=None;return
    if allow_load_motion:coupled_second_grasp(world)
    else:raise RuntimeError('No clear second-hand approach before lifting: '+str(failures))


def panel_second_grasp(world,goal_q):
    """Route the free wrist around a panel face before closing the grasp.

    An above-panel hand may need to withdraw past the near edge, descend,
    and approach from below. An over-the-top shortcut can put the upper arm
    through the panel even when both wrist endpoints are clear. Candidate
    routes derive from the actual panel bounds; all body and native-skin
    constraints remain active for the complete planned and executed path.
    """
    row=world.current_row();row.pop('second_hand_blend',None)
    start=copy.deepcopy(world.rows[-1]['body_visual']['right']);start_q=world.operator_q.copy()
    hands,targets=hand_constraints({**row,'two_hands':True},world.spec);goal=hands['right'];rotation=R.from_quat(goal[1],scalar_first=True)
    part=(row.get('second_grasp') or world.spec['finish_second_grasp'])['part'];p,quat=row['parts'][part];p=np.array(p);pr=R.from_quat(quat,scalar_first=True)
    half=np.array(world.parts[part]['size'])/2;thin=int(np.argmin(half));planar=[i for i in range(3) if i!=thin]
    world.operator.set(start_q);shoulder=pr.inv().apply(world.operator.point('right_shoulder')-p)
    near=max(planar,key=lambda i:abs(shoulder[i])/half[i]);near_sign=1 if shoulder[near]>=0 else -1
    first=pr.inv().apply(world.operator.point('right_wrist')-p);last=pr.inv().apply(targets['right']-p)
    for face in [-1,1]:
        for clearance in [.06,.10,.15]:
            outside=first.copy();outside[near]=near_sign*(half[near]+clearance)
            around=outside.copy();around[thin]=face*(half[thin]+clearance)
            approach=last.copy();approach[thin]=around[thin]
            via=[[(p+pr.apply(point)-rotation.apply(wrist_offset('right','board'))).tolist(),goal[1]] for point in [outside,around,approach]]
            previous=start_q.copy();records=[]
            for u in np.linspace(0,1,81)[1:]:
                blend={'start':start,'via':via,'wrist_space':True,'fraction':float(u)}
                sample={**row,'stage':'Reach second support grasp','second_hand_blend':blend};_,active=hand_constraints(sample,world.spec)
                nominal=start_q*(1-u)+goal_q*u
                q,report=world.operator.fit(active,sample,initial=previous,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=160)
                if not report['accepted']:break
                records.append((float(u),q.copy()));previous=q
            if len(records)!=80:continue
            print('PANEL_SECOND_GRASP',part,'face',face,'clearance',clearance,flush=True)
            world.stage='Reach second support grasp';previous_fraction=0.
            for u,q in records:
                world.execute_pose(q,world.anchors,world.foot_yaws,duration=.16,hand_blend={'start':start,'via':via,'wrist_space':True,'from':previous_fraction,'to':u});previous_fraction=u
            world.two_hands=True;world.second_hand_blend=None;return True
    return False


def joint_second_grasp(world,goal_q):
    """Derive the approach from articulated motion, then execute its wrists."""
    row=world.current_row();row.pop('second_hand_blend',None)
    start_q=world.operator_q.copy();start=copy.deepcopy(world.rows[-1]['body_visual']['right'])
    _,targets=hand_constraints(row,world.spec)
    goal_hands,_=hand_constraints({**row,'two_hands':True},world.spec)
    start_rotation=R.from_quat(start[1],scalar_first=True);goal_rotation=R.from_quat(goal_hands['right'][1],scalar_first=True)
    previous=start_q.copy();records=[];nodes=[]
    for u in np.linspace(0,1,81)[1:]:
        nominal=start_q*(1-u)+goal_q*u;world.operator.set(nominal)
        targets['right']=world.operator.point('right_wrist').copy()
        q,report=world.operator.fit(targets,row,initial=nominal,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=180)
        if not report['accepted']:raise RuntimeError('Articulated second-hand approach rejected: '+str(report))
        rotation=mixrot(start_rotation,goal_rotation,float(u));position=world.operator.point('right_wrist')-rotation.apply(wrist_offset('right','board'))
        nodes.append([position.tolist(),rotation.as_quat(scalar_first=True).tolist()]);records.append((float(u),q.copy()));previous=q
    print('JOINT_SECOND_GRASP',len(records),'poses',flush=True);world.stage='Reach second support grasp';previous_fraction=0.
    for u,q in records:
        world.execute_pose(q,world.anchors,world.foot_yaws,duration=.12,hand_blend={'start':start,'via':nodes[:-1],'wrist_space':True,'from':previous_fraction,'to':u});previous_fraction=u
    world.two_hands=True;world.second_hand_blend=None


def coupled_second_grasp(world):
    """Reach around the edge while the supporting arm repositions the load."""
    row=world.current_row();row.pop('second_hand_blend',None);row['stage']='Reach second support grasp'
    start=copy.deepcopy(world.rows[-1]['body_visual']['right'])
    _,turn=turn_plan(world);endpoint=turn[0][0];failures=[]
    hands,_=hand_constraints({**row,'two_hands':True},world.spec);goal=hands['right']
    outward=R.from_quat(goal[1],scalar_first=True).apply([0,1,0])
    for height,clearance in [(.15,0),(.15,.06),(.22,.06),(.22,.12)]:
        # Reach the outside edge while still above the board, then lower.
        # A sinusoidal shortcut descends before the wrist has cleared the edge.
        above=np.array(goal[0])+outward*clearance+[0,0,height];outside=np.array(goal[0])+outward*clearance
        via=[[above.tolist(),goal[1]],[outside.tolist(),goal[1]]]
        blend={'start':start,'reference':copy.deepcopy(row['gripper']),'wrist_space':True,'via':via}
        body=CarriedBody(world.spec,row,world.operator_q,bimanual=True,comfortable=True);body.hand_rotation_override=body.reference_rotation
        previous=world.operator_q.copy();records=[]
        for u in np.linspace(0,1,121)[1:]:
            sample={**row,'second_hand_blend':{**blend,'fraction':float(u)}}
            nominal=world.operator_q*(1-u)+endpoint*u
            q,report=body.fit({},sample,initial=previous,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=160)
            if not report['accepted']:
                for seed in [nominal,endpoint]:
                    alternate,check=body.fit({},sample,initial=seed,nominal=nominal,anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=220)
                    if (not check['accepted'],check['cost'])<(not report['accepted'],report['cost']):q,report=alternate,check
                    if report['accepted']:break
            if not report['accepted']:
                failures.append({'height':height,'clearance':clearance,'fraction':float(u),'report':report});break
            records.append((float(u),q.copy()));previous=q
        if len(records)!=120:continue
        print('COUPLED_EDGE_GRASP',height,clearance,flush=True);world.stage='Reach second support grasp';previous_fraction=0.
        for u,q in records:
            world.execute_pose(q,world.anchors,world.foot_yaws,duration=.12,carried=body,hand_blend={**blend,'from':previous_fraction,'to':u});previous_fraction=u
        world.two_hands=True;world.second_hand_blend=None;return
    raise RuntimeError('No complete coupled second-hand approach clears the assembled furniture: '+str(failures))


def turn_and_set_down(world,final_station=None):
    """Continue from two actual support grasps through turn, release and rest."""
    base=world.spec['base']
    body,records=turn_plan(world);world.stage='Turn completed furniture upright'
    for q,rotation,_,_ in records:
        body.hand_rotation_override=rotation;world.execute_pose(q,world.anchors,world.foot_yaws,duration=.12,carried=body)
    if final_station is None:final_station=position_for_setdown(world)
    lower_completed(world,final_station)


def lowering_plan(world,final_station):
    """Plan coordinated lowering with the load path derived from the body."""
    base=world.spec['base']
    body=CarriedBody(world.spec,world.current_row(),world.operator_q,bimanual=True,comfortable=True);body.allow_floor_contact=True
    hp,hr=world.pose('gripper');bp,br=world.pose(base);offset=hr.inv().apply(bp-hp);relative=hr.inv()*br
    desired=R.from_quat(world.spec['finish_rotation'],scalar_first=True)*relative.inv();goal=np.array([0.,0.,world.spec['finish_height']])-desired.apply(offset)
    start_q=world.operator_q.copy()
    final_q=final_station['q'].copy();final_q[3]=start_q[3]+angle_delta(final_q[3],start_q[3])
    # Straight hand interpolation can leave the two-arm workspace even when
    # both endpoints are reachable. Let coordinated body motion determine the
    # intermediate load path, with the exact placement target at the endpoint.
    previous=start_q.copy();records=[]
    for u in np.linspace(0,1,101)[1:]:
        rotation=mixrot(hr,desired,u);body.hand_rotation_override=rotation
        nominal=start_q*(1-u)+final_q*u
        targets={} if u<1 else {'left':goal+desired.apply(wrist_offset('left',world.grasp_profile))}
        q,report=fit_work_contact(body,targets,world.current_row(),initial=previous,nominal=nominal,
            anchors=world.anchors,foot_yaws=world.foot_yaws,continuity=previous,max_nfev=180,posture_weight=10.)
        if not report['accepted']:raise RuntimeError('Physical setdown plan rejected: '+str(report))
        records.append((q.copy(),rotation));previous=q
    return body,records


def lower_completed(world,final_station):
    """Execute coupled lowering, then release the load and stand."""
    world.stage='Set down completed furniture';body,records=lowering_plan(world,final_station)
    for q,rotation in records:
        body.hand_rotation_override=rotation
        world.execute_pose(q,world.anchors,world.foot_yaws,carried=body,track_load=True)
    world.advance(1.)
    release_completed_when_supported(world)
    world.two_hands=False
    path=standing_path(world.operator,world.current_row(),world.operator_q,world.anchors,world.foot_yaws,world.operator_yaw)
    world.stage='Stand before walking'
    for q in path:world.execute_pose(q,world.anchors,world.foot_yaws)
    world.stage='Released · standing under gravity';world.advance(2.)



def release_completed_when_supported(world):
    """Allow real contact settling while retaining the grasp until release is stable.

    Reaching the floor does not imply the connected load has stopped rocking.
    Failed release probes restore exact physics and controller state. Time then
    advances with the original bounded grasp, body checks and floor contacts.
    The same drift/speed limits must pass within five additional seconds.
    """
    for attempt in range(11):
        require_floor_placement(world)
        if world.release_if_supported('Check floor support before releasing furniture'):
            return
        if attempt==10:
            raise RuntimeError('Completed furniture is not stable on its resting contacts')
        world.stage='Settle completed furniture on floor'
        world.advance(.5)


def require_floor_placement(world):
    """Reject a missed physical setdown before releasing the load."""
    base=world.spec['base'];position,rotation=world.pose(base)
    desired=R.from_quat(world.spec['finish_rotation'],scalar_first=True)
    floor=min(world.pose(n)[0][2]-abs(world.pose(n)[1].as_matrix()[2])@np.asarray(world.parts[n]['size'])/2 for n in world.parts)
    if np.linalg.norm(position-[0,0,world.spec['finish_height']])>.006 or (rotation*desired.inv()).magnitude()>np.radians(2) or not -.002<=floor<=.003:
        raise RuntimeError('Executed furniture has not reached its planned floor placement')
