"""Conservative floor routes before articulated step and load planning."""
import heapq
import numpy as np
from scipy.spatial import ConvexHull


def plan_route(start,goal,obstacles,radius=.22,spacing=.1):
    start=np.asarray(start)[:2];goal=np.asarray(goal)[:2]
    axis=np.arange(-2.8,2.8001,spacing);nx=len(axis);grid=np.stack(np.meshgrid(axis,axis,indexing='ij'),axis=-1);flat=grid.reshape(-1,2)
    clear=np.ones(len(flat),dtype=bool)
    signs=np.array(np.meshgrid([-1,1],[-1,1],[-1,1])).T.reshape(-1,3)
    for center,rotation,half in zip(*obstacles[1:]):
        corners=center+(signs*half)@rotation.T
        if corners[:,2].min()>.10:continue
        hull=ConvexHull(corners[:,:2]);eq=hull.equations
        clear&=np.any(flat@eq[:,:2].T+eq[:,2]>radius,axis=1)
    clear=clear.reshape(nx,nx)
    def nearest(point):
        distances=np.linalg.norm(flat-point,axis=1);distances[~clear.ravel()]=np.inf
        index=int(np.argmin(distances))
        if distances[index]>.4:raise RuntimeError('No clear route endpoint near the declared work stance')
        return tuple(np.unravel_index(index,(nx,nx)))
    source=nearest(start);target=nearest(goal);queue=[(0.,source)];cost={source:0.};previous={}
    moves=[(x,y) for x in [-1,0,1] for y in [-1,0,1] if x or y]
    while queue:
        _,node=heapq.heappop(queue)
        if node==target:break
        for dx,dy in moves:
            nxt=(node[0]+dx,node[1]+dy)
            if not (0<=nxt[0]<nx and 0<=nxt[1]<nx) or not clear[nxt]:continue
            if dx and dy and (not clear[node[0]+dx,node[1]] or not clear[node[0],node[1]+dy]):continue
            candidate=cost[node]+np.hypot(dx,dy)
            if candidate>=cost.get(nxt,np.inf):continue
            cost[nxt]=candidate;previous[nxt]=node
            heapq.heappush(queue,(candidate+np.linalg.norm(np.array(nxt)-target),nxt))
    if target not in cost:raise RuntimeError('No floor route connects the work stations')
    nodes=[target]
    while nodes[-1]!=source:nodes.append(previous[nodes[-1]])
    nodes.reverse();points=[grid[node] for node in nodes]
    # Preserve obstacle corners while avoiding a stop at every grid cell.
    simplified=[]
    for i,p in enumerate(points):
        if i==0 or i==len(points)-1 or not np.array_equal(np.array(nodes[i])-nodes[i-1],np.array(nodes[i+1])-nodes[i]):simplified.append(p)
    if np.linalg.norm(simplified[-1]-goal)>.01:simplified.append(goal)
    return [np.array(p) for p in simplified]
