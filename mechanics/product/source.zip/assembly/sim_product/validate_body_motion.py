"""Independent acceptance gate for articulated candidate motions.

This checks kinematics and quasi-static support, not dynamically balanced human
control. Pose-solver success alone is never a clearance certificate.
"""
from pathlib import Path
import os,sys
import numpy as np
from scipy.spatial.transform import Rotation as R
from articulated_body import Body,THIGH,SHIN,UPPER_ARM,FOREARM
from leg_clearance import boxes,interpolate_obstacles,segment_box_distances
from audit_leg_surface import triangle_box_intersections
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'sim_v5'))
from human_surface import Surface
from task_hands import hand_constraints


class ClothingAudit:
    def __init__(self):
        os.environ['HUMAN_SURFACE_NECK']='1';os.environ['HUMAN_SURFACE_HEAD_GAZE']='1';os.environ['HUMAN_SURFACE_FOREARMS']='1'
        self.surface=Surface()
        faces=self.surface.faces
        self.triangles=np.array([[f[0],f[j],f[j+1]] for f in faces for j in range(1,len(f)-1)])
        self.used=np.unique(self.triangles)

    def collisions(self,v,obstacles):
        operator=dict(shoulder_center=v['shoulder'],hip=v['hip'],forward=-np.array(v['back']),head=v['head'],camera_quaternion=v['camera_quaternion'],legs=v['legs'],arms={'hand_'+k:a for k,a in v['arms'].items()},segment_frames=v['segment_frames'],clavicles=v.get('clavicles',{}))
        vertices=self.surface.deform({'operator':operator});hits={}
        triangles=vertices[self.triangles];lower=triangles.min(axis=1);upper=triangles.max(axis=1)
        for name,center,rotation,half in zip(*obstacles):
            extent=np.abs(rotation)@half
            possible=np.all(lower<=center+extent,axis=1)&np.all(upper>=center-extent,axis=1)
            if not possible.any():continue
            local=(triangles[possible]-center)@rotation
            count=int(triangle_box_intersections(local,half).sum())
            if count:hits[name]=count
        floor=float(vertices[self.used,2].min())
        if floor<-.001:hits['floor']=floor
        return hits


def validate_pose(body,q,row,clothing=None):
    errors=[];q=np.array(q)
    if q.shape!=(body.nvars,) or not np.isfinite(q).all():return ['invalid joint vector']
    if np.any(q<body.bounds[0]-1e-7) or np.any(q>body.bounds[1]+1e-7):errors.append('joint limit')
    if body.comfortable and not body.working_posture_valid(q):errors.append('working posture limit')
    body.obstacles(row);v=body.landmarks(q)
    for side,sign in [('left','-1'),('right','1')]:
        actual=np.linalg.norm(np.diff(v['legs'][sign],axis=0),axis=1)
        if not np.allclose(actual,[THIGH,SHIN],atol=1e-8):errors.append(side+' leg length')
        actual=np.linalg.norm(np.diff(v['arms'][side],axis=0),axis=1)
        if not np.allclose(actual,[UPPER_ARM,FOREARM],atol=1e-8):errors.append(side+' arm length')
    _,targets=hand_constraints(row,body.spec)
    for side,target in targets.items():
        error=float(np.linalg.norm(body.point(side+'_wrist')-target))
        if error>=.008:errors.append({'active_wrist':side,'error_m':error})
    for side,anchor in row.get('body_anchors',{}).items():
        error=float(np.linalg.norm(body.point(side+'_ankle')-anchor))
        if error>=.008:errors.append({'foot_anchor':side,'error_m':error})
        desired=R.from_euler('z',row['body_foot_yaws'][side])
        actual=R.from_matrix(body.d.xmat[body.m.body(side+'_foot').id].reshape(3,3))
        if (desired.inv()*actual).magnitude()>.05:errors.append({'foot_orientation':side})
    pen,hits=body.collision_penalties()
    if hits:errors.append({'penetration':hits})
    if pen.max()>.004:errors.append({'clearance_violation_m':float(pen.max())})
    if body.support_gap()<.005:errors.append({'support_margin_m':body.support_gap()})
    if row.get('body_support'):
        from scipy.spatial import ConvexHull
        vertices=[]
        for side in row['body_support']:
            geom=body.m.geom(side+'_shoe').id;rotation=body.d.geom_xmat[geom].reshape(3,3)
            for x in [-.065,.065]:
                for y in [-.13,.13]:vertices.append((body.d.geom_xpos[geom]+rotation@np.array([x,y,-.04]))[:2])
        equations=ConvexHull(np.array(vertices)).equations
        margin=float(np.min(-(equations[:,:2]@body.load_center()[:2]+equations[:,2])))
        if margin<.005:errors.append({'declared_support_margin_m':margin})
    if clothing:
        hits=clothing.collisions(v,boxes(row,body.spec))
        if hits:errors.append({'rendered_clothing':hits})
    return errors


def interpolate_row(previous,row,u):
    """Interpolate the scene exactly as the dense motion acceptance audit."""
    sample=dict(row);sample['parts']={}
    for name,(p,quat) in row['parts'].items():
        ap,aq=previous['parts'][name];ar=R.from_quat(aq,scalar_first=True);br=R.from_quat(quat,scalar_first=True)
        rotation=R.from_rotvec((br*ar.inv()).as_rotvec()*u)*ar
        sample['parts'][name]=[(np.array(ap)*(1-u)+np.array(p)*u).tolist(),rotation.as_quat(scalar_first=True).tolist()]
    if 'body_support' in row and 'body_support' in previous:sample['body_support']=sorted(set(row['body_support'])|set(previous['body_support']))
    for key in ['gripper','tool']:
        if key not in row:continue
        ap,aq=previous[key];bp,bq=row[key];ar=R.from_quat(aq,scalar_first=True);br=R.from_quat(bq,scalar_first=True)
        sample[key]=[(np.array(ap)*(1-u)+np.array(bp)*u).tolist(),(R.from_rotvec((br*ar.inv()).as_rotvec()*u)*ar).as_quat(scalar_first=True).tolist()]
    sample['stroke']=previous.get('stroke',0)*(1-u)+row.get('stroke',0)*u
    if row.get('second_hand_blend') and previous.get('second_hand_blend'):
        sample['second_hand_blend']=dict(row['second_hand_blend']);sample['second_hand_blend']['fraction']=previous['second_hand_blend']['fraction']*(1-u)+row['second_hand_blend']['fraction']*u
    if 'body_anchors' in row and 'body_anchors' in previous:
        sample['body_anchors']={s:(np.array(previous['body_anchors'][s])*(1-u)+np.array(a)*u).tolist() for s,a in row['body_anchors'].items()}
        sample['body_foot_yaws']={s:previous['body_foot_yaws'][s]*(1-u)+a*u for s,a in row['body_foot_yaws'].items()}
    return sample


def validate_transition(body,previous,row,q,subsamples=3):
    """Reject crossings between accepted endpoints using the native skin."""
    failures=[];start=np.asarray(previous['body_q']);q=np.asarray(q)
    for j in range(1,subsamples+1):
        u=j/(subsamples+1);sample=interpolate_row(previous,row,u);pose=start*(1-u)+q*u
        errors=validate_pose(body,pose,sample)
        hits=body.surface_checker().contacts(body,pose)[1]
        if hits:errors.append({'rendered_clothing':hits})
        if errors:failures.append({'between_fraction':u,'errors':errors})
    return failures


def validate(rows,qs,spec,subsamples=3,clothing=True):
    if len(rows)!=len(qs) or not rows:raise ValueError('Every recorded frame must have an articulated state')
    body=Body(spec,comfortable=True);surface=ClothingAudit() if clothing else None;failures=[];checked=0
    for i,(row,q) in enumerate(zip(rows,qs)):
        errors=validate_pose(body,q,row,surface);checked+=1
        if errors:failures.append(dict(frame=i,errors=errors))
        if i==0:continue
        dt=row['t']-rows[i-1]['t'];delta=np.array(q)-qs[i-1]
        if dt<=0:raise ValueError('Motion times must increase')
        if np.linalg.norm(delta[:3])/dt>1.5 or np.max(np.abs(delta[3:])/dt)>np.radians(180):failures.append(dict(frame=i,errors=['motion speed exceeds configured limit']))
        for j in range(1,subsamples+1):
            u=j/(subsamples+1);sample=interpolate_row(rows[i-1],row,u)
            errors=validate_pose(body,np.array(qs[i-1])*(1-u)+np.array(q)*u,sample,surface);checked+=1
            if errors:failures.append(dict(frame=i,between_fraction=u,errors=errors))
    return dict(passed=not failures,checked_poses=checked,failures=failures,scope=__doc__)


def validate_parallel(rows,qs,spec,subsamples=3,clothing=True,workers=None):
    """Audit independent time spans with one overlapping boundary pose."""
    from concurrent.futures import ProcessPoolExecutor
    workers=int(workers or os.environ.get('BODY_AUDIT_WORKERS','8'))
    if workers<=1 or len(rows)<200:return validate(rows,qs,spec,subsamples,clothing)
    width=int(np.ceil(len(rows)/workers));jobs=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for start in range(0,len(rows),width):
            offset=max(0,start-1);end=min(len(rows),start+width)
            jobs.append((start,offset,pool.submit(validate,rows[offset:end],qs[offset:end],spec,subsamples,clothing)))
        failures=[];checked=0
        for start,offset,job in jobs:
            report=job.result();checked+=report['checked_poses']-(1 if start else 0)
            for failure in report['failures']:
                if start and failure['frame']==0:continue
                failures.append({**failure,'frame':failure['frame']+offset})
    return dict(passed=not failures,checked_poses=checked,failures=failures,scope=__doc__)
