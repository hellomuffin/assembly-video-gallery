"""Render immutable physics + kinematic records using disjoint frame jobs."""
import os,sys,json,subprocess,concurrent.futures,hashlib
from pathlib import Path
H=Path(__file__).resolve().parent;O=H.parent/'outputs/product_v1';B=Path(os.environ.get('BLENDER_EXECUTABLE','/tmp/product-blender/blender'))
if not B.exists():B=H.parent/'sim_v2/vendor/blender-4.5.3-linux-x64/blender'
jobs=[];manifest={'renders':[]}
for name in sys.argv[1:] or ['table','shelf']:
 folder=O/f'{name}_1';rows=json.loads((folder/'trajectory.json').read_text())
 files=[folder/'asset.json',folder/'trajectory.json',folder/'visuals.json',H/'render.py',H/'assets/hand_poses.json',H.parent/'sim_v2/render_blender.py',H.parent/'sim_v3/render_hand.py',H.parent/'sim_v5/human_surface.py',H.parent/'sim_v5/assets/makehuman/base.obj',H.parent/'sim_v5/assets/makehuman/default_weights.mhw',H.parent/'sim_v5/assets/makehuman/default.mhskel']
 signature={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files};cache=folder/'render-cache.json'
 if not cache.exists() or json.loads(cache.read_text())!=signature:
  for view in ['overview','ego','detail']:
   for image in (folder/view).glob('*.jpg'):image.unlink()
 cache.write_text(json.dumps(signature,sort_keys=True))
 first=next(i for i,r in enumerate(rows) if r['stage'].startswith('Tighten clockwise'))
 end=next(i for i in range(first,len(rows)) if rows[i]['stage']=='Withdraw driver')
 choices={'overview':list(range(0,len(rows),4)),'ego':list(range(0,len(rows),2)),'detail':list(range(max(0,first-15),min(len(rows),end+15)))}
 for view,indices in choices.items():
  manifest['renders'].append({'furniture':name,'view':view,'indices':indices,'speed':4 if view=='overview' else 2 if view=='ego' else 1,'trajectory_sha256':hashlib.sha256((folder/'trajectory.json').read_bytes()).hexdigest(),'visuals_sha256':hashlib.sha256((folder/'visuals.json').read_bytes()).hexdigest()})
  for shard in range(4):jobs.append((name,view,shard,indices[shard::4]))
def run(item,number):
 name,view,shard,indices=item
 indices=[i for i in indices if not (O/f'{name}_1'/view/f'{i:06d}.jpg').exists()]
 if not indices:return
 env={**os.environ,'PRODUCT':name,'VIEWS':view,'INDICES':','.join(map(str,indices)),'CUDA_VISIBLE_DEVICES':str(number%2),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'2'}
 with (O/f'{name}-{view}-{shard}.log').open('w') as log:
  subprocess.run([str(B),'-b','-t','2','--python-exit-code','1','-P',str(H/'render.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',name,view,shard,len(indices),flush=True)
(O/'render-manifest.json').write_text(json.dumps(manifest,indent=2))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 fs=[pool.submit(run,j,i) for i,j in enumerate(jobs)]
 for f in concurrent.futures.as_completed(fs):f.result()
(O/'render-manifest.json').write_text(json.dumps(manifest,indent=2))
