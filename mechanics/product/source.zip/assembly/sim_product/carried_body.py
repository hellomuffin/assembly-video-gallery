"""Couple a carried assembly to the articulated hand during motion planning.

During transport the hand path is an output of body motion. It is not an
independent world-space target that the legs must contort to follow. These
object transforms are planning predictions and must be executed in physics.
"""
import copy
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation as R
from articulated_body import Body
from task_hands import wrist_offset
from leg_clearance import boxes


class CarriedBody(Body):
    def __init__(self,spec,reference_row,reference_q,side='left',bimanual=False,comfortable=False):
        self.coupling=None;self.hand_rotation_override=None;self.bimanual=bimanual;self.allow_mating_contacts=False;self.allow_floor_contact=False
        held=reference_row.get('held')
        if held is None:raise ValueError('A carried assembly requires an existing grasp')
        group={held}
        while True:
            size=len(group)
            for c in spec['connectors']:
                if c['id'] in reference_row.get('fastened',[]) and (c['a'] in group or c['b'] in group):group.update([c['a'],c['b']])
            if size==len(group):break
        carried_names={'part_'+name for name in group}
        carried_names.update('part_'+box['id'] for part in spec['parts'] if part['id'] in group for box in part.get('collision_boxes',[]))
        for connector in spec['connectors']:
            if connector.get('bracket') and connector['b'] in group:
                carried_names.update('part_'+connector['id']+':bracket_'+suffix for suffix in ['foot','upright'])
        scene_names={'floor',*('part_'+name for name in boxes(reference_row,spec)[0])}
        scene_pairs=sorted((a,b) for a in carried_names for b in scene_names-carried_names)
        super().__init__(spec,comfortable=comfortable,scene_pairs=scene_pairs)
        self.reference=copy.deepcopy(reference_row);self.carry_side=side;self.carry_group=group
        self.reference_yaw=reference_q[3]
        self.reference_gripper=np.array(reference_row['gripper'][0]);self.reference_rotation=R.from_quat(reference_row['gripper'][1],scalar_first=True)
        self.offset=wrist_offset(side,reference_row.get('grasp_profile','tool'))
        self.coupling=True
        # Include carried-object vs environment contacts in the same constrained
        # solve; resting scene contacts and internal assembly contacts are legal.
        self.pairs=[(a,b) for a in range(self.m.ngeom) for b in range(a) if self.m.geom_bodyid[a]!=self.m.geom_bodyid[b]]
        self.pair_index={tuple(sorted(pair)):i for i,pair in enumerate(self.pairs)}
        self.carried_geoms={self.m.geom(name).id for name in carried_names}
        for connector in spec['connectors']:
            if connector.get('bracket') and connector['b'] in group:
                for suffix in ['foot','upright']:self.carried_geoms.add(self.m.geom('part_'+connector['id']+':bracket_'+suffix).id)
        self.m.geom_contype[list(self.carried_geoms)]=4;self.m.geom_conaffinity[list(self.carried_geoms)]=3
        names,centers,rotations,_=boxes(reference_row,spec)
        selected=[i for i,name in enumerate(names) if self.m.geom('part_'+name).id in self.carried_geoms]
        self.carried_names=[names[i] for i in selected]
        self.carried_mocaps=np.array([self.m.body('part_'+name).mocapid[0] for name in self.carried_names])
        self.relative_positions=centers[selected]-self.reference_gripper
        self.relative_rotations=rotations[selected]
        self.part_masses={p['id']:p['mass'] for p in spec['parts'] if p['id'] in group}
        self.mating_pairs=set()
        for connector in spec['connectors']:
            a=self.m.geom('part_'+connector['a']).id
            names=[connector['b']]
            if connector.get('bracket'):names += [connector['id']+':bracket_'+suffix for suffix in ['foot','upright']]
            for name in names:self.mating_pairs.add(tuple(sorted([a,self.m.geom('part_'+name).id])))
        # Parts can intentionally rest on another assembled panel without a
        # direct fastener (for example, shelf dividers on the backboard). Keep
        # their designed touching faces as contact pairs during insertion;
        # penetration remains forbidden by the ordinary contact validator.
        parts=spec['parts']
        for item in parts:
            if item['id'] not in group:continue
            for receiver in parts:
                if receiver['id'] in group:continue
                gap=np.abs(np.asarray(item['assembly_position'])-receiver['assembly_position'])-(np.asarray(item['size'])+receiver['size'])/2
                if abs(float(np.max(gap)))<1e-8:
                    self.mating_pairs.add(tuple(sorted([self.m.geom('part_'+item['id']).id,self.m.geom('part_'+receiver['id']).id])))
        self.obstacles(reference_row)

    def project(self,row,nominal,previous,anchors,foot_yaws,support_sides,dt,track_wrist=False):
        """Preserve feasible loaded samples; repair interpolation off contacts."""
        from validate_body_motion import validate_pose
        from task_hands import hand_constraints
        self.obstacles(row);self.set(nominal)
        task_targets={self.carry_side:self.point(self.carry_side+'_wrist').copy()} if track_wrist else {}
        sample={**self.predicted_row,'body_anchors':anchors,'body_foot_yaws':foot_yaws,'body_support':support_sides}
        step=np.r_[np.full(3,.8),np.full(self.nvars-3,np.pi/2)]*dt
        if np.all(np.abs(nominal-previous)<=step+1e-9) and not validate_pose(self,nominal,sample):
            _,targets=hand_constraints(sample,self.spec)
            precise=max((np.linalg.norm(self.point(s+'_wrist')-p) for s,p in targets.items()),default=0.)<.003
            for side,anchor in anchors.items():
                precise=precise and np.linalg.norm(self.point(side+'_ankle')-anchor)<.0005
                rotation=R.from_matrix(self.d.xmat[self.m.body(side+'_foot').id].reshape(3,3))
                precise=precise and (R.from_euler('z',foot_yaws[side]).inv()*rotation).magnitude()<.005
            if precise and not self.surface_checker().contacts(self,nominal)[1]:
                return nominal.copy(),dict(accepted=True,mode='valid_interpolation',surface_checked=True)
        options=dict(initial=previous,nominal=nominal,anchors=anchors,foot_yaws=foot_yaws,
            support_sides=support_sides,continuity=previous,motion_dt=dt,max_nfev=100,posture_weight=20.)
        if track_wrist:
            from task_stance import fit_work_contact
            return fit_work_contact(self,task_targets,row,**options)
        return self.fit(task_targets,row,**options)

    def refresh_reference(self,row,q):
        """Predict from measured grasp/assembly transforms, including compliance.

        Finite-force grasps and assembled joints can flex under load. Keeping
        the pickup geometry forever makes later collision predictions stale.
        This updates only the private planning model, never physical poses.
        """
        if row.get('held') not in self.carry_group:raise ValueError('Carried group changed during transport')
        self.reference=copy.deepcopy(row);self.reference_yaw=float(q[3])
        self.reference_gripper=np.asarray(row['gripper'][0],float)
        self.reference_rotation=R.from_quat(row['gripper'][1],scalar_first=True)
        names,centers,rotations,_=boxes(row,self.spec)
        selected=[names.index(name) for name in self.carried_names]
        self.relative_positions=centers[selected]-self.reference_gripper
        self.relative_rotations=rotations[selected]
        self.obstacles(row)

    def obstacles(self,row):
        self.base_row=copy.deepcopy(row)
        super().obstacles(row)

    def set(self,q):
        if not self.coupling:
            return super().set(q)
        self.d.qpos[:3]=q[:3]
        self.d.qpos[3:7]=(R.from_euler('z',q[3])*R.from_euler('y',q[5])*R.from_euler('x',-q[4])).as_quat(scalar_first=True)
        self.d.qpos[7:]=q[6:]
        mujoco.mj_kinematics(self.m,self.d)
        rotation=R.from_euler('z',q[3]-self.reference_yaw)*self.reference_rotation if self.hand_rotation_override is None else self.hand_rotation_override
        delta=rotation*self.reference_rotation.inv()
        position=self.point(self.carry_side+'_wrist')-rotation.apply(self.offset)
        self.d.mocap_pos[self.carried_mocaps]=position+delta.apply(self.relative_positions)
        matrices=delta.as_matrix()@self.relative_rotations
        self.d.mocap_quat[self.carried_mocaps]=R.from_matrix(matrices).as_quat(scalar_first=True)
        self.planned_gripper=[position.tolist(),rotation.as_quat(scalar_first=True).tolist()]
        self.forward()

    @property
    def predicted_row(self):
        effective=copy.deepcopy(self.base_row);effective['gripper']=copy.deepcopy(self.planned_gripper)
        for name in self.carry_group:
            index=self.m.body('part_'+name).mocapid[0]
            effective['parts'][name]=[self.d.mocap_pos[index].tolist(),self.d.mocap_quat[index].tolist()]
        return effective

    def load_center(self):
        if not self.coupling:return super().load_center()
        mass=float(self.m.body_subtreemass[self.root_id]);moment=mass*self.d.subtree_com[self.root_id]
        for name,load in self.part_masses.items():
            mass+=load;moment+=load*self.d.xpos[self.m.body('part_'+name).id]
        return moment/mass

    def contact_constraint(self,contact,clearance=.012):
        if not self.coupling:return super().contact_constraint(contact,clearance)
        a,b=sorted(contact.geom);index=self.pair_index.get((a,b))
        if index is None or not self.collision_pair_enabled(a,b):return None
        human=set(self.human_geoms)
        if a not in human and b not in human:
            if not ({a,b}&self.carried_geoms) or {a,b}<=self.carried_geoms:return None
        support=a==0 and self.geom_names[b].endswith(('_shoe','_shin'))
        intentional=(self.allow_mating_contacts and (a,b) in self.mating_pairs) or (self.allow_floor_contact and a==0 and b in self.carried_geoms)
        return index,0. if support or intentional else clearance

    def dynamic_targets(self):
        if not self.bimanual:return {}
        if self.base_row.get('second_hand_blend'):
            from task_hands import hand_constraints
            return {'right':hand_constraints(self.predicted_row,self.spec)[1]['right']}
        grasp=self.base_row.get('second_grasp') or self.spec['finish_second_grasp'];index=self.m.body('part_'+grasp['part']).id;p=self.d.xpos[index];rotation=R.from_matrix(self.d.xmat[index].reshape(3,3))
        hand_rotation=rotation*R.from_quat(grasp['rotation'],scalar_first=True)
        return {'right':np.array(p)+rotation.apply(grasp['position'])+hand_rotation.apply(wrist_offset('right','board'))}
