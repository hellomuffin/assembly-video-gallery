"""Execute body-driven assembly in an isolated candidate dataset."""
import sys,json,time,hashlib,os,shutil
from pathlib import Path
# Execute the captured snapshot itself. Archiving hashes alone does not freeze
# a module that is imported later, while another trial edits the working tree.
if not os.environ.get('EMBODIED_FROZEN_EXECUTION'):
    from body_proof import EXECUTION_SOURCES,digest,H,archive_execution_sources
    furniture=sys.argv[1] if len(sys.argv)>1 else 'table'
    destination=Path(os.environ.get('EMBODIED_OUTPUT',H.parent/'outputs/body_rebuild/embodied'/f'{furniture}_1')).resolve()
    if (destination/'execution_sources').exists():raise RuntimeError('Choose a fresh output directory; the existing execution snapshot is immutable')
    arguments=sys.argv[1:]
    if len(arguments)<2:arguments=[furniture,'1']
    if len(arguments)<3:arguments.append(str(H/'assets'/f'{furniture}.json'))
    arguments[2]=str(Path(arguments[2]).resolve())
    archive_execution_sources(destination,{p:digest(H/p) for p in EXECUTION_SOURCES})
    os.environ['EMBODIED_OUTPUT']=str(destination);os.environ['EMBODIED_FROZEN_EXECUTION']='1'
    snapshot=destination/'execution_sources/sim_product/run_embodied.py'
    os.execv(sys.executable,[sys.executable,str(snapshot),*arguments])
import numpy as np
from scipy.spatial.transform import Rotation as R
from embodied_world import EmbodiedWorld
from body_proof import EXECUTION_SOURCES,EXECUTION_SOURCE_SCHEMA,digest,archive_execution_sources,verify_execution_sources,capture_continuation

H=Path(__file__).resolve().parent
name=sys.argv[1] if len(sys.argv)>1 else 'table';limit=int(sys.argv[2]) if len(sys.argv)>2 else 1
asset=Path(sys.argv[3]) if len(sys.argv)>3 else H/'assets'/f'{name}.json'
out=Path(os.environ.get('EMBODIED_OUTPUT',H.parent/'outputs/body_rebuild/embodied'/f'{name}_1'));out.mkdir(parents=True,exist_ok=True)
frozen=Path(__file__).resolve()==(out/'execution_sources/sim_product/run_embodied.py').resolve()
if not frozen:raise RuntimeError('Body execution must run from its captured source snapshot')
sources={p:digest(H/p) for p in EXECUTION_SOURCES}
resume=os.environ.get('EMBODIED_RESUME');diagnostic_resume=False;continuation=None;pending_operation=None
if not os.environ.get('EMBODIED_FROZEN_EXECUTION'):archive_execution_sources(out,sources)
if resume:
    previous=json.loads((Path(resume)/'result.json').read_text())
    pending_operation=previous.get('pending_operation')
    changed=previous['source_sha256']!=sources
    if os.environ.get('EMBODIED_DIAGNOSTIC_RESUME')=='1':
        diagnostic_resume=True;w=EmbodiedWorld.restore(resume)
    else:
        if changed and os.environ.get('EMBODIED_VERIFIED_RESUME')!='1':raise RuntimeError('Changed-source continuation requires verified checkpoint lineage or an explicitly diagnostic output')
        verify_execution_sources(resume,previous)
        if not previous.get('passed') or not previous.get('frozen_execution'):raise RuntimeError('Resume from an accepted frozen connector checkpoint')
        for backend in ['world.py','../sim_shared/engine.py']:
            if previous['source_sha256'][backend]!=sources[backend]:raise RuntimeError('Verified continuation requires the same furniture physics backend')
        w=EmbodiedWorld.restore(resume)
        if w.spec!=json.loads((Path(resume)/'asset.json').read_text()):raise RuntimeError('Checkpoint geometry or declared grasps changed during restore')
        from validate_body_motion import validate_parallel
        print('AUDIT_CONTINUATION_PREFIX',len(w.rows),flush=True)
        audit=validate_parallel(w.rows,[r['body_q'] for r in w.rows],w.spec)
        if not audit['passed']:
            (out/'continuation-rejected.json').write_text(json.dumps(audit,indent=2));raise RuntimeError('The checkpoint prefix fails current body/surface constraints')
        continuation=capture_continuation(resume,out,audit)
else:w=EmbodiedWorld(asset,1)
assembled={w.spec['base']}
for key in w.fastened:assembled.update([w.connectors[key]['a'],w.connectors[key]['b']])
remaining=[key for key in w.connectors if key not in w.fastened];start=time.time();completed=[key for key in w.connectors if key in w.fastened]

def checkpoint(folder,pending=None):
    w.save(folder);shutil.copytree(out/'execution_sources',folder/'execution_sources',dirs_exist_ok=True)
    if continuation:
        shutil.copytree(out/'execution_parent',folder/'execution_parent',dirs_exist_ok=True);shutil.copy2(out/'continuation-parent-audit.json',folder/'continuation-parent-audit.json')
    (folder/'result.json').write_text(json.dumps({'passed':True,'full_task_complete':False,'diagnostic_resume':diagnostic_resume,'completed_connectors':completed,'remaining_connectors':remaining,'source_schema':EXECUTION_SOURCE_SCHEMA,'source_sha256':sources,'frozen_execution':frozen,**({'continuation':continuation} if continuation else {}),**({'pending_operation':pending} if pending else {})},indent=2))

try:
    while remaining and len(completed)<limit:
        key=next(k for k in remaining if w.connectors[k]['a'] in assembled);c=w.connectors[key]
        phase=pending_operation.get('phase') if pending_operation else None
        if pending_operation and (pending_operation.get('connector')!=key or phase not in ['carry','place','align','fasten']):raise RuntimeError('Pending checkpoint does not match the next operation')
        if pending_operation and (w.held not in [None,c['b']] or (w.held is None and c['b'] not in assembled)):raise RuntimeError('Pending checkpoint has no valid supporting grasp')
        ready=phase=='fasten'
        if phase in ['carry','place'] and w.held!=c['b']:raise RuntimeError('Transport checkpoint requires the actual component grasp')
        w.before_place=lambda part,target,rotation:checkpoint(out/'checkpoints'/('before-place-'+key),{'connector':key,'phase':'place','position':np.asarray(target).tolist(),'rotation':rotation.as_quat(scalar_first=True).tolist()})
        if not pending_operation and c['b'] not in assembled:
            print('PICKUP',c['b'],flush=True);w.pickup(c['b'])
            checkpoint(out/'checkpoints'/('before-carry-'+key),{'connector':key,'phase':'carry'})
        if phase=='carry' or (not pending_operation and c['b'] not in assembled):
            p,r=w.pose(c['a']);offset=np.array(w.parts[c['b']]['assembly_position'])-w.parts[c['a']]['assembly_position']
            print('CARRY',c['b'],flush=True);w.carry(c['b'],p+r.apply(offset),r)
        if phase=='place':
            print('PLACE',c['b'],flush=True);w.place(c['b'],np.array(pending_operation['position']),R.from_quat(pending_operation['rotation'],scalar_first=True));w.advance(.4)
        w.before_place=None
        if not ready and w.held==c['b']:
            checkpoint(out/'checkpoints'/('before-align-'+key),{'connector':key,'phase':'align'})
            w.align(key)
        checkpoint(out/'checkpoints'/('before-'+key),{'connector':key,'phase':'fasten'});pending_operation=None
        print('FASTEN',key,flush=True);w.fasten(key);w.release();w.advance(.4);assembled.add(c['b']);remaining.remove(key);completed.append(key)
        checkpoint(out/'checkpoints'/str(len(completed)))
    complete=not remaining and '--finish' in sys.argv[4:]
    checks={}
    if complete:
        print('FINISH',flush=True);w.finish()
        errors={k:float(w.mating_error(k)[0]) for k in w.connectors};desired=R.from_quat(w.spec['finish_rotation'],scalar_first=True);current=w.pose(w.spec['base'])[1]
        floor=min(w.pose(n)[0][2]-abs(w.pose(n)[1].as_matrix()[2])@np.array(w.parts[n]['size'])/2 for n in w.parts)
        checks={'all_fastened':len(w.fastened)==len(w.connectors),'all_hands_released':w.held is None and not w.two_hands,'tool_parked':w.tool_parked,'upright_tilt_under_2deg':bool(np.dot(current.apply(desired.inv().apply([0,0,1])),[0,0,1])>np.cos(np.radians(2))),'no_floor_penetration_over_2mm':bool(floor>-.002),'connections_aligned':max(errors.values())<.006,'gravity_enabled':bool(np.allclose(w.m.opt.gravity,[0,0,-9.81]))}
    result={'passed':all(checks.values()),'checks':checks,'completed_connectors':completed,'remaining_connectors':remaining,'full_task_complete':complete and all(checks.values()),'source_sha256':sources,'diagnostic_resume':diagnostic_resume,'sim_seconds':float(w.d.time),'wall_seconds':time.time()-start,'scope':'Finite-force furniture physics and assisted grasps; articulated kinematic human with quasi-static support, not dynamically balanced human simulation.'}
except (Exception,KeyboardInterrupt) as error:
    import traceback
    traceback.print_exc()
    result={'passed':False,'error':str(error),'completed_connectors':completed,'remaining_connectors':remaining,'source_sha256':sources,'diagnostic_resume':diagnostic_resume,'wall_seconds':time.time()-start}
    print('REJECTED',repr(error),flush=True)
finally:
    result['source_schema']=EXECUTION_SOURCE_SCHEMA
    result['frozen_execution']=frozen
    if continuation:result['continuation']=continuation
    w.save(out);(out/'asset.json').write_text(json.dumps(w.spec,indent=2));(out/'result.json').write_text(json.dumps(result,indent=2))
    if all('body_visual' in row for row in w.rows):(out/'visuals.json').write_text(json.dumps([row['body_visual'] for row in w.rows]))
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}),flush=True)
if not result['passed']:raise SystemExit(1)
