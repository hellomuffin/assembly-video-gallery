"""Independent finite-difference checks and deep-penetration regression."""
import copy,unittest
import numpy as np
import mujoco
from scipy.optimize._numdiff import approx_derivative
from articulated_body import Body
from carried_body import CarriedBody
from contact_geometry import geometry, crossing_contacts
from body_differentials import COLLISION_WEIGHT
from test_articulated_body import SPEC,ROW

class DifferentialRegression(unittest.TestCase):
    def test_query_forward_matches_full_dynamics_kinematics_and_contacts(self):
        import json
        from pathlib import Path
        data=json.loads((Path(__file__).parent/'tests/fixtures/table_twohand_floor_pickup.json').read_text())
        body=Body(data['spec']);body.obstacles(data['row'])
        fields=['xpos','xmat','geom_xpos','geom_xmat','site_xpos','subtree_com','cdof']
        for q in [np.array(data['q']),body.seed('stand',[0,-1.2],.3),body.seed('squat',[0,-.7],-.2)]:
            body.set(q);query={name:getattr(body.d,name).copy() for name in fields}
            contacts=[(tuple(c.geom),c.dist,c.pos.copy(),c.frame.copy()) for c in body.d.contact]
            mujoco.mj_forward(body.m,body.d)
            for name,expected in query.items():np.testing.assert_allclose(getattr(body.d,name),expected,atol=1e-12,rtol=0)
            self.assertEqual(len(contacts),body.d.ncon)
            for actual,expected in zip(body.d.contact,contacts):
                self.assertEqual(tuple(actual.geom),expected[0]);self.assertAlmostEqual(actual.dist,expected[1],places=12)
                np.testing.assert_allclose(actual.pos,expected[2],atol=1e-12,rtol=0)
                np.testing.assert_allclose(actual.frame,expected[3],atol=1e-12,rtol=0)

    def test_carry_reference_tracks_measured_grasp_compliance(self):
        from scipy.spatial.transform import Rotation as R
        from task_hands import wrist_offset
        base=Body(SPEC);q=base.seed('stand',[0,-1],0)
        row=copy.deepcopy(ROW);row.update(held='block',tool_parked=True)
        row['gripper']=[(base.point('left_wrist')-wrist_offset('left','tool')).tolist(),[1,0,0,0]]
        body=CarriedBody(SPEC,row,q)
        measured=copy.deepcopy(row)
        measured['parts']['block']=[(np.array(row['parts']['block'][0])+[.04,-.03,.02]).tolist(),
            R.from_euler('xyz',[.04,-.12,.08]).as_quat(scalar_first=True).tolist()]
        body.refresh_reference(measured,q);body.set(q)
        predicted=body.predicted_row['parts']['block']
        np.testing.assert_allclose(predicted[0],measured['parts']['block'][0],atol=1e-12)
        np.testing.assert_allclose(R.from_quat(predicted[1],scalar_first=True).as_matrix(),
            R.from_quat(measured['parts']['block'][1],scalar_first=True).as_matrix(),atol=1e-12)
        self.assertEqual(row['parts'],ROW['parts'])

    def test_loaded_placement_projection_preserves_commanded_wrist(self):
        import json
        from pathlib import Path
        from validate_body_motion import validate_pose
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_carry_interpolation.json').read_text())
        body=CarriedBody(fixture['spec'],fixture['row'],np.asarray(fixture['reference_q']),comfortable=True)
        nominal=np.asarray(fixture['nominal']);body.set(nominal);target=body.point('left_wrist').copy()
        anchors={s:np.asarray(a) for s,a in fixture['anchors'].items()}
        q,report=body.project(fixture['row'],nominal,nominal,anchors,fixture['foot_yaws'],['left','right'],.04,track_wrist=True)
        self.assertTrue(report['accepted'],report);body.set(q)
        self.assertLess(np.linalg.norm(body.point('left_wrist')-target),.003)
        sample={**body.predicted_row,'body_anchors':fixture['anchors'],'body_foot_yaws':fixture['foot_yaws'],'body_support':['left','right']}
        self.assertEqual(validate_pose(body,q,sample),[])
        self.assertEqual(body.surface_checker().contacts(body,q)[1],{})

    def test_loaded_interpolation_preserves_floor_contacts(self):
        import json
        from pathlib import Path
        from validate_body_motion import validate_pose
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_carry_interpolation.json').read_text())
        body=CarriedBody(fixture['spec'],fixture['row'],np.array(fixture['reference_q']),comfortable=True)
        nominal=np.array(fixture['nominal']);body.set(nominal)
        # This is an actual interpolated carrying command, with more than
        # 1 mm of foot-floor penetration despite valid step endpoints.
        self.assertTrue(any(a=='floor' and depth<-.001 for a,b,depth in body.collision_penalties()[1]))
        anchors={s:np.array(a) for s,a in fixture['anchors'].items()}
        q,report=body.project(fixture['row'],nominal,nominal,anchors,fixture['foot_yaws'],['left','right'],.04)
        self.assertTrue(report['accepted'],report)
        self.assertLess(report['anchor_error_m'],1e-5)
        sample={**body.predicted_row,'body_anchors':fixture['anchors'],
            'body_foot_yaws':fixture['foot_yaws'],'body_support':['left','right']}
        self.assertEqual(validate_pose(body,q,sample),[])
        self.assertEqual(body.surface_checker().contacts(body,q)[1],{})
        repeated,check=body.project(fixture['row'],q,q,anchors,fixture['foot_yaws'],['left','right'],.04)
        self.assertEqual(check['mode'],'valid_interpolation')
        np.testing.assert_array_equal(repeated,q)

    def test_carried_box_queries_floor_and_static_receiver_contacts(self):
        from body_differentials import Kinematics
        from task_hands import wrist_offset
        from scipy.spatial.transform import Rotation as R
        spec=copy.deepcopy(SPEC);receiver=copy.deepcopy(spec['parts'][0]);receiver['id']='receiver';spec['parts'].append(receiver)
        base=Body(spec);q=base.seed('stand',[0,-1],0)
        row=copy.deepcopy(ROW);row.update(held='block',tool_parked=True)
        row['gripper']=[(base.point('left_wrist')-wrist_offset('left','tool')).tolist(),[1,0,0,0]]
        row['parts']['block']=[[1,1,-.05],R.from_euler('z',.17).as_quat(scalar_first=True).tolist()]
        row['parts']['receiver']=[[1.26,1.03,-.05],R.from_euler('xyz',[.03,.07,-.1]).as_quat(scalar_first=True).tolist()]
        body=CarriedBody(spec,row,q);body.set(q)
        moving=body.m.geom('part_block').id;fixed=body.m.geom('part_receiver').id
        floor_pair=body.pair_index[tuple(sorted([0,moving]))]
        receiver_pair=body.pair_index[tuple(sorted([moving,fixed]))]
        residual,hits=body.collision_penalties()
        # Automatic collision filtering used to omit both mocap/static pairs,
        # even though direct geometric distance reported deep intersections.
        self.assertGreater(residual[floor_pair],.2)
        self.assertGreater(residual[receiver_pair],.04)
        self.assertTrue(any('floor' in a+b for a,b,_ in hits))
        def penalties(value):body.set(value);return body.collision_penalties()[0]
        body.set(q);analytic=Kinematics(body,q).collisions()
        numeric=approx_derivative(penalties,q,method='3-point',abs_step=1e-6)
        np.testing.assert_allclose(analytic[[floor_pair,receiver_pair]],numeric[[floor_pair,receiver_pair]],atol=2e-4,rtol=2e-3)

    def test_idle_driver_matches_recording_and_collides_with_carried_panel(self):
        import json
        from pathlib import Path
        from scipy.spatial.transform import Rotation as R
        from body_differentials import Kinematics
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_free_driver_contact.json').read_text())
        row=fixture['row'];q=np.array(row['body_q']);spec=fixture['spec']
        for coupled in [False,True]:
            body=CarriedBody(spec,row,q) if coupled else Body(spec)
            body.obstacles(row);body.set(q)
            handle,bit=body.free_tool_geoms;rotation=R.from_quat(row['tool'][1],scalar_first=True)
            np.testing.assert_allclose(body.d.geom_xpos[handle],row['tool'][0],atol=1e-10)
            np.testing.assert_allclose(body.d.geom_xpos[bit],np.array(row['tool'][0])+rotation.apply([0,-.08,0]),atol=1e-10)
            self.assertTrue(any('free_driver' in a+b and 'part_left' in (a,b) for a,b,_ in body.collision_penalties()[1]))
            def residual(value):body.set(value);return body.collision_penalties()[0]
            body.set(q);analytic=Kinematics(body,q).collisions()
            numeric=approx_derivative(residual,q,method='3-point',abs_step=1e-6)
            pairs=[i for i,pair in enumerate(body.pairs) if set(pair)&set(body.free_tool_geoms)]
            np.testing.assert_allclose(analytic[pairs],numeric[pairs],atol=1.5e-4,rtol=2e-3)
            for flags in [{'tool_parked':True},{'stage':'Position driver at screw'},{'two_hands':True,'second_grasp':{'part':'left','position':[0,0,0],'rotation':[1,0,0,0]}}]:
                body.obstacles({**row,**flags});body.set(q)
                self.assertFalse(any('free_driver' in a+b for a,b,_ in body.collision_penalties()[1]))

    def test_reaching_target_moves_with_carried_load(self):
        from scipy.spatial.transform import Rotation as R
        from body_differentials import Kinematics
        from task_hands import hand_constraints,attach_free_hands
        spec=copy.deepcopy(SPEC);spec['finish_second_grasp']={'part':'block','position':[.15,0,0],'rotation':[1,0,0,0]}
        row=copy.deepcopy(ROW);row.update(held='block',tool_parked=True)
        base=Body(spec);q=base.seed('stand',[0,-1],.2)
        hands,targets=hand_constraints(row,spec);start=attach_free_hands(base,q,hands,targets)['right']
        row['second_hand_blend']={'start':start,'reference':copy.deepcopy(row['gripper']),'wrist_space':True,'arc':[0,0,.12],'fraction':0.}
        # At the approach boundary the wrist stays exactly where it was.
        _,targets=hand_constraints(row,spec)
        np.testing.assert_allclose(targets['right'],base.point('right_wrist'),atol=1e-12)
        row['second_hand_blend']['fraction']=.47
        body=CarriedBody(spec,row,q,bimanual=True);body.obstacles(row)
        def target(value):body.set(value);return body.dynamic_targets()['right']
        body.set(q);actual=Kinematics(body,q).dynamic_targets()['right']
        numeric=approx_derivative(target,q,method='3-point',abs_step=1e-6)
        np.testing.assert_allclose(actual,numeric,atol=1e-7)
        # Closing the approach must meet the same grasp used by two-hand turn.
        row['second_hand_blend']['fraction']=1.;_,blended=hand_constraints(row,spec)
        row.pop('second_hand_blend');row['two_hands']=True;_,closed=hand_constraints(row,spec)
        np.testing.assert_allclose(blended['right'],closed['right'],atol=1e-12)

    def test_body_and_coupled_jacobians(self):
        for coupled,posture_weight in [(False,1.),(True,1.),(False,20.),(True,20.)]:
            with self.subTest(coupled=coupled,posture_weight=posture_weight):
                spec=copy.deepcopy(SPEC);spec['finish_second_grasp']={'part':'block','position':[.15,0,0],'rotation':[1,0,0,0]}
                row=copy.deepcopy(ROW);row['parts']['block'][0]=[0,-.86,1.]
                base=Body(spec);q=base.seed('stand',[0,-1],.2);q[3:]+=.012*np.random.default_rng(4).normal(size=len(q)-3);q=np.clip(q,base.bounds[0]+.01,base.bounds[1]-.01);q[2]-=.007
                if coupled:
                    row['held']='block';row['gripper']=[[-.15,-.86,1.],[1,0,0,0]];body=CarriedBody(spec,row,q,bimanual=True)
                else:body=base
                body.obstacles(row);body.set(q);anchors={s:body.point(s+'_ankle') for s in ['left','right']};targets={} if coupled else {'left':body.point('left_wrist')+[.02,0,.01]}
                body.fit(targets,row,initial=q,nominal=q,anchors=anchors,max_nfev=1,posture_weight=posture_weight)
                residual,jacobian=body.last_problem;actual=jacobian(q);numeric=approx_derivative(residual,q,method='3-point',abs_step=1e-6);offset=len(actual)-len(body.pairs)
                np.testing.assert_allclose(actual[:offset],numeric[:offset],atol=1e-4,rtol=1e-4)
                # Compare unscaled geometric derivatives; native convex-contact
                # queries have finite CCD accuracy regardless of solver weight.
                np.testing.assert_allclose(actual[offset:]/COLLISION_WEIGHT,numeric[offset:]/COLLISION_WEIGHT,atol=1.5e-4,rtol=2e-3)
    def test_center_line_inside_box_has_escape_gradient(self):
        xml='<mujoco><worldbody><geom type="box" size=".15 .15 .15"/><body pos=".14 0 0"><freejoint/><geom type="capsule" fromto="0 0 -.2 0 0 .2" size=".027" mass="1"/></body></worldbody></mujoco>'
        model=mujoco.MjModel.from_xml_string(xml);data=mujoco.MjData(model);mujoco.mj_forward(model,data)
        raw=float(data.contact[0].dist);before=geometry(model,data,data.contact[0]);self.assertAlmostEqual(raw,-.027,places=6)
        data.qpos[:3]+=before[-1]*.001;mujoco.mj_forward(model,data);after=geometry(model,data,data.contact[0])
        self.assertAlmostEqual(float(data.contact[0].dist),raw,places=6)
        self.assertAlmostEqual(after[0]-before[0],.001,places=6)

    def test_center_line_crossing_box_is_detected_without_native_contact(self):
        model=mujoco.MjModel.from_xml_string('<mujoco><worldbody><geom type="box" size=".15 .15 .15"/><body pos=".03 0 0"><freejoint/><geom type="capsule" fromto="0 0 -.2 0 0 .2" size=".027" mass="1"/></body></worldbody></mujoco>')
        data=mujoco.MjData(model);mujoco.mj_forward(model,data)
        contacts=list(crossing_contacts(model,data,[(1,0)]))
        self.assertEqual(len(contacts),1)
        self.assertLess(geometry(model,data,contacts[0])[0],-.1)
        data.qpos[0]=.4;mujoco.mj_forward(model,data)
        self.assertEqual(list(crossing_contacts(model,data,[(1,0)])),[])

if __name__=='__main__':unittest.main()
