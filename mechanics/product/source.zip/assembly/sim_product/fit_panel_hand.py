"""Fit a bounded anatomical edge pinch once; reuse on flat panels of 35 mm.
This is an atomic pose fit, not contact-dynamics simulation."""
import sys,json,numpy as np,mujoco
from pathlib import Path
from scipy.spatial.transform import Rotation as R
from scipy.optimize import least_squares
H=Path(__file__).resolve().parent;D=H.parent/'outputs/hand_v3';g=json.loads((D/'lift_geometry.json').read_text());frames=json.loads((D/'lift_frames.json').read_text())
m=mujoco.MjModel.from_xml_path(str(D/'contact_model.xml'));d=mujoco.MjData(m);d.qpos[:]=frames[100]['qpos'];mujoco.mj_forward(m,d)
center=d.xpos[m.body('tool').id].copy();basis=d.xmat[m.body('tool').id].reshape(3,3).copy();fixed=d.qpos.copy()
js=[i for i in range(m.njnt) if m.jnt_limited[i] and m.joint(i).name not in ['lift','base_x','base_y','pro_sup_r','flexion_r','deviation_r']]
ad=m.jnt_qposadr[js];bounds=m.jnt_range[js];x0=np.clip(fixed[ad],bounds[:,0]+1e-6,bounds[:,1]-1e-6)
coll=[i for i in range(m.ngeom) if 'coll' in m.geom(i).name and not m.geom(i).name.startswith('radius')]
tips=[m.body(n).id for n in ['distph2_r','distph3_r','distph4_r','distph5_r','distal_thumb_r']]
x0=np.r_[x0,0,0,0];bounds=np.r_[bounds,[[-.02,.02],[-.02,.05],[-.025,.025]]]
def objective(x):
 d.qpos[:]=fixed;d.qpos[ad]=x[:-3];mujoco.mj_forward(m,d)
 tp=(d.xpos[tips]-center)@basis+x[-3:]
 targetz=np.array([.025,.025,.025,.025,-.025]);targety=np.array([-.025,-.025,-.025,-.02,-.02])
 residual=[(tp[:,2]-targetz)*15,(tp[:,1]-targety)*10,(x-x0)*.025]
 points=[];radii=[]
 for i in coll:
  typ=m.geom_type[i];size=m.geom_size[i];pos=d.geom_xpos[i];axis=d.geom_xmat[i].reshape(3,3)[:,2]
  if typ==mujoco.mjtGeom.mjGEOM_CAPSULE:
   for u in [-1,0,1]:points.append(pos+axis*size[1]*u);radii.append(size[0])
  else:points.append(pos);radii.append(min(size[:3]))
 pts=(np.array(points)-center)@basis+x[-3:];qq=np.abs(pts-[0,-.15,0])-[.3,.15,.0175]
 sd=np.linalg.norm(np.maximum(qq,0),axis=1)+np.minimum(qq.max(axis=1),0)-radii
 residual.append(np.minimum(sd+.001,0)*120)
 return np.concatenate(residual)
sol=least_squares(objective,x0,bounds=(bounds[:,0],bounds[:,1]),max_nfev=300,ftol=1e-7)
objective(sol.x);P=(d.xpos-center)@basis+sol.x[-3:];RR=np.einsum('ij,njk->nik',basis.T,d.xmat.reshape(-1,3,3))
poses=[]
for u in np.linspace(0,1,21):
 d.qpos[:]=fixed;d.qpos[ad]=np.clip(np.array(frames[0]['qpos'])[ad],bounds[:-3,0],bounds[:-3,1])*(1-u)+sol.x[:-3]*u;mujoco.mj_forward(m,d)
 poses.append({'closure':float(u),'xpos':((d.xpos-center)@basis+sol.x[-3:]).tolist(),'xmat':np.einsum('ij,njk->nik',basis.T,d.xmat.reshape(-1,3,3)).tolist()})
p=H/'assets/hand_poses.json';lib=json.loads(p.read_text());lib['board_poses']=poses;ci=g['bodies'].index('capitate_r');lib['board_wrist']=(P[ci]+RR[ci]@np.array([0,.012,0])).tolist();lib['panel_fit']={'cost':sol.cost,'joint_limits_respected':True,'max_nfev':sol.nfev,'scope':'35 mm panel edge pinch; approximate contacts'};p.write_text(json.dumps(lib,separators=(',',':')))
print(lib['panel_fit'], 'tips',P[tips].round(3).tolist(),flush=True)
