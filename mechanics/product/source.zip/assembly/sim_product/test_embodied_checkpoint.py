"""An exact physics/controller checkpoint must reproduce continuation."""
import tempfile,unittest
from pathlib import Path
import mujoco
import numpy as np
from embodied_world import EmbodiedWorld

class CheckpointRegression(unittest.TestCase):
    def test_planning_row_uses_current_controller_state(self):
        world=EmbodiedWorld(Path(__file__).parent/'assets/table.json',1)
        world.rows[-1]['second_hand_blend']={'fraction':.5}
        world.second_hand_blend=None;world.stroke=.37;world.connector='mount_0';world.tool_engaged=True;world.tool_control=True
        row=world.current_row()
        self.assertNotIn('second_hand_blend',row)
        self.assertEqual(row['stroke'],.37)
        self.assertEqual(row['connector'],'mount_0')
        self.assertTrue(row['tool_engaged']);self.assertTrue(row['tool_control'])

    def test_tool_retry_restores_physics_and_recording(self):
        from scipy.spatial.transform import Rotation as R
        world=EmbodiedWorld(Path(__file__).parent/'assets/table.json',1)
        world.operator.seed('stand',[-2,-2],0);anchors={s:world.operator.point(s+'_ankle') for s in ['left','right']}
        for a in anchors.values():a[2]=.065
        world.install_station({'anchors':anchors,'yaw':0.});world.stage='Released';world.tool_parked=True;world.tool_control=True
        with tempfile.TemporaryDirectory() as folder:
            world.save(folder);reference=EmbodiedWorld.restore(folder)
            advance=world.advance;calls=[0]
            def reject_once(seconds):
                advance(seconds);calls[0]+=1
                if calls[0]==2:raise RuntimeError('Injected rejection after a real physics and recording step')
            world.advance=reject_once
            world.tool_move([.6,-.6,.4],R.identity(),.08)
            reference.tool_move([.6,-.6,.4],R.identity(),.16)
            np.testing.assert_allclose(world.d.qpos,reference.d.qpos,atol=1e-12)
            np.testing.assert_allclose(world.d.qvel,reference.d.qvel,atol=1e-12)
            np.testing.assert_allclose(world.operator_q,reference.operator_q,atol=1e-12)
            self.assertEqual(world.rows,reference.rows)
            self.assertEqual(len(world.rejected_rollouts),1)

    def test_restore_preserves_next_physics_and_body_step(self):
        world=EmbodiedWorld(Path(__file__).parent/'assets/table.json',1)
        q=world.operator.seed('stand',[-2,-2],0)
        anchors={s:world.operator.point(s+'_ankle') for s in ['left','right']}
        for a in anchors.values():a[2]=.065
        world.install_station({'anchors':anchors,'yaw':0.})
        from grasp_sites import paired_candidates
        grip=paired_candidates(world.parts['top'])[0]
        world.finish_grasp={**grip,'part':'top','candidate':0};world.second_grasp=grip['paired']
        with tempfile.TemporaryDirectory() as folder:
            world.save(folder);restored=EmbodiedWorld.restore(folder)
            self.assertEqual(world.spec,restored.spec)
            self.assertEqual(world.finish_grasp,restored.finish_grasp)
            self.assertEqual(world.second_grasp,restored.current_row()['second_grasp'])
            for a,b in zip(world.site('top'),restored.site('top')):
                if hasattr(a,'as_matrix'):a,b=a.as_matrix(),b.as_matrix()
                np.testing.assert_allclose(a,b,atol=1e-12)
            self.assertEqual(world.d.time,restored.d.time)
            np.testing.assert_allclose(world.d.qpos,restored.d.qpos,atol=1e-12)
            np.testing.assert_allclose(world.operator_q,restored.operator_q,atol=1e-12)
            world.advance(.04);restored.advance(.04)
            np.testing.assert_allclose(world.d.qpos,restored.d.qpos,atol=1e-10)
            np.testing.assert_allclose(world.d.qvel,restored.d.qvel,atol=1e-10)
            np.testing.assert_allclose(world.operator_q,restored.operator_q,atol=1e-10)

    def test_weight_transfer_finishes_on_a_recorded_supported_pose(self):
        from plan_body_motion import stance_seed
        from validate_body_motion import validate
        world=EmbodiedWorld(Path(__file__).parent/'assets/table.json',1)
        world.operator.seed('stand',[-2,-2],0);anchors={s:world.operator.point(s+'_ankle') for s in ['left','right']}
        for a in anchors.values():a[2]=.065
        world.install_station({'anchors':anchors,'yaw':0.});start=len(world.rows)-1
        q,report=world.operator.fit({},world.current_row(),initial=world.operator_q,nominal=world.operator_q,anchors=world.anchors,foot_yaws=world.foot_yaws,support_sides=['left'],max_nfev=150)
        self.assertTrue(report['accepted'],report)
        world.execute_pose(q,world.anchors,world.foot_yaws,duration=.2132,support_goal=['left'],defer_support=True)
        self.assertAlmostEqual(world.rows[-1]['t'],world.d.time,places=8)
        self.assertEqual(world.rows[-1]['body_support'],['left'])
        raised={s:a.copy() for s,a in world.anchors.items()};raised['right'][2]+=.1
        nominal=stance_seed(world.operator,1.,world.operator_yaw,raised)
        q,report=world.operator.fit({},world.current_row(),initial=world.operator_q,nominal=nominal,anchors=raised,foot_yaws=world.foot_yaws,support_sides=['left'],max_nfev=150)
        self.assertTrue(report['accepted'],report)
        world.execute_pose(q,raised,world.foot_yaws,duration=.2132,support_goal=['left'])
        rows=world.rows[start:];audit=validate(rows,[r['body_q'] for r in rows],world.spec,clothing=False)
        self.assertTrue(audit['passed'],audit['failures'][:3])

if __name__=='__main__':unittest.main()
