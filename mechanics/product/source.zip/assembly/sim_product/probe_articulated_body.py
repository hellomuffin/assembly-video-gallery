"""Static feasibility diagnostics; failed poses are never render-ready artifacts."""
import json,sys,numpy as np
from pathlib import Path
from articulated_body import Body,R
H=Path(__file__).resolve().parent
name=sys.argv[1] if len(sys.argv)>1 else 'table'
folder=H.parent/'outputs/product_v1'/f'{name}_1';rows=json.loads((folder/'trajectory.json').read_text());visuals=json.loads((folder/'visuals.json').read_text());spec=json.loads((folder/'asset.json').read_text());body=Body(spec)
out=H.parent/'outputs/body_rebuild'/name;out.mkdir(parents=True,exist_ok=True);results=[]
for frame in map(int,sys.argv[2:] or [200,650,1000,1500,3000,3500]):
 row=rows[frame];v=visuals[frame];targets={side:np.array(v['arms'][side][2]) for side in ['left','right']};focus=np.mean(list(targets.values()),axis=0)
 forward=np.r_[-focus[:2],0.];forward/=max(np.linalg.norm(forward),1e-6);base=np.arctan2(-forward[0],forward[1]);options=[]
 span=targets['right']-targets['left'];face=np.cross([0,0,1],span);span_yaw=np.arctan2(-face[0],face[1]);headings=[base,base-.5,base+.5,span_yaw,span_yaw+np.pi]
 for mode in ['stand','squat','kneel']:
  for yaw in headings:
   turn=yaw-base
   for distance in [.30,.45]:
    xy=focus[:2]-R.from_euler('z',yaw).apply([0,distance,0])[:2]
    q,report=body.fit(targets,row,mode,xy,yaw,max_nfev=100)
    options.append((q,report));print(name,frame,mode,round(turn,1),distance,report,flush=True)
 good=[x for x in options if x[1]['accepted']];best=min(good or options,key=lambda x:x[1]['cost']);q,report=best
 record=dict(frame=frame,stage=row['stage'],report=report,geometry=body.landmarks(q),targets={k:v.tolist() for k,v in targets.items()});results.append(record)
 (out/'static-probes.json').write_text(json.dumps(results,indent=2))
 print('BEST',frame,report,flush=True)
