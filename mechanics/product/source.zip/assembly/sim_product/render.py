"""Detailed room replay. Furniture poses are recorded dynamics; hands and tool
operations use explicitly simplified anatomical animation."""
import bpy,sys,os,json,math,numpy as np
from pathlib import Path
from mathutils import Vector,Quaternion,Matrix
H=Path(__file__).resolve().parent;A=H.parent;name=os.environ.get('PRODUCT','table');O=A/'outputs/product_v1'/f'{name}_1'
rows=json.loads((O/'trajectory.json').read_text());visual=json.loads((O/'visuals.json').read_text());spec=json.loads((O/'asset.json').read_text())
# Reuse our furnished apartment and procedural materials.
source=(A/'sim_v2/render_blender.py').read_text().split('parts=json.loads')[0]
exec(compile(source,'existing_room','exec'))
for ob in list(bpy.data.objects):
 if ob.name.startswith('Assembly mat'):bpy.data.objects.remove(ob,do_unlink=True)
# Wood floor top exactly coincides with the physics plane (z=0).
for ob in bpy.data.objects:
 if ob.name.startswith('Floor board'):ob.location.z=-.02
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.cycles.samples=12
scene.cycles.use_denoising=True;scene.cycles.denoising_use_gpu=True;scene.render.use_persistent_data=True
scene.view_settings.exposure=-1.1
for node in wood.node_tree.nodes:
 if node.type=='VALTORGB':
  node.color_ramp.elements[0].color=(.20,.09,.035,1);node.color_ramp.elements[1].color=(.52,.30,.12,1)
objects={}
for p in spec['parts']:
 ob=cube(p['id'],(0,0,0),p['size'],wood,.0015);ob.rotation_mode='QUATERNION';objects[p['id']]=ob
skin=material('Warm skin',(.48,.245,.145),.48);shirt=material('Cotton sleeves',(.035,.11,.12),.92);rubber=material('Driver grip',(.018,.065,.07),.72)
def ball(name,size,mat):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12);o=bpy.context.object;o.name=name;o.scale=size;o.data.materials.append(mat)
 for f in o.data.polygons:f.use_smooth=True
 return o
def segment(o,a,b,r1=.035):
 a,b=Vector(a),Vector(b);o.location=(a+b)/2;o.rotation_mode='QUATERNION';o.rotation_quaternion=(b-a).to_track_quat('Z','Y');o.scale=(r1,r1,(b-a).length/2+.009)
# Continuous skin inherited from the anatomical mesh; omit source forearm
# capsules because the forearm is now driven by finite-length arm IK.
lib=json.loads((H/'assets/hand_poses.json').read_text())
class Hand:
 def __init__(self,side):
  import bmesh
  geo=json.loads((A/'outputs/hand_v3/lift_geometry.json').read_text())
  geo['geoms']=[g for g in geo['geoms'] if 'coll' in g['name'] and not g['name'].startswith('radius_')]
  src=(A/'sim_v3/render_hand.py').read_text();src=src[src.index('def mat('):src.index('# Workbench with the same physical support geometry.')]
  ns=dict(bpy=bpy,np=np,Vector=Vector,Quaternion=Quaternion,Matrix=Matrix,geo=geo)
  exec(compile(src,'continuous_hand','exec'),ns);self.ns=ns;self.side=side
  if side=='left':
   mesh=bmesh.new();mesh.from_mesh(ns['hand'].data);bmesh.ops.reverse_faces(mesh,faces=list(mesh.faces));mesh.to_mesh(ns['hand'].data);mesh.free()
 def update(self,p,q,closure,profile):
  n=self.ns;pose=lib['board_poses' if profile=='board' else 'poses'][int(np.clip(round(closure*20),0,20))];P=np.array(pose['xpos']);RR=np.array(pose['xmat'])
  reflect=np.diag([-1,1,1]) if self.side=='left' else np.eye(3);rot=np.array(Quaternion(q).to_matrix())@reflect
  P=P@rot.T+np.array(p);RR=np.einsum('ij,njk->nik',rot,RR);vb=n['vbody']
  verts=(n['weights'][:,:,None]*(np.einsum('nkij,nkj->nki',RR[vb],n['local'])+P[vb])).sum(axis=1)
  n['hand'].data.vertices.foreach_set('co',verts.ravel());n['hand'].data.update()
  for ob,g in n['nails']:
   b=g['body'];T=np.eye(4);T[:3,:3]=RR[b]@np.array(Quaternion(g['local_quat']).to_matrix());T[:3,3]=P[b]+RR[b]@np.array(g['local_pos']);ob.matrix_world=Matrix(T)
hands={s:Hand(s) for s in ['left','right']}
arms={s:[ball(s+' sleeve',(1,1,1),shirt),ball(s+' forearm',(1,1,1),skin)] for s in hands}
pants=material('Canvas trousers',(.075,.085,.095),.9);hair=material('Short dark hair',(.025,.016,.011),.9)
shoulder_bridge=ball('Shoulder fabric',(1,1,1),shirt)
torso=ball('Cotton torso',(1,1,1),shirt);neck=ball('Neck',(1,1,1),skin);body_head=ball('Head',(.083,.09,.115),skin)
haircap=ball('Hair',(.085,.092,.060),hair)
eyes=[ball('Eye',(.006,.006,.006),hair) for _ in range(2)];nose=ball('Nose',(.012,.016,.019),skin)
legs={k:[ball('Trouser thigh',(1,1,1),pants),ball('Trouser calf',(1,1,1),pants),ball('Shoe',(.065,.13,.05),rubber)] for k in ['-1','1']}
# Ratchet T-handle, visible shaft, and angle marker.
bpy.ops.object.empty_add();tool=bpy.context.object;tool.rotation_mode='QUATERNION'
def cylinder(name,radius,depth,location,mat,parent=None,rotation=(0,0,0)):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=radius,depth=depth);o=bpy.context.object;o.name=name;o.data.materials.append(mat);o.parent=parent;o.location=location;o.rotation_euler=rotation
 for f in o.data.polygons:f.use_smooth=True
 return o
cylinder('Rubber T handle',.017,.14,(0,0,0),rubber,tool,(0,math.pi/2,0))
cylinder('Driver shaft',.003,.13,(0,-.075,0),steel,tool,(math.pi/2,0,0))
marker=cube('Visible grip rotation marker',(.045,0,.017),(.025,.006,.002),trim,.001);marker.parent=tool;marker.location=(.045,0,.017)
cube('Driver rack',(.65,-.7,.035),(.17,.06,.07),wood,.003)
# Brackets move with their furniture panel; screws follow the receiver and
# advance only during the recorded tightening action.
screws={};washers={}
parts={p['id']:p for p in spec['parts']}
for c in spec['connectors']:
 a=parts[c['a']];b=parts[c['b']];pos=np.array(c['tool_position']);axis=np.array(c['tool_axis']);worldpos=np.array(a['assembly_position'])+pos
 if c['bracket']:
  off=worldpos-np.array(b['assembly_position'])
  foot=cube(c['id']+' factory mounting bracket',(0,0,0),(.14,.045,.004),steel,.001);foot.parent=objects[c['b']];foot.location=off+[np.sign(b['assembly_position'][0])*.04,0,-.002]
  sign=np.sign(b['assembly_position'][0]);up=cube(c['id']+' bracket upright',(0,0,0),(.004,.045,.045),steel,.001);up.parent=objects[c['b']]
  up.location=off+[sign*.105,0,.020]
 head=cylinder(c['id']+' screw head',.006,.003,(0,0,0),steel);head.rotation_mode='QUATERNION'
 slot=cube(c['id']+' screw slot',(0,0,0),(.008,.0014,.0008),rubber,.0002);slot.parent=head;slot.location=(0,0,.0017)
 shaft=cylinder(c['id']+' screw shaft',.002,.020,(0,0,-.010),steel,head)
 screws[c['id']]=head
for loc,power,size in [((1,-1,3.3),700,3),((-1.5,1.5,2.5),220,2)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(Vector((0,0,.1))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.clip_start=.015;cam.data.clip_end=30
# Replace the drafting mannequin with the project's CC0 human surface.
sys.path.insert(0,str(A/'sim_v5'));os.environ['HUMAN_SURFACE_NECK']='1';os.environ['HUMAN_SURFACE_HEAD_GAZE']='1'
from human_surface import Surface
surface=Surface();surface_objects=[]
for category,matl in enumerate([skin,shirt,pants]):
 mesh=bpy.data.meshes.new('Operator surface '+str(category));faces=[f for f,m in zip(surface.faces,surface.materials) if m==category]
 mesh.from_pydata(surface.rest[surface.used].tolist(),[],faces);mesh.update()
 ob=bpy.data.objects.new('Operator surface '+str(category),mesh);bpy.context.collection.objects.link(ob);ob.data.materials.append(matl)
 for face in mesh.polygons:face.use_smooth=True
 surface_objects.append(ob)
retired=[torso,shoulder_bridge,neck,body_head,haircap]+[arms[s][0] for s in hands]+[legs[k][j] for k in legs for j in [0,1]]
indices=list(map(int,os.environ['INDICES'].split(','))) if os.environ.get('INDICES') else list(range(0,len(rows),4))
views=os.environ.get('VIEWS','overview,ego').split(',')
for index in indices:
 row=rows[index];v=visual[index]
 for n,(p,q) in row['parts'].items():objects[n].location=p;objects[n].rotation_quaternion=Quaternion(q)
 for side in hands:
  hands[side].update(*v[side]);s,e,w=v['arms'][side];segment(arms[side][0],s,e,.043);segment(arms[side][1],e,w,.027)
 shoulder=np.array(v['shoulder']);hip=np.array(v['hip']);back=np.array(v['back'])
 segment(torso,hip,shoulder,.155);segment(shoulder_bridge,v['arms']['left'][0],v['arms']['right'][0],.085);body_head.location=shoulder+[0,0,.205];haircap.location=np.array(body_head.location)+[0,0,.075];segment(neck,shoulder,shoulder+[0,0,.14],.045)
 for k,(h,knee,foot) in v['legs'].items():
  segment(legs[k][0],h,knee,.070);segment(legs[k][1],knee,foot,.050);legs[k][2].location=foot
  legs[k][2].rotation_euler.z=math.atan2(-back[0],back[1])
 p,q=row['tool'];tool.location=p;tool.rotation_quaternion=Quaternion(q)@Quaternion((0,1,0),-row['stroke'])
 for c in spec['connectors']:
  carrier=c['b'] if c['bracket'] else c['a']
  p,q=row['parts'][carrier];rot=Quaternion(q);axis=rot@Vector(c['tool_axis'])
  local=np.array(c['tool_position'])+np.array(parts[c['a']]['assembly_position'])-np.array(parts[carrier]['assembly_position'])
  entry=Vector(p)+rot@Vector(local)
  fraction=min(1,row['engagement'][c['id']]/c['required_turns']);head=screws[c['id']]
  # Captive screws start partially inserted in factory bracket/pilot holes.
  head.location=entry-axis*(.012*(1-fraction));head.rotation_quaternion=(-axis).to_track_quat('Z','Y')@Quaternion((0,0,1),-row['engagement'][c['id']]*2*math.pi)
 cq=(Vector(v['look'])-Vector(v['eye'])).to_track_quat('-Z','Y')
 hp=Vector(v['eye'])-cq@Vector((0,0,-.08))-cq@Vector((0,.03,0))
 operator={'shoulder_center':v['shoulder'],'hip':v['hip'],'forward':(-np.array(v['back'])).tolist(),'head':list(hp),'camera_quaternion':list(cq),'legs':v['legs'],'arms':{'hand_'+k:val for k,val in v['arms'].items()}}
 points=surface.deform({'operator':operator})
 forward=cq@Vector((0,0,-1));up=cq@Vector((0,1,0));right=cq@Vector((1,0,0))
 hr=Matrix((right,forward,up)).transposed().to_quaternion()
 body_head.location=hp;body_head.rotation_mode='QUATERNION';body_head.rotation_quaternion=hr
 haircap.location=hp+up*.075;haircap.rotation_mode='QUATERNION';haircap.rotation_quaternion=hr
 nose.location=hp+forward*.092;nose.rotation_mode='QUATERNION';nose.rotation_quaternion=hr
 for eye,sign in zip(eyes,[-1,1]):eye.location=hp+forward*.081+up*.025+right*(sign*.032)
 segment(neck,shoulder+[0,0,.06],hp,.045)
 for ob in surface_objects:ob.data.vertices.foreach_set('co',points.ravel());ob.data.update()
 for view in views:
  body_head.hide_render=view=='ego';haircap.hide_render=view=='ego';neck.hide_render=view=='ego';torso.hide_render=view=='ego';shoulder_bridge.hide_render=view=='ego'
  cam.data.lens=24 if view=='ego' else 36
  cam.location=v['eye'] if view=='ego' else (2.5,-3.8,2.65)
  target=Vector(v['look'] if view=='ego' else (0,-.45,.32))
  if view=='detail':
   cam.data.lens=52;cam.location=Vector(row['tool'][0])+Vector((.32,-.36,.28));target=Vector(row['tool'][0])+Vector((0,0,-.04))
  cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
  for ob in retired:ob.hide_render=True
  surface_objects[0].hide_render=True
  surface_objects[1].hide_render=view=='ego'
  for ob in [body_head,haircap,neck,nose,*eyes]:ob.hide_render=view=='ego'
  for side in arms:arms[side][0].hide_render=view!='ego'
  folder=O/view;folder.mkdir(exist_ok=True);scene.render.filepath=str(folder/f'{index:06d}.jpg');scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=90;bpy.ops.render.render(write_still=True)
 print('FRAME',index,flush=True)
