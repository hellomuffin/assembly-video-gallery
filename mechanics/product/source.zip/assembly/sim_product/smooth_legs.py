"""Project temporally smoothed hip/knee parameters onto the clearance constraints."""
import numpy as np
from scipy.ndimage import gaussian_filter1d
from plan_legs import solve
from leg_clearance import boxes


def smooth(rows,visuals,spec):
    obstacles=[boxes(r,spec) for r in rows]
    parameters=[]
    for v in visuals:
        if 'leg_parameters' in v:parameters.append(v['leg_parameters']);continue
        back=np.array(v['back']);x=-np.cross(back,[0,0,1]);diff=np.array(v['hip'])-v['shoulder'];params=[diff@back,diff@x]
        for k,sign in enumerate([-1,1]):
            h,knee,foot=np.array(v['legs'][str(sign)]);u=(foot-h)/np.linalg.norm(foot-h);bend=knee-(h+foot)/2
            # Recover the pre-projection horizontal knee direction.
            b=bend-u*(bend[2]/u[2]) if abs(u[2])>1e-6 else bend
            params.append(np.arctan2(b@x*sign,-b@back))
        parameters.append(params)
    p=np.array(parameters);result=list(visuals)
    for iteration in range(4):
        targets=gaussian_filter1d(p,12,axis=0,mode='nearest')
        failures=0
        order=range(len(visuals)-1,-1,-1) if iteration%2==0 else range(len(visuals))
        neighbor=None
        for i in order:
            v=visuals[i]
            feet={int(s):np.array(leg[2]) for s,leg in v['legs'].items()}
            target=targets[i] if neighbor is None else .8*neighbor+.2*targets[i]
            q,lower,ok=solve(v,feet,obstacles[i],target,p[i])
            if neighbor is not None and np.linalg.norm(q-neighbor)>.12:
                alt,pose,valid=solve(v,feet,obstacles[i],target,neighbor)
                weights=np.array([6,9,.06,.06])
                if valid and (not ok or np.sum((alt-target)**2*weights)<np.sum((q-target)**2*weights)):
                    q,lower,ok=alt,pose,valid
            if ok:p[i]=q;result[i]={**v,**lower};neighbor=q
            else:failures+=1
        print('smooth',iteration,'projection failures',failures,flush=True)
    return result

if __name__=='__main__':
    import json,sys
    from pathlib import Path
    d=Path(__file__).resolve().parent.parent/'outputs/product_v1'/f'{sys.argv[1]}_1'
    rows=json.loads((d/'trajectory.json').read_text());v=json.loads((d/'visuals-candidate.json').read_text());spec=json.loads((d/'asset.json').read_text());result=smooth(rows,v,spec)
    (d/'visuals-smooth.json').write_text(json.dumps(result,separators=(',',':')))
    for key in ['hip','knee','foot']:
        a=np.array([z['hip'] if key=='hip' else z['legs']['-1'][1 if key=='knee' else 2] for z in result]);speed=np.linalg.norm(np.diff(a,axis=0),axis=1)/.04;i=int(speed.argmax());print(key,float(speed.max()),i,rows[i]['stage'])
