"""Independent triangle/OBB audit of the same trouser skin used by Blender."""
import json,sys,os
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parent/'sim_v5'))
from human_surface import Surface
from leg_clearance import boxes


def triangle_box_intersections(triangles, half):
    """Triangle/AABB SAT (including containment, face and edge crossings)."""
    if not len(triangles):return np.zeros(0,dtype=bool)
    keep=np.all(triangles.min(axis=1)<=half,axis=1)&np.all(triangles.max(axis=1)>=-half,axis=1)
    indices=np.flatnonzero(keep);tri=triangles[indices]
    if not len(tri):return keep
    edges=np.roll(tri,-1,axis=1)-tri
    normal=np.cross(edges[:,0],edges[:,1])
    axes=np.concatenate([normal[:,None],np.cross(edges[:,:,None,:],np.eye(3)[None,None]).reshape(-1,9,3)],axis=1)
    projections=np.einsum('tvi,tai->tav',tri,axes);radius=np.abs(axes)@half
    separated=np.any((projections.min(axis=-1)>radius+1e-10)|(projections.max(axis=-1)<-radius-1e-10),axis=-1)
    keep[indices[separated]]=False
    return keep


class LegSurface:
    def __init__(self):
        self.surface=Surface()
        faces=[f for f,m in zip(self.surface.faces,self.surface.materials) if m==2]
        self.triangles=np.array([[f[0],f[j],f[j+1]] for f in faces for j in range(1,len(f)-1)])
        # Deform exactly the rendered trouser vertices; upper-body vertices have
        # no influence on their linear skinning and need not be recomputed.
        selected=np.unique(self.triangles)
        mapping=np.full(len(self.surface.used),-1,dtype=int);mapping[selected]=np.arange(len(selected))
        source=self.surface.used[selected]
        self.surface.rest=self.surface.rest[source].copy()
        self.surface.weights=self.surface.weights[source].copy()
        self.surface.used=np.arange(len(source))
        self.triangles=mapping[self.triangles]

    def points(self,v):
        operator=dict(shoulder_center=v['shoulder'],hip=v['hip'],forward=(-np.array(v['back'])).tolist(),head=np.array(v['shoulder'])+[0,0,.24],legs=v['legs'],arms={'hand_'+k:val for k,val in v['arms'].items()})
        if 'segment_frames' in v:operator['segment_frames']=v['segment_frames']
        if 'clavicles' in v:operator['clavicles']=v['clavicles']
        return self.surface.deform(dict(operator=operator))
    def collisions(self,v,obstacles,points=None):
        if points is None: points=self.points(v)
        names,centers,rotations,half=obstacles;hits={}
        for name,center,rot,h in zip(names,centers,rotations,half):
            local=(points-center)@rot
            mask=triangle_box_intersections(local[self.triangles],h)
            if mask.any():hits[name]=int(mask.sum())
        return hits


def audit(rows,visuals,spec,stride=1):
    surface=LegSurface();failures=[]
    for i in range(0,len(rows),stride):
        hits=surface.collisions(visuals[i],boxes(rows[i],spec))
        if hits:failures.append(dict(frame=i,time_s=rows[i]['t'],stage=rows[i]['stage'],triangles_by_part=hits))
    return dict(passed=not failures,checked_frames=len(range(0,len(rows),stride)),colliding_frames=len(failures),failures=failures,scope='Rendered trouser triangles against all recorded furniture OBBs, at sampled poses. Includes pelvis skin; excludes other body surfaces, dynamics and unrecorded times.')

if __name__=='__main__':
    folder=H.parent/'outputs/product_v1'/sys.argv[1]
    visuals=Path(sys.argv[3]) if len(sys.argv)>3 else folder/'visuals.json'
    report=audit(json.loads((folder/'trajectory.json').read_text()),json.loads(visuals.read_text()),json.loads((folder/'asset.json').read_text()),int(os.environ.get('AUDIT_STRIDE','1')))
    target=folder/(sys.argv[2] if len(sys.argv)>2 else 'leg-surface.json');target.write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='failures'}));print(report['failures'][:10])
