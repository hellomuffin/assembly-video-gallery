"""Publish only the reviewed product page, media and discoverability links."""
from pathlib import Path
import subprocess,os,shutil,json
A=Path(__file__).resolve().parent.parent;O=A/'outputs/product_v1';repo=A/'outputs/gallery-publish-filtered'
from body_proof import require_body_validation
for name in ['table','shelf']:require_body_validation(O/f'{name}_1')
assert (O/'page-local.json').exists()
env={**os.environ,'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ASKPASS':str(A/'outputs/publish-tools/askpass.sh')}
def git(*args):
 r=subprocess.run(['git','-C',str(repo),*args],env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError('Git operation failed: '+args[0])
 return r.stdout.strip()
assert not git('status','--porcelain')
shutil.copytree(A/'showcase/mechanics/product',repo/'mechanics/product',dirs_exist_ok=True)
# Remove superseded transport files after copying the verified split archive.
parts=json.loads((repo/'mechanics/product/recordings-manifest.json').read_text())['parts']
expected={p['file'] for p in parts if not p.get('url')}
(repo/'mechanics/product/recordings.zip').unlink(missing_ok=True)
for old in (repo/'mechanics/product').glob('recordings.zip.[0-9][0-9][0-9]'):
 if old.name not in expected:old.unlink()
git('add','mechanics/product');print(git('diff','--cached','--stat'),flush=True)
git('-c','user.name=hellomuffin','-c','user.email=hellomuffin@users.noreply.github.com','commit','-m','Rebuild assembly motion with fixed anatomy and whole-body collision checks')
sha=git('rev-parse','HEAD');git('push','origin','HEAD:main');(O/'deployment.json').write_text(json.dumps({'commit':sha,'pushed':True},indent=2));print('Published',sha,flush=True)
