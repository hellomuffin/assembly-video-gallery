"""Publish only the reviewed product page, media and discoverability links."""
from pathlib import Path
import subprocess,os,shutil,json
A=Path(__file__).resolve().parent.parent;O=A/'outputs/product_v1';repo=A/'outputs/gallery-publish-filtered'
assert (O/'page-local.json').exists()
env={**os.environ,'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ASKPASS':str(A/'outputs/publish-tools/askpass.sh')}
def git(*args):
 r=subprocess.run(['git','-C',str(repo),*args],env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError('Git operation failed: '+args[0])
 return r.stdout.strip()
assert not git('status','--porcelain')
for n in ['index.html','mechanics/assembly-design.html']:shutil.copy2(A/'showcase'/n,repo/n)
shutil.copytree(A/'showcase/mechanics/product',repo/'mechanics/product',dirs_exist_ok=True)
git('add','index.html','mechanics/assembly-design.html','mechanics/product');print(git('diff','--cached','--stat'),flush=True)
git('-c','user.name=hellomuffin','-c','user.email=hellomuffin@users.noreply.github.com','commit','-m','Publish complete table and shelf assembly with egocentric views')
sha=git('rev-parse','HEAD');git('push','origin','HEAD:main');(O/'deployment.json').write_text(json.dumps({'commit':sha,'pushed':True},indent=2));print('Published',sha,flush=True)
