"""Choose a work stance against the task's final grasp and screw targets."""
import copy
import numpy as np
from scipy.spatial.transform import Rotation as R
from task_hands import hand_constraints
from foot_contacts import boxes,choose_landing


def fit_work_contact(body,targets,row,**options):
    """Refine contact precision without pulling back toward a distant seed.

    A comfortable seed is useful for choosing the IK branch. Once that branch
    is feasible, project its contacts again with the found pose as the soft
    preference. Keep every foot, support, surface and joint constraint, and
    score the result against the original objective for stance comparison.
    """
    q,report=body.fit(targets,row,**options)
    error=max(report['wrist_error_m'].values(),default=0.)
    if error>.003:
        residual=body.last_problem[0]
        refined,check=body.fit(targets,row,**{**options,'initial':q,'nominal':q,'max_nfev':200})
        if check['accepted'] and max(check['wrist_error_m'].values(),default=0.)<error:
            check['cost']=float(np.sum(residual(refined)**2)/2)
            return refined,check
    return q,report


def work_target(rows,index,spec):
    row=rows[index];stage=row['stage'];part=row.get('held')
    if stage.startswith(('Approach ','Reach for ','Grasp ')):
        label=stage.removeprefix('Approach ').removeprefix('Reach for ').removeprefix('Grasp ')
        for j in range(index,len(rows)):
            if rows[j]['stage']=='Grasp '+label:
                return 'pickup:'+label,j
    if stage.startswith('Raise '):
        label=stage.removeprefix('Raise ')
        for j in range(index,-1,-1):
            if rows[j]['stage']=='Grasp '+label:return 'pickup:'+label,j
    if part and part!=spec.get('finish_grasp_part',spec['base']):
        for j in range(index,len(rows)):
            if rows[j].get('held')!=part:break
            if rows[j]['stage'].startswith('Tighten '):return 'fasten:'+str(rows[j].get('connector')),j
    return None,None


def plan_stance(body,row,spec,yaw_hint=None,center_hint=None,candidate_check=None,distances=None):
    _,targets=hand_constraints(row,spec);focus=np.mean(list(targets.values()),axis=0)
    radial=-focus[:2];base=np.arctan2(-radial[0],radial[1]) if yaw_hint is None else yaw_hint
    options=[]
    for mode in (['stand','squat'] if focus[2]>.55 else ['squat']):
        for yaw in [base,base-.3,base+.3,base-.6,base+.6,base-.9,base+.9,base-1.2,base+1.2]:
            for distance in (distances if distances is not None else [.25,.30,.35,.40,.45,.50,.55,.60]):
                center=focus.copy()
                if len(targets)==1:
                    sign=-1 if 'left' in targets else 1
                    center-=R.from_euler('z',yaw).apply([sign*.168,0,0])
                if center_hint is not None:center[:2]=center_hint
                xy=center[:2]-R.from_euler('z',yaw).apply([0,distance,0])[:2]
                nominal=body.seed(mode,xy,yaw);anchors={side:body.point(side+'_ankle') for side in ['left','right']}
                try:
                    for side in anchors:anchors[side][2]=.065
                    anchors['left']=choose_landing(anchors['left'],yaw,boxes(row,spec),'left',anchors['right'],max_shift=.16)
                    anchors['right']=choose_landing(anchors['right'],yaw,boxes(row,spec),'right',anchors['left'],max_shift=.16)
                except RuntimeError:continue
                q,report=fit_work_contact(body,targets,row,mode=mode,nominal=nominal,anchors=anchors,max_nfev=100)
                if report['accepted'] and row.get('connector') and row.get('stage','').startswith(('Tighten ','Loosen ')):
                    # The work stance must reach the complete ratchet arc,
                    # including the heavier connected load after fastening.
                    previous=q.copy();variant_costs=[]
                    for stroke in np.linspace(-np.pi/4,np.pi/4,9):
                        variant=copy.deepcopy(row);variant['stroke']=float(stroke);variant['fastened']=sorted(set(variant.get('fastened',[]))|{row['connector']})
                        _,variant_targets=hand_constraints(variant,spec)
                        alternate,check=fit_work_contact(body,variant_targets,variant,mode=mode,nominal=nominal,initial=previous,anchors=anchors,foot_yaws={s:yaw for s in anchors},continuity=previous,max_nfev=120)
                        if not check['accepted'] or max(check['wrist_error_m'].values(),default=0.)>.004:
                            report={**report,'accepted':False,'ratchet_arc_rejected':check};break
                        variant_costs.append(check['cost']);previous=alternate
                    if report['accepted']:report={**report,'cost':report['cost']+max(variant_costs),'ratchet_arc_samples':9}
                    if report['accepted']:
                        # A stance must reach the approach as well as the
                        # seated tool. The old final-pose-only check admitted
                        # a workspace gap halfway down the driver path.
                        handle=np.array(row['tool'][0]);rotation=R.from_quat(row['tool'][1],scalar_first=True)
                        standoff=handle+rotation.apply([0,.15,0]);high=standoff+[0,0,.10]
                        previous=q.copy();approach_costs=[]
                        path=[handle+(standoff-handle)*u for u in np.linspace(0,1,9)[1:]]+[standoff+(high-standoff)*u for u in np.linspace(0,1,13)[1:]]
                        for position in path:
                            variant=copy.deepcopy(row);variant['stroke']=0.;variant['tool']=[position.tolist(),row['tool'][1]]
                            _,approach_targets=hand_constraints(variant,spec)
                            alternate,check=fit_work_contact(body,approach_targets,variant,mode=mode,nominal=nominal,initial=previous,anchors=anchors,foot_yaws={s:yaw for s in anchors},continuity=previous,max_nfev=150)
                            if not check['accepted'] or max(check['wrist_error_m'].values(),default=0.)>.004:
                                report={**report,'accepted':False,'tool_approach_rejected':check};break
                            approach_costs.append(check['cost']);previous=alternate
                        if report['accepted']:report={**report,'cost':report['cost']+max(approach_costs),'tool_approach_samples':len(path)}
                if report['accepted'] and candidate_check is not None:
                    check=candidate_check(q,anchors,yaw)
                    if not check['accepted']:report={**report,'accepted':False,'exit_rejected':check}
                options.append((q,report,anchors))
            good=[o for o in options if o[1]['accepted']]
            if good:
                q,report,anchors=min(good,key=lambda o:o[1]['cost'])
                return dict(q=q,report=report,anchors=anchors,yaw=yaw)
    raise RuntimeError('Task has no feasible work stance: '+str(min([o[1] for o in options],key=lambda r:r['cost']) if options else 'no clear foot landings'))
