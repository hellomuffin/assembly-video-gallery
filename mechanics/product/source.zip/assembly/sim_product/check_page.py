"""Desktop/mobile and all six media selections, seek and playback."""
import json,threading,functools,http.server,io,sys,os
from pathlib import Path
from playwright.sync_api import sync_playwright
A=Path(__file__).resolve().parent.parent;O=A/'outputs/product_v1';root=A/'showcase'
class RangeHandler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
 def send_head(self):
  p=Path(self.translate_path(self.path))
  if p.is_file() and self.headers.get('Range'):
   data=p.read_bytes();r=self.headers['Range'].removeprefix('bytes=').split('-');start=int(r[0]);end=min(int(r[1]) if r[1] else len(data)-1,len(data)-1)
   self.send_response(206);self.send_header('Content-Type',self.guess_type(str(p)));self.send_header('Accept-Ranges','bytes');self.send_header('Content-Range',f'bytes {start}-{end}/{len(data)}');self.send_header('Content-Length',str(end-start+1));self.end_headers();return io.BytesIO(data[start:end+1])
  return super().send_head()
live='--live' in sys.argv
if not live:
 server=http.server.ThreadingHTTPServer(('127.0.0.1',8782),functools.partial(RangeHandler,directory=str(root)));threading.Thread(target=server.serve_forever,daemon=True).start()
base='https://hellomuffin.github.io/assembly-video-gallery/' if live else 'http://127.0.0.1:8782/'
manifest=json.loads((root/'mechanics/product/manifest.json').read_text());durations={v['file']:v['duration_seconds'] for v in manifest['videos']}
with sync_playwright() as p:
 runtime=Path(os.environ.get('PRODUCT_BROWSER_LIBS',A/'outputs/browser-runtime/lib'))
 browser_env=dict(os.environ)
 if runtime.is_dir():browser_env['LD_LIBRARY_PATH']=str(runtime)+(':'+browser_env['LD_LIBRARY_PATH'] if browser_env.get('LD_LIBRARY_PATH') else '')
 b=p.chromium.launch(headless=True,args=['--no-sandbox','--disable-gpu'],env=browser_env);page=b.new_page(viewport={'width':1365,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(base+'mechanics/product/');report={'media':[]}
 for furniture in ['shelf','table']:
  page.locator('[data-furniture="'+furniture+'"]').click()
  for view in ['overview','ego','detail']:
   page.locator('[data-view="'+view+'"]').click();filename=f'{furniture}-{view}.mp4'
   page.wait_for_function('document.querySelector("video").readyState>=1')
   duration=page.locator('video').evaluate('(v)=>v.duration');assert abs(duration-durations[filename])<.1
   page.locator('video').evaluate('(v)=>{v.muted=true;v.currentTime=v.duration*.65;return v.play()}')
   page.wait_for_function('document.querySelector("video").currentTime>document.querySelector("video").duration*.65&&!document.querySelector("video").seeking')
   assert page.locator('video').evaluate('(v)=>!v.error');page.locator('video').evaluate('(v)=>v.pause()')
   assert page.locator('#direct').get_attribute('href').split('?')[0]==filename
   report['media'].append({'file':filename,'duration':duration,'seek_and_play':True})
 reviews=page.request.get(base+'mechanics/product/body-reviews.json').json()['videos']
 report['body_reviews']=[];review_page=b.new_page()
 for review in reviews:
  filename=review['file'];assert page.locator('a[href="'+filename+'"]').count()==1
  review_page.set_content('<video controls muted src="'+base+'mechanics/product/'+filename+'"></video>')
  review_page.wait_for_function('document.querySelector("video").readyState>=1')
  duration=review_page.locator('video').evaluate('(v)=>v.duration');assert abs(duration-review['duration_seconds'])<.1
  review_page.locator('video').evaluate('(v)=>{v.currentTime=v.duration*.65;return v.play()}')
  review_page.wait_for_function('document.querySelector("video").currentTime>document.querySelector("video").duration*.65&&!document.querySelector("video").seeking')
  assert review_page.locator('video').evaluate('(v)=>!v.error');review_page.locator('video').evaluate('(v)=>v.pause()')
  report['body_reviews'].append({'file':filename,'duration':duration,'seek_and_play':True})
 review_page.close()
 for width in [1365,390,320]:
  page.set_viewport_size({'width':width,'height':900});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  page.screenshot(path=str(O/f'page-{"live" if live else "local"}-{width}.png'))
 for name in ['validation.json','manifest.json','source.zip','recordings.html','recordings-manifest.json','reassemble_recordings.py']:
  response=page.request.get(base+'mechanics/product/'+name);assert response.status==200
 download_manifest=page.request.get(base+'mechanics/product/recordings-manifest.json').json()
 for part in download_manifest['parts']:
  response=page.request.head(part.get('url',base+'mechanics/product/'+part['file']))
  assert response.status==200,part['file']
  assert int(response.headers['content-length'])==part['bytes'],part['file']
 page.goto(base);assert page.locator('a[href="mechanics/product/"]').count()
 assert not errors,errors
 report.update({'responsive_widths':[1365,390,320],'javascript_errors':errors,'homepage_link':True,'live':live})
 (O/f'page-{"live" if live else "local"}.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));b.close()
if not live:server.shutdown()
