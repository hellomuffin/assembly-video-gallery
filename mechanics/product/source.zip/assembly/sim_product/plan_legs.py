"""Collision-aware kinematic leg placement for immutable furniture replays.

Both feet stay planted except during explicit alternating swing intervals.
The torso and knee swivel adapt to those contacts; no furniture pose is edited.
"""
import numpy as np
from scipy.optimize import minimize
from leg_clearance import boxes, gaps, segment_box_distances, CLEARANCE, SHOE_RADIUS


def unit(v):
    return v/max(np.linalg.norm(v),1e-12)


def posture(v, p, feet):
    back=np.array(v['back']);x=-np.cross(back,[0,0,1]);shoulder=np.array(v['shoulder'])
    hip=shoulder+back*p[0]+x*p[1]
    hip[2]-=np.sqrt(max(.005,.56**2-p[0]**2-p[1]**2))
    legs={}
    for k,sign in enumerate([-1,1]):
        h=hip+x*sign*.085;foot=feet[sign];delta=foot-h;dist=np.linalg.norm(delta);u=unit(delta)
        bend=-back*np.cos(p[2+k])+x*sign*np.sin(p[2+k]);bend=unit(bend-u*np.dot(bend,u))
        knee=(h+foot)/2+bend*np.sqrt(max(0,.52**2-dist**2/4))
        legs[str(sign)]=[h.tolist(),knee.tolist(),foot.tolist()]
    return dict(hip=hip.tolist(),legs=legs,back=back.tolist(),leg_parameters=np.asarray(p).tolist())


def solve(v, feet, obs, prior, initial=None, edge=None):
    def constraints(p):
        z=posture(v,p,feet);d,_=gaps(z,obs)
        spans=[np.linalg.norm(np.array(k[2])-k[0]) for k in z['legs'].values()]
        # Pelvis surface has a wider envelope than each thigh.
        pelvis=segment_box_distances(z['legs']['-1'][0],z['legs']['1'][0],obs)[0]-.18
        swept=[]
        if edge is not None:
            other,between=edge
            for u,obstacle in zip([.25,.5,.75],between):
                iv=dict(legs={side:(np.array(z['legs'][side])*(1-u)+np.array(other['legs'][side])*u).tolist() for side in z['legs']},
                        back=(np.array(v['back'])*(1-u)+np.array(other['back'])*u).tolist())
                swept.extend((gaps(iv,obstacle)[0]-CLEARANCE/2).ravel())
        knees=np.array([leg[1][2] for leg in z['legs'].values()])
        return np.r_[d.ravel()-CLEARANCE,pelvis-CLEARANCE,.56**2-p[0]**2-p[1]**2-.008,np.array(z['hip'])[2]-.20,1.025-np.array(spans),knees-.105,swept]
    def objective(p):
        return np.sum((p-prior)**2*np.array([6,9,.06,.06]))+.08*(p[0]-.43)**2+.12*p[1]**2+.003*np.sum((p[2:]-1.15)**2)
    start=prior if initial is None else initial
    if constraints(prior).min()>=0:return prior,posture(v,prior,feet),True
    result=minimize(objective,start,method='SLSQP',bounds=[(.02,.55),(-.32,.32),(.25,2.25),(.25,2.25)],constraints=[dict(type='ineq',fun=constraints)],options=dict(maxiter=55,ftol=1e-8))
    return result.x,posture(v,result.x,feet),bool(constraints(result.x).min()>=-1e-6)


def shoe_gaps(foot,back,obs):
    return segment_box_distances(foot-back*.06,foot+back*.06,obs)[0]-SHOE_RADIUS


def safe_foot(goal, back, obs, other=None):
    x=-np.cross(back,[0,0,1]);offsets=sorted((back*d+x*l for d in [0,.12,-.12,.24,-.24,.36,.48,.6] for l in [0,.12,-.12,.24,-.24,.36,-.36,.48,-.48]),key=lambda a:np.dot(a,a))
    for offset in offsets:
        f=goal+offset;f[2]=.055
        if other is not None and np.linalg.norm(f[:2]-other[:2])<.19:continue
        if shoe_gaps(f,back,obs).min()>=.025:return f
    raise RuntimeError('No collision-free foot landing')


def plan(rows,visuals,spec):
    obstacles=[boxes(r,spec) for r in rows];feet={};p=np.array([.44,0.,1.15,1.15]);swing=None;next_side=-1;output=[];failures=[]
    for i,(row,v,obs) in enumerate(zip(rows,visuals,obstacles)):
        back=np.array(v['back']);x=-np.cross(back,[0,0,1]);future=min(len(rows)-1,i+12);fv=visuals[future];fb=np.array(fv['back']);fx=-np.cross(fb,[0,0,1])
        # Ahead-of-time targets let a foot move before the torso reaches it.
        shoulder=np.array(fv['shoulder']);lean=np.clip(.18+(1.5-shoulder[2])*.6,.08,.44);hip=shoulder+fb*lean-[0,0,np.sqrt(.56**2-lean**2)]
        targets={}
        for sign in [-1,1]:
            goal=hip+fb*(.10 if shoulder[2]>1.25 else .22)+fx*sign*.22;goal[2]=.055
            targets[sign]=safe_foot(goal,fb,obstacles[future],feet.get(-sign))
            if sign not in feet:feet[sign]=targets[sign].copy()
        if swing is None:
            eligible=[s for s in [-1,1] if np.linalg.norm((targets[s]-feet[s])[:2])>.13 or min(shoe_gaps(feet[s],fb,obstacles[future]))<.02]
            if eligible:
                side=next_side if next_side in eligible else eligible[0];next_side=-side
                start=feet[side].copy();end=targets[side];height=.12
                # Validate the swept shoe against the moving recorded objects.
                for h in [.12,.20,.30,.40]:
                    clear=True
                    for j in range(13):
                        u=j/12;f=start+(end-start)*(u*u*(3-2*u))+[0,0,h*np.sin(np.pi*u)]
                        at=min(i+j,len(rows)-1)
                        if shoe_gaps(f,np.array(visuals[at]['back']),obstacles[at]).min()<CLEARANCE:clear=False;break
                    if clear:height=h;break
                if clear:swing=(side,i,start,end,height)
        if swing is not None:
            side,t0,start,end,height=swing;u=min(1,(i-t0)/12);feet[side]=start+(end-start)*(u*u*(3-2*u))+[0,0,height*np.sin(np.pi*u)]
            if u>=1:swing=None
        new,lower,ok=solve(v,feet,obs,p)
        if not ok:
            for lean in [.32,.48,.53]:
                for side in [-.18,.18,0]:
                    new,lower,ok=solve(v,feet,obs,p,np.array([lean,side,1.5,1.5]))
                    if ok:break
                if ok:break
        if ok:p=new
        else:failures.append(dict(frame=i,stage=row['stage']))
        output.append({**v,**lower})
        if i%500==0:print('legs',i,'failures',len(failures),flush=True)
    return output,failures

if __name__=='__main__':
    import json,sys
    from pathlib import Path
    O=Path(__file__).resolve().parent.parent/'outputs/product_v1';name=sys.argv[1];folder=O/f'{name}_1'
    rows=json.loads((folder/'trajectory.json').read_text());visuals=json.loads((folder/'visuals.json').read_text());spec=json.loads((folder/'asset.json').read_text())
    output,failures=plan(rows,visuals,spec)
    (folder/'visuals-candidate.json').write_text(json.dumps(output,separators=(',',':')));(folder/'leg-plan-failures.json').write_text(json.dumps(failures,indent=2));print('DONE',name,len(failures))
