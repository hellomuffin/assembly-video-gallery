"""Declared edge-grasp alternatives, selected before moving the person.

A board lying flat cannot be grasped at an edge center with the wrist below the
floor. Top/bottom edge and palm-roll alternatives preserve the real surface
contact while allowing the task to choose a reachable grasp.
"""
import numpy as np
import copy
from scipy.spatial.transform import Rotation as R
from task_hands import wrist_offset


def completed_assembly_pairs(spec,carrier):
    """Real support surfaces for acquiring both hands before the final lift.

    Separate panels can share a long edge without sharing a local origin.
    Shift the declared contacts together along that edge, preserving their
    palm frames and checking both unchanged panel surfaces.
    """
    second=spec['finish_second_grasp']
    parts={p['id']:p for p in spec['parts']};first=parts[carrier]
    if second['part']==carrier:
        return paired_candidates(first,palm_pitch_degrees=(0,45,70))
    other=parts[second['part']]
    if any(p.get('grasp_profile')!='board' for p in [first,other]):return []
    sizes=[np.asarray(p['size'],float) for p in [first,other]]
    points=[np.asarray(first['grasp_position'],float),np.asarray(second['position'],float)]
    axis=int(np.argmax(np.minimum(*sizes)));result=[]
    for priority,offset in enumerate([0.,-.10,.10,-.15,.15,-.25,.25]):
        shifted=[p+np.eye(3)[axis]*offset for p in points]
        if any(np.any(abs(p)>size/2+1e-9) or not np.any(np.isclose(abs(p),size/2,atol=1e-9)) for p,size in zip(shifted,sizes)):continue
        normals=[(np.eye(3)[a]*np.sign(shifted[0][a])).tolist() for a in range(3) if np.isclose(abs(shifted[0][a]),sizes[0][a]/2,atol=1e-9)]
        paired=copy.deepcopy(second);paired['position']=shifted[1].tolist()
        result.append(dict(position=shifted[0].tolist(),rotation=list(first['grasp_rotation']),
            paired=paired,surface_normals=normals,purpose='two_hand_finish',priority=priority))
    return result


def paired_candidates(part,palm_pitch_degrees=(0,)):
    """Two hands on one panel edge, with a common outward palm direction."""
    if part.get('grasp_profile')!='board':return []
    size=np.array(part['size']);thin=int(np.argmin(size));result=[]
    for face_sign in [-1,1]:
        normal=np.eye(3)[thin]*face_sign
        for edge in [a for a in range(3) if a!=thin]:
            for edge_sign in [-1,1]:
                outward=np.eye(3)[edge]*edge_sign;tangent=np.cross(outward,normal)
                width=float(abs(tangent)@size);span=min(.42,width*.65)
                center=normal*size[thin]/2+outward*size[edge]/2
                frame=R.from_matrix(np.column_stack([tangent,outward,normal]))
                for pitch in palm_pitch_degrees:
                    rotation=(frame*R.from_euler('x',pitch,degrees=True)).as_quat(scalar_first=True).tolist()
                    left=dict(position=(center+tangent*span/2).tolist(),rotation=rotation,purpose='two_hand_finish',
                        surface_normal=normal.tolist(),palm_pitch_degrees=float(pitch))
                    left['paired']=dict(part=part['id'],position=(center-tangent*span/2).tolist(),rotation=rotation)
                    result.append(left)
    return result


def candidates(part):
    result=[dict(position=list(part['grasp_position']),rotation=list(part['grasp_rotation']))]
    if part.get('grasp_profile')!='board':return result
    axis=int(np.argmin(part['size']));rotation=R.from_quat(part['grasp_rotation'],scalar_first=True)
    for sign in [-1,1]:
        point=np.array(part['grasp_position'],float);point[axis]=sign*part['size'][axis]/2
        for roll in [0,np.pi]:
            result.append(dict(position=point.tolist(),rotation=(rotation*R.from_euler('y',roll)).as_quat(scalar_first=True).tolist()))
    # Captive hardware can prop a panel on a tilted face. Its originally
    # declared edge may then rest on the floor while another edge is reachable.
    # Search actual panel edges with outward palms, keeping all contacts on the
    # unchanged surface rather than forcing the body to reach through the floor.
    size=np.asarray(part['size'],float)
    for face_sign in [-1,1]:
        normal=np.eye(3)[axis]*face_sign
        for edge in [a for a in range(3) if a!=axis]:
            for edge_sign in [-1,1]:
                outward=np.eye(3)[edge]*edge_sign;tangent=np.cross(outward,normal)
                point=normal*size[axis]/2+outward*size[edge]/2
                frame=R.from_matrix(np.column_stack([tangent,outward,normal]))
                result.append(dict(position=point.tolist(),rotation=frame.as_quat(scalar_first=True).tolist()))
    return result


def select(part,position,rotation,minimum_wrist_z):
    options=part.get('grasp_candidates') or candidates(part);valid=[]
    for index,grasp in enumerate(options):
        if grasp.get('purpose')=='two_hand_finish':continue
        p=np.array(position)+rotation.apply(grasp['position']);r=rotation*R.from_quat(grasp['rotation'],scalar_first=True)
        wrist=p+r.apply(wrist_offset('left',part.get('grasp_profile','tool')))
        if wrist[2]>=minimum_wrist_z-1e-6:
            if index==0:return index
            valid.append((float(wrist[2]),index))
    if not valid:raise RuntimeError('No declared grasp keeps the wrist above the floor: '+part['id'])
    return max(valid)[1]


def choose_task_grasp(world,part,minimum_wrist_z):
    """Require one surface grasp to reach both pickup and fastening workspaces."""
    from task_stance import plan_stance
    key=next((k for k,c in world.connectors.items() if c['b']==part and k not in world.fastened),None)
    if key is None:return None
    c=world.connectors[key];item=world.parts[part];position,rotation=world.pose(part)
    receiver,orientation=world.pose(c['a'])
    goal=receiver+orientation.apply(np.asarray(item['assembly_position'])-world.parts[c['a']]['assembly_position'])
    tip,axis=world.tool_site(key);tool_rotation=world.tool_rotation(axis)
    options=item['grasp_candidates'];ranked=[];failures=[]
    for index,grasp in enumerate(options):
        hand_rotation=rotation*R.from_quat(grasp['rotation'],scalar_first=True)
        hand=position+rotation.apply(grasp['position'])
        future_rotation=orientation*R.from_quat(grasp['rotation'],scalar_first=True)
        future=goal+orientation.apply(grasp['position'])
        wrist=hand+hand_rotation.apply(wrist_offset('left',item.get('grasp_profile','tool')))
        future_wrist=future+future_rotation.apply(wrist_offset('left',item.get('grasp_profile','tool')))
        if min(wrist[2],future_wrist[2])<minimum_wrist_z-1e-6:continue
        ranked.append((0 if index==0 else 1,float(np.linalg.norm(future_wrist-tip)),index,hand,hand_rotation,future,future_rotation))
    for _,__,index,hand,hand_rotation,future,future_rotation in sorted(ranked,key=lambda x:x[:3]):
        pickup=world.current_row();pickup.update(stage='Grasp '+part,gripper=[hand.tolist(),hand_rotation.as_quat(scalar_first=True).tolist()],grasp_profile=item.get('grasp_profile','tool'))
        work=world.current_row();work['parts'][part]=[goal.tolist(),orientation.as_quat(scalar_first=True).tolist()]
        work.update(held=part,stage='Tighten clockwise',connector=key,stroke=0.,grasp_profile=item.get('grasp_profile','tool'),
            gripper=[future.tolist(),future_rotation.as_quat(scalar_first=True).tolist()],tool=[(tip-axis*.14).tolist(),tool_rotation.as_quat(scalar_first=True).tolist()])
        try:
            plan_stance(world.operator,work,world.spec)
            station=plan_stance(world.operator,pickup,world.spec)
        except RuntimeError as error:
            failures.append({'candidate':index,'reason':str(error)});continue
        print('TASK_GRASP',part,index,'pickup and fastening stances accepted',flush=True)
        return index,station
    raise RuntimeError('No surface grasp reaches pickup and fastening: '+str(failures))
