"""Encode source-indexed, labeled videos without interpolating furniture poses."""
import json,subprocess,hashlib,concurrent.futures
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
H=Path(__file__).resolve().parent;O=H.parent/'outputs/product_v1';dest=O/'media';dest.mkdir(exist_ok=True)

font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17)
def encode(item):
 name=item['furniture'];view=item['view'];folder=O/f'{name}_1';rows=json.loads((folder/'trajectory.json').read_text());indices=item['indices'];target=dest/f'{name}-{view}.mp4'
 assert hashlib.sha256((folder/'trajectory.json').read_bytes()).hexdigest()==item['trajectory_sha256']
 assert hashlib.sha256((folder/'visuals.json').read_bytes()).hexdigest()==item['visuals_sha256']
 encode=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','25','-i','-','-an','-c:v','libx264','-threads','2','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],stdin=subprocess.PIPE)
 for index in indices:
  row=rows[index];im=Image.open(folder/view/f'{index:06d}.jpg').convert('RGB');d=ImageDraw.Draw(im)
  d.rectangle((0,0,1280,43),fill='#101713');d.text((20,8),f'{name.upper()} / '+{'overview':'ROOM VIEW','ego':'MOVING FIRST-PERSON VIEW','detail':'ATOMIC FASTENING · CLOSE VIEW'}[view],font=font,fill='#ecf1e8');d.text((1100,10),f'{item["speed"]}× playback',font=small,fill='#c7e8a6')
  stage=row['stage']
  if stage.startswith('Reset ratchet'):stage='Ratchet return — screw holds its progress'
  d.rectangle((0,674,1280,720),fill='#101713');d.text((20,685),stage,font=font,fill='white');d.text((1000,686),f'{len(row["fastened"])} / {len(row["engagement"])} fastened',font=small,fill='#c7e8a6')
  encode.stdin.write(np.asarray(im).tobytes())
 encode.stdin.close();assert encode.wait()==0
 im.save(dest/f'{name}-{view}.jpg')
 subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','null','-'],check=True)
 record={**item,'file':target.name,'duration_seconds':len(indices)/25,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
 print('ENCODED',target.name,len(indices)/25,flush=True);return record
if __name__=='__main__':
 renders=json.loads((O/'render-manifest.json').read_text())
 old=json.loads((dest/'manifest.json').read_text())['videos'] if (dest/'manifest.json').exists() else []
 records={v['file']:v for v in old};pending=[]
 for item in renders['renders']:
  file=f'{item["furniture"]}-{item["view"]}.mp4';previous=records.get(file);target=dest/file
  if previous and all(previous.get(k)==v for k,v in item.items()) and target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==previous['sha256']:continue
  folder=O/f'{item["furniture"]}_1'/item['view']
  if all((folder/f'{i:06d}.jpg').exists() for i in item['indices']):pending.append(item)
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  for r in pool.map(encode,pending):records[r['file']]=r
 (dest/'manifest.json').write_text(json.dumps({'videos':list(records.values())},indent=2))
