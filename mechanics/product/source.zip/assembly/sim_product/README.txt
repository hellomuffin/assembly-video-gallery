Assembly product demonstration
=============================
This package contains a shared rigid-body executor, two original furniture
descriptions, an explicit assembly-order policy, and visual replay code.

Simulation:
  python assembly/sim_product/run.py table
  python assembly/sim_product/run.py shelf
  python assembly/sim_product/validate_completion.py table
  python assembly/sim_product/validate_completion.py shelf
  python assembly/sim_product/audit.py table
  python assembly/sim_product/audit.py shelf

Python requirements: numpy, scipy, mujoco, Pillow. Rendering uses Blender 4.5
and ffmpeg. Anatomical hand poses are supplied; re-fitting them is optional.

Replay:
  python assembly/sim_product/prepare_visuals.py table
  python assembly/sim_product/prepare_visuals.py shelf
  PRODUCT=table VIEWS=ego,overview blender -b -P assembly/sim_product/render.py
render_batch.py renders full clips and records their source-frame indices.
Set BLENDER_EXECUTABLE to your Blender installation when using the batch helper.
encode.py adds labels and writes MP4s from those exact frame indices.
The published normal-speed handling excerpts have separate body-reviews.json
provenance. Their captured render/encode scripts are included in the source
archive under assembly/review_scripts; adjust their data/output paths to the
extracted recordings when replaying locally.

Abstractions:
- Bounded virtual surface grasps approximate instinctive hand contact.
- The final two-hand lift uses an aggregate bounded wrench.
- Screws/ratchets are ideal atomic operations, with geometric and progress gates.
- Preinstalled brackets and captive screws are part of the design assumptions.
- Rendering replays recorded furniture poses; it does not invent their motion.
- The human is an articulated kinematic model with quasi-static foot support,
  not a dynamically balanced human simulation. Detailed finger contact and
  wrist orientation are not certified.
- The policy knows a correct order; this is not a learned planning result.
- Only the specified screw-group connector is implemented. Arbitrary furniture,
  detailed thread mechanics and overload fracture are not claimed.

The final completion checker measures tilt relative to gravity. A small yaw
difference is permitted; exact global heading is not an assembly requirement.

Included third-party assets:
MyoHub/myo_sim anatomical hand geometry: Apache-2.0.
MakeHuman base surface and rig weights: CC0.
See the included license files and provenance.

Articulated motion rebuild (2026-10-15)
-----------------------------------------------------------
The independent hip/knee-offset repair was rejected because its poses were
unnatural. Its leg-only validation cannot authorize rendering or publication.

run_embodied.py plans motion before advancing the actual furniture simulation.
The skeleton has fixed native bone lengths, hinge knees and bounded joints.
Whole-body and held-object contacts, active wrists, planted feet, support and
motion speed constrain each recorded pose. Floor routes avoid loose panels;
entire steps are planned before weight transfer or swing begins. Placement
planning tests full routes, including alternate board rotation directions and
separate lowering, instead of forcing a straight path through the person.
The skull collider is derived from the visible native head. Exact skin/panel
contacts also constrain joint-space refinement where blended waist or clothing
surfaces extend between rigid proxies. The skin vertices are never displaced
independently; wrist, foot, support, velocity and anatomical limits still apply.
Before lifting a completed assembly, the controller searches paired surface
grasps on one panel or on the supplied support panels. It selects a stance
that reaches both hands and permits final setdown and standing. Both grips
are acquired while the furniture still rests on the floor. On separate panels,
the search can move the declared contacts together along their real edges.
Selected grasps are recorded in controller state and frames; furniture geometry
and the original asset remain unchanged.
Final second-hand approaches can also reposition the load along with the arms.
The approach is planned completely before execution; its wrist path arcs around
the furniture and follows the actual held load during replay. A fixed-load
reach that is anatomically infeasible must not distort the body to close it.

Contact changes and final placement:
When a supporting grasp prevents a valid fastening posture, the executor may
release it only after testing actual resting support under gravity. The test
checks every connected part for drift and speed; a failed test restores the
prior integration state exactly. The operator can then step to a feasible
fastening stance without pulling the supporting arm or changing limb lengths.
Final lowering tracks the commanded carrying wrist during collision refinement.
Before release, the measured furniture pose must reach the floor endpoint and
pass the same resting-support test. If the assembly is still settling, the
controller retains its bounded grasp and allows up to five additional seconds
of real contact settling; every release probe keeps the original drift and
speed limits. Rejected probes restore both physics and finger closure. A missed
target cannot silently become a mid-air release. The person must then reach a
valid standing pose.

Fresh isolated full-task trial:
  EMBODIED_OUTPUT=assembly/outputs/body_rebuild/table_1 python assembly/sim_product/run_embodied.py table 4 assembly/sim_product/assets/table.json --finish
  EMBODIED_OUTPUT=assembly/outputs/body_rebuild/shelf_1 python assembly/sim_product/run_embodied.py shelf 8 assembly/sim_product/assets/shelf.json --finish

Do not treat a partial connector checkpoint or a successful pose fit as a
completed task. The finish operation must also succeed and pass independent
furniture completion checks. Set PRODUCT_DATA to a candidate directory when
running validate_completion.py or audit.py to keep review outputs isolated.

prepare_visuals.py requires a complete execution with captured source hashes,
then independently checks every recorded pose and three intermediate samples
per interval. It checks joint/bone constraints, body/self/part contacts, active
wrist reach, declared and actual foot support, and the exact visible native
surface against assembly parts, brackets, rack and floor. Rendered landmarks
are regenerated from the audited joints. The connected native head, neck and
clothing use the same bone frames and surface geometry as the audit.

Render and publication gates bind validation to the exact data and sources.
Changed-source diagnostic resumes cannot authorize publication. A verified
resume from a successful frozen connector checkpoint uses
EMBODIED_VERIFIED_RESUME=1 with EMBODIED_RESUME. It requires the same furniture
physics and asset, audits the entire prefix against current body constraints,
and archives every parent state/source plus the unchanged trajectory and event
prefix. Final validation still audits the complete combined execution.
Trials execute their source snapshot, so later workspace edits cannot alter a
module imported midway through a long run. The complete corrected table run
has passed 80,541 independent native-body poses, the furniture/tool audit, and
physical completion checks. The corrected shelf also passed 127,853 independent
native-body poses, the furniture/tool audit, and physical completion. Both
complete recordings retain their verified frozen continuation history.

Regression tests:
  python -m unittest discover -s assembly/sim_product -p 'test_*.py'

The sampled checks are not a continuous-time proof. Decorative room furniture
and detailed fingers are outside the collision audit; human dynamic balance
and real grasp forces are not certified.

Large complete recording archives may be hosted as release assets in the same
gallery repository to stay within the Pages site limit. The recording manifest
binds every download part and the reconstructed ZIP to their SHA-256 hashes.
