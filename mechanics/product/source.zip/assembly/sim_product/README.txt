Assembly product demonstration
=============================
This package contains a shared rigid-body executor, two original furniture
descriptions, a known-correct demonstration policy, and visual replay code.

Simulation:
  python assembly/sim_product/run.py table
  python assembly/sim_product/run.py shelf
  python assembly/sim_product/validate_completion.py table
  python assembly/sim_product/validate_completion.py shelf
  python assembly/sim_product/audit.py table
  python assembly/sim_product/audit.py shelf

Python requirements: numpy, scipy, mujoco, Pillow. Rendering uses Blender 4.5
and ffmpeg. Anatomical hand poses are supplied; re-fitting them is optional.

Replay:
  python assembly/sim_product/prepare_visuals.py table
  python assembly/sim_product/prepare_visuals.py shelf
  PRODUCT=table VIEWS=ego,overview blender -b -P assembly/sim_product/render.py
render_batch.py renders full clips and records their source-frame indices.
Set BLENDER_EXECUTABLE to your Blender installation when using the batch helper.
encode.py adds labels and writes MP4s from those exact frame indices.

Abstractions:
- Bounded virtual surface grasps approximate instinctive hand contact.
- The final two-hand lift uses an aggregate bounded wrench.
- Screws/ratchets are ideal atomic operations, with geometric and progress gates.
- Preinstalled brackets and captive screws are part of the design assumptions.
- Rendering replays recorded furniture poses; it does not invent their motion.
- Human hands, surface and gait are kinematic visual models, not balanced human
  dynamics or collision-certified skin.
- The policy knows a correct order; this is not a learned planning result.
- Only the specified screw-group connector is implemented. Arbitrary furniture,
  detailed thread mechanics and overload fracture are not claimed.

The final completion checker measures tilt relative to gravity. A small yaw
difference is permitted; exact global heading is not an assembly requirement.

Included third-party assets:
MyoHub/myo_sim anatomical hand geometry: Apache-2.0.
MakeHuman base surface and rig weights: CC0.
See the included license files and provenance.
