Assembly product demonstration
=============================
This package contains a shared rigid-body executor, two original furniture
descriptions, a known-correct demonstration policy, and visual replay code.

Simulation:
  python assembly/sim_product/run.py table
  python assembly/sim_product/run.py shelf
  python assembly/sim_product/validate_completion.py table
  python assembly/sim_product/validate_completion.py shelf
  python assembly/sim_product/audit.py table
  python assembly/sim_product/audit.py shelf

Python requirements: numpy, scipy, mujoco, Pillow. Rendering uses Blender 4.5
and ffmpeg. Anatomical hand poses are supplied; re-fitting them is optional.

Replay:
  python assembly/sim_product/prepare_visuals.py table
  python assembly/sim_product/prepare_visuals.py shelf
  PRODUCT=table VIEWS=ego,overview blender -b -P assembly/sim_product/render.py
render_batch.py renders full clips and records their source-frame indices.
Set BLENDER_EXECUTABLE to your Blender installation when using the batch helper.
encode.py adds labels and writes MP4s from those exact frame indices.

Abstractions:
- Bounded virtual surface grasps approximate instinctive hand contact.
- The final two-hand lift uses an aggregate bounded wrench.
- Screws/ratchets are ideal atomic operations, with geometric and progress gates.
- Preinstalled brackets and captive screws are part of the design assumptions.
- Rendering replays recorded furniture poses; it does not invent their motion.
- Human hands, surface and gait are kinematic visual models, not balanced human
  dynamics or collision-certified skin.
- The policy knows a correct order; this is not a learned planning result.
- Only the specified screw-group connector is implemented. Arbitrary furniture,
  detailed thread mechanics and overload fracture are not claimed.

The final completion checker measures tilt relative to gravity. A small yaw
difference is permitted; exact global heading is not an assembly requirement.

Included third-party assets:
MyoHub/myo_sim anatomical hand geometry: Apache-2.0.
MakeHuman base surface and rig weights: CC0.
See the included license files and provenance.

Leg/part clearance repair (2026-10-15)
------------------------------------
prepare_visuals.py now plans alternating foot swings, searches hip and knee
postures around recorded moving parts, and anticipates changes of knee
configuration. Both leg bones retain their 0.52 m lengths; at least one foot
remains stationary on the floor during every recorded transition.

A foot landing check alone is insufficient: a thigh can intersect a panel while
both feet are clear. validate_legs.py checks thigh/calf/shoe envelopes against
oriented panels, rendered mounting brackets and the driver rack. It also tests
three intermediate samples per 40 ms recorded interval, and independently tests
all rendered trouser triangles (including pelvis skin) at every recorded frame.
The source furniture trajectory and all hand/arm targets remain unchanged.

Preparation rejects failed clearance rather than writing accepted visuals.
render_batch.py and stage_site.py require successful validation matching the
exact trajectory, visuals, asset description and validation/planning source.
Validation: python assembly/sim_product/validate_legs.py table_1
Regression tests: python -m unittest discover -s assembly/sim_product -p test_leg_clearance.py

This certifies only the listed geometric checks at the listed sample times.
It does not certify continuous-time collision freedom, upper-body contact,
self-collision, room furniture contact, or dynamically balanced human gait.
