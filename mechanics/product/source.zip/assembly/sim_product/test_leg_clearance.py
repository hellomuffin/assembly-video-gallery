"""Regression cases for crossings missed by the former foot-only screen."""
import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from leg_clearance import boxes,segment_box_distances,gaps
from audit_leg_surface import triangle_box_intersections

class ClearanceTest(unittest.TestCase):
    def test_segment_crossing_with_clear_endpoints(self):
        obs=(['panel'],np.zeros((1,3)),np.eye(3)[None],np.array([[.5,.02,.5]]))
        self.assertAlmostEqual(float(segment_box_distances([0,-1,0],[0,1,0],obs)[0,0]),0)
        self.assertAlmostEqual(float(segment_box_distances([.7,-1,0],[.7,1,0],obs)[0,0]),.2)
    def test_rotated_thin_panel(self):
        rot=Rotation.from_euler('z',45,degrees=True).as_matrix()
        obs=(['panel'],np.zeros((1,3)),rot[None],np.array([[1,.01,.2]]))
        a=rot@np.array([-.5,.2,0]);b=rot@np.array([.5,.2,0])
        self.assertAlmostEqual(float(segment_box_distances(a,b,obs)[0,0]),.19)
    def test_stationary_point(self):
        obs=(['box'],np.zeros((1,3)),np.eye(3)[None],np.ones((1,3)))
        np.testing.assert_allclose(segment_box_distances([[2,2,2],[0,0,0]],[[2,2,2],[0,0,0]],obs)[:,0],[np.sqrt(3),0])
    def test_triangle_crosses_box_without_vertex_inside(self):
        tri=np.array([[[-2,-2,0],[2,-2,0],[0,2,0]]])
        self.assertTrue(triangle_box_intersections(tri,np.ones(3)*.1)[0])
        self.assertFalse(triangle_box_intersections(tri+[0,0,.2],np.ones(3)*.1)[0])
    def test_triangle_aabb_overlap_without_triangle_contact(self):
        tri=np.array([[[.05,2,0],[2,.05,0],[2,2,0]]])
        self.assertFalse(triangle_box_intersections(tri,np.ones(3)*.1)[0])
    def test_stale_visuals_cannot_render(self):
        import tempfile,json
        from pathlib import Path
        from validate_legs import stamp,require_leg_validation
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary)
            for name in ['trajectory.json','visuals.json','asset.json']:
                (folder/name).write_text('[]')
            stamp({'passed':True},folder,folder/'visuals.json')
            require_leg_validation(folder)
            (folder/'visuals.json').write_text('[1]')
            with self.assertRaisesRegex(AssertionError,'Stale leg validation'):
                require_leg_validation(folder)

    def test_thigh_crossing_with_safe_shoes(self):
        obs=(['panel'],np.array([[0,0,.6]]),np.eye(3)[None],np.array([[.3,.03,.2]]))
        v=dict(back=[0,-1,0],legs={'-1':[[0,-.3,.8],[0,.3,.4],[0,.5,.055]]})
        d,labels=gaps(v,obs)
        self.assertLess(d[labels.index('-1:thigh'),0],0)
        self.assertGreater(d[labels.index('-1:shoe'),0],0)

if __name__=='__main__':unittest.main()
