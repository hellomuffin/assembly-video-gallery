"""Joint-space constraints for the visible skin between rigid body proxies.

Blended skin can cross a thin panel even when each neighboring rigid collider
is clear. Repair those contacts by moving the articulated joints, with the
original wrist, foot, support, velocity and joint-limit constraints intact.
"""
import copy
import numpy as np
from scipy.optimize import least_squares
from scipy.optimize._numdiff import approx_derivative
from body_geometry import Surface
from leg_clearance import boxes
from audit_leg_surface import triangle_box_intersections


class SurfaceConstraints:
    def __init__(self):
        self.surface=Surface(neck=True,forearms=True,gaze=True)
        self.triangles=np.array([[f[0],f[j],f[j+1]] for f in self.surface.faces for j in range(1,len(f)-1)])

    @staticmethod
    def operator(body,q):
        v=body.landmarks(q)
        return dict(shoulder_center=v['shoulder'],hip=v['hip'],forward=-np.array(v['back']),
            head=v['head'],camera_quaternion=v['camera_quaternion'],legs=v['legs'],
            arms={'hand_'+k:a for k,a in v['arms'].items()},segment_frames=v['segment_frames'],clavicles=v['clavicles'])

    @staticmethod
    def obstacles(body):
        return boxes(body.predicted_row if getattr(body,'coupling',False) else body.row,body.spec)

    def contacts(self,body,q,margin=0.):
        vertices=self.surface.deform({'operator':self.operator(body,q)})
        triangles=vertices[self.triangles];lower=triangles.min(axis=1);upper=triangles.max(axis=1)
        contacts=[];hits={}
        for index,(name,center,rotation,half) in enumerate(zip(*self.obstacles(body))):
            extent=np.abs(rotation)@(half+margin)
            candidates=np.flatnonzero(np.all(lower<=center+extent,axis=1)&np.all(upper>=center-extent,axis=1))
            if not len(candidates):continue
            local=(triangles[candidates]-center)@rotation
            selected=triangle_box_intersections(local,half+margin)
            if not selected.any():continue
            hits[name]=int(selected.sum())
            for triangle,points in zip(candidates[selected],local[selected]):
                gaps=np.r_[points.min(axis=0)-half,(-points).min(axis=0)-half]
                face=int(np.argmax(gaps));contacts.append((int(triangle),index,face%3,1. if face<3 else -1.))
        floor=np.flatnonzero(vertices[:,2]<(margin if margin>0 else -.001))
        if len(floor):
            hits['floor']=float(vertices[floor,2].min())
            contacts.extend((int(vertex),-1,2,1.) for vertex in floor)
        return contacts,hits

    def repair(self,body,q,residual,jacobian,bounds,max_nfev=100):
        evaluations=0
        for iteration in range(4):
            actual,hits=self.contacts(body,q)
            if not actual:return q,{},evaluations,iteration
            contacts,_=self.contacts(body,q,margin=.004)
            used=np.unique(np.concatenate([self.triangles[t] if obstacle>=0 else [t] for t,obstacle,_,_ in contacts]))
            source=self.surface.used[used];subset=copy.copy(self.surface)
            subset.rest=self.surface.rest[source].copy();subset.weights=self.surface.weights[source].copy();subset.used=np.arange(len(source))
            mapping=np.full(len(self.surface.used),-1,dtype=int);mapping[used]=np.arange(len(used))
            constraints=[(mapping[self.triangles[t]] if obstacle>=0 else np.array([mapping[t]]),obstacle,axis,sign) for t,obstacle,axis,sign in contacts]

            def skin_residual(value):
                vertices=subset.deform({'operator':self.operator(body,value)})
                _,centers,rotations,halves=self.obstacles(body);values=[]
                for ids,obstacle,axis,sign in constraints:
                    if obstacle<0:gap=float(vertices[ids,2].min());margin=0.
                    else:
                        local=(vertices[ids]-centers[obstacle])@rotations[obstacle]
                        gap=float((sign*local[:,axis]).min()-halves[obstacle,axis]);margin=.004
                    values.append(max(0.,margin-gap)*5000.)
                return np.asarray(values)

            def combined(value):return np.r_[residual(value),skin_residual(value)]
            def derivative(value):
                base=jacobian(value)
                skin=approx_derivative(skin_residual,value,method='3-point',abs_step=1e-6)
                return np.vstack([base,skin])

            result=least_squares(combined,np.clip(q,bounds[0]+1e-8,bounds[1]-1e-8),jac=derivative,
                bounds=bounds,max_nfev=max_nfev,ftol=1e-6,xtol=1e-6,gtol=1e-5)
            q=result.x;evaluations+=result.nfev
        _,hits=self.contacts(body,q)
        return q,hits,evaluations,4
