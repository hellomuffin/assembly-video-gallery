"""Contact-aware articulated motion preflight.

An infeasible task is reported, never repaired by displacing knees or stretching
bones. Feet have explicit stance/swing phases. Candidate motion is private until
an independent full-rate audit accepts it.
"""
from pathlib import Path
import json,sys
import numpy as np
from scipy.spatial.transform import Rotation as R
from articulated_body import Body,THIGH,SHIN
from task_stance import work_target,plan_stance
from foot_contacts import choose_landing,boxes
from task_hands import hand_constraints,attach_free_hands


def angle_delta(a,b):return (a-b+np.pi)%(2*np.pi)-np.pi

def stance_seed(body,height,yaw,anchors):
    # A continuous crouch preference; task/contact constraints still determine
    # whether the requested posture is feasible.
    u=float(np.clip((.95-height)/.70,0,1))
    a=body.seed('stand',yaw=yaw);b=body.seed('squat',yaw=yaw)
    q=a*(1-u)+b*u
    hip=q[body.index['left_hip_flexion']]-q[4]
    knee=q[body.index['left_knee']]
    q[2]=.065+THIGH*np.cos(hip)+SHIN*np.cos(hip+knee)
    body.set(q)
    center=np.mean([body.point(side+'_ankle') for side in ['left','right']],axis=0)
    q[:2]+=np.mean(list(anchors.values()),axis=0)[:2]-center[:2]
    return q


def task_center(targets,yaw,fallback):
    if not targets:return np.asarray(fallback)
    center=np.mean(list(targets.values()),axis=0)
    if len(targets)==1:
        side=next(iter(targets));sign=-1 if side=='left' else 1
        center-=R.from_euler('z',yaw).apply([sign*.168,0,0])
    return center


def plan(rows,spec,stride=5,limit=None):
    body=Body(spec);stations={};reach_starts={};foot_yaws={'left':0.,'right':0.};keys=[];failures=[];previous=None;anchors=None;gait=None;next_side='left';yaw=0.;last_t=rows[0]['t'];last_center=np.array([0,-1,1.])
    # The operator starts in a collision-free station for the first operation.
    # The virtual gripper's idle location does not define the human's spawn.
    first=next((j for j,r in enumerate(rows) if r['stage'].startswith(('Approach ','Reach for '))),None)
    if first is not None:
        key,j=work_target(rows,first,spec);stations[key]=plan_stance(body,rows[j],spec)
        anchors={side:a.copy() for side,a in stations[key]['anchors'].items()};yaw=stations[key]['yaw'];foot_yaws={side:yaw for side in anchors}
    stop=min(len(rows),limit or len(rows))
    for i in sorted(set([*range(0,stop,stride),stop-1])):
        row=rows[i];station_key,target_index=work_target(rows,i,spec)
        if station_key and station_key not in stations:
            stations[station_key]=plan_stance(body,rows[target_index],spec);print('WORK_STANCE',station_key,stations[station_key]['report'],flush=True)
        station=stations.get(station_key)
        hands,targets=hand_constraints(row,spec)
        if station_key and station_key.startswith('pickup:') and row['stage'].startswith('Reach for '):
            duration=2.;remaining=rows[target_index]['t']-row['t']
            if remaining<=duration and previous is not None:
                if station_key not in reach_starts:
                    body.set(previous);reach_starts[station_key]=(row['t'],body.point('left_wrist'))
                t0,start=reach_starts[station_key];_,goal=hand_constraints(rows[target_index],spec)
                u=np.clip((row['t']-t0)/max(rows[target_index]['t']-t0,.04),0,1);u=u*u*(3-2*u)
                targets['left']=start*(1-u)+goal['left']*u
        dt=row['t']-last_t;last_t=row['t']
        center=task_center(targets,yaw,last_center)
        if row['stage'].startswith('Reach for '):center[2]=max(center[2] if targets else .3,float(row['gripper'][0][2]))
        last_center=center.copy()
        goal_center=np.mean(list(station['anchors'].values()),axis=0)[:2] if station is not None else center[:2]-R.from_euler('z',yaw).apply([0,.35,0])[:2]
        feet_center=np.mean(list(anchors.values()),axis=0)[:2] if anchors is not None else goal_center
        travel=goal_center-feet_center;distance=np.linalg.norm(travel)
        walking=station is not None and distance>.35 and row['stage'].startswith(('Approach ','Carry '))
        desired_yaw=np.arctan2(-travel[0],travel[1]) if walking else station['yaw'] if station is not None else yaw
        if row.get('two_hands'):desired_yaw=0.
        if center[2]>.55:yaw+=np.clip(angle_delta(desired_yaw,yaw),-.5*dt,.5*dt)
        desired_xy=goal_center
        if anchors is None:
            q=body.seed('stand',desired_xy,yaw);anchors={side:body.point(side+'_ankle') for side in ['left','right']}
            for side in anchors:anchors[side][2]=.065
            obstacles=boxes(row,spec)
            anchors['left']=choose_landing(anchors['left'],yaw,obstacles,'left',anchors['right'])
            anchors['right']=choose_landing(anchors['right'],yaw,obstacles,'right',anchors['left'])
        foot_center=np.mean(list(anchors.values()),axis=0)
        support=['left','right']
        needs_step=(max(np.linalg.norm(station['anchors'][side]-anchors[side]) for side in anchors)>.05 or max(abs(angle_delta(station['yaw'],foot_yaws[side])) for side in anchors)>.10) if station is not None else np.linalg.norm(desired_xy-foot_center[:2])>.16
        if gait is None and center[2]>.55 and needs_step:
            choices=[next_side,'right' if next_side=='left' else 'left'];errors=[]
            for side in choices:
                other='right' if side=='left' else 'left';sign=-1 if side=='left' else 1
                if walking:
                    midpoint=foot_center[:2]+travel/max(distance,1e-9)*min(.20,distance)
                    target=midpoint+R.from_euler('z',yaw).apply([sign*.13,0,0])[:2]
                elif station is not None:target=station['anchors'][side][:2]
                else:target=desired_xy+R.from_euler('z',yaw).apply([sign*.13,0,0])[:2]
                delta=target-anchors[side][:2];delta*=min(1.,.40/max(np.linalg.norm(delta),1e-9))
                end=anchors[side].copy();end[:2]+=delta
                end_yaw=foot_yaws[side]+np.clip(angle_delta(desired_yaw,foot_yaws[side]),-.40,.40)
                try:end=choose_landing(end,yaw,boxes(row,spec),side,anchors[other])
                except RuntimeError as error:
                    errors.append(str(error));continue
                gait=dict(t=row['t'],side=side,other=other,start=anchors[side].copy(),end=end,yaw0=foot_yaws[side],yaw1=end_yaw)
                break
            if gait is None:
                failures.append(dict(frame=i,stage=row['stage'],reason='No feasible next footstep',anchors={s:a.tolist() for s,a in anchors.items()},goal=desired_xy.tolist(),yaw=float(yaw)))
                break
        if gait is not None:
            elapsed=row['t']-gait['t'];support=[gait['other']]
            u=np.clip((elapsed-.15)/.45,0,1);blend=u*u*(3-2*u)
            foot_yaws[gait['side']]=gait['yaw0']+angle_delta(gait['yaw1'],gait['yaw0'])*blend
            anchors[gait['side']]=gait['start']*(1-blend)+gait['end']*blend+np.array([0,0,.10*np.sin(np.pi*u)])
            if elapsed>=.70:
                anchors[gait['side']]=gait['end'];next_side=gait['other'];gait=None;support=['left','right']
        nominal=stance_seed(body,center[2],yaw,anchors)
        initial=previous if previous is not None else nominal
        # Preserve the previous arm posture through ratchet cycles and body
        # movement instead of choosing a different IK branch at each frame.
        q,report=body.fit(targets,row,initial=initial,nominal=nominal,anchors=anchors,support_sides=support,continuity=previous,foot_yaws=foot_yaws,max_nfev=70)
        if not report['accepted']:
            q2,r2=body.fit(targets,row,initial=nominal,nominal=nominal,anchors=anchors,support_sides=support,continuity=previous,foot_yaws=foot_yaws,max_nfev=120)
            if r2['cost']<report['cost']:q,report=q2,r2
        if not report['accepted']:failures.append(dict(frame=i,stage=row['stage'],**report))
        previous=q.copy();v=body.landmarks(q);v.update(attach_free_hands(body,q,hands,{k:t for k,t in targets.items() if k!='left' or row.get('held') or not row['stage'].startswith('Reach for ')}))
        if not row.get('tool_parked') and 'right' not in targets:v['tool']=v['right'][:2]
        keys.append(dict(frame=i,q=q.tolist(),foot_yaws=foot_yaws.copy(),anchors={k:a.tolist() for k,a in anchors.items()},support=support,report=report,visual=v))
        if i%100==0 or not report['accepted']:print(i,row['stage'],report,flush=True)
    return dict(passed=not failures,keyframes=keys,failures=failures,stations={key:{'q':v['q'].tolist(),'anchors':{side:a.tolist() for side,a in v['anchors'].items()},'report':v['report']} for key,v in stations.items()},scope='Candidate articulated contact motion. Full-rate mesh and swept collision audit required before rendering as a product.')

if __name__=='__main__':
    folder=Path(sys.argv[1]);rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text())
    result=plan(rows,spec,limit=int(sys.argv[2]) if len(sys.argv)>2 else None)
    (folder/'body-candidate.json').write_text(json.dumps(result,indent=2));print('CANDIDATE',result['passed'],len(result['failures']),flush=True)
