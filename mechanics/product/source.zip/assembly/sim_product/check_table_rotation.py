"""Focused full-rate rotation regression, using side-edge physical grasps."""
import json,sys
from pathlib import Path
import numpy as np
from articulated_body import Body,R
from task_hands import hand_constraints,attach_free_hands
from validate_body_motion import validate

folder=Path(sys.argv[1]);rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text());body=Body(spec)
indices=[i for i,row in enumerate(rows) if row.get('two_hands') and .08<R.from_quat(row['parts']['top'][1],scalar_first=True).magnitude()<3.05 and row['stage'] in ['Lift and orient top','Carry top']]
selected=[rows[i] for i in indices];visual=[];qs=[];previous=None;anchors=None
options=[]
for distance in [.30,.40,.50,.60]:
    focus=np.mean(list(hand_constraints(selected[0],spec)[1].values()),axis=0)
    nominal=body.seed('stand',focus[:2]-[0,distance],0);candidate={side:body.point(side+'_ankle') for side in ['left','right']}
    for side in candidate:candidate[side][2]=.065
    checkpoints=[]
    seed=None
    for j in [len(selected)//2,0,len(selected)-1]:
        _,targets=hand_constraints(selected[j],spec)
        attempts=[body.fit(targets,selected[j],mode='stand',nominal=nominal,anchors=candidate,initial=start,max_nfev=200) for start in [None,seed]]
        q,r=min(attempts,key=lambda pair:(not pair[1]['accepted'],pair[1]['cost']))
        print('STANCE',distance,j,r,flush=True);checkpoints.append((q,r))
        if seed is None:seed=q
    if all(r['accepted'] for q,r in checkpoints):options.append((sum(r['cost'] for q,r in checkpoints),nominal.copy(),candidate,checkpoints[1][0]))
if not options:raise RuntimeError('No fixed stance passes the complete rotation; revise task trajectory')
_,nominal,anchors,previous=min(options,key=lambda o:o[0])
for index,row in zip(indices,selected):
    hands,targets=hand_constraints(row,spec);focus=np.mean(list(targets.values()),axis=0)
    if anchors is None:
        nominal=body.seed('stand',focus[:2]-[0,.30],0);anchors={side:body.point(side+'_ankle') for side in ['left','right']}
        for side in anchors:anchors[side][2]=.065
    q,report=body.fit(targets,row,mode='stand',nominal=nominal,anchors=anchors,initial=previous,continuity=previous,max_nfev=100)
    if not report['accepted']:print('REJECT',index,report,flush=True)
    previous=q;qs.append(q.tolist());v=body.landmarks(q);v.update(attach_free_hands(body,q,hands,targets));visual.append(v)
    if index%25==0:print('POSE',index,report,flush=True)
report=validate(selected,qs,spec,subsamples=3)
report['source_frames']=indices
out=folder/'rotation-regression';out.mkdir(exist_ok=True)
for name,value in [('trajectory',selected),('visuals',visual),('asset',spec),('validation',report)]:
    (out/(name+'.json')).write_text(json.dumps(value,indent=2 if name=='validation' else None))
print('VALIDATION',report['passed'],report['checked_poses'],len(report['failures']),report['failures'][:4],flush=True)
