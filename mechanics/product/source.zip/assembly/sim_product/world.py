"""Shared atomic-operation layer: rigid-body furniture physics, assisted surface
grasps, bounded-motion tool animation and guarded fasteners. Finger contacts and
ratchet internals are intentionally approximated; part poses remain simulated.
"""
from pathlib import Path
import sys,json,numpy as np
from scipy.spatial.transform import Rotation as R,Slerp
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'sim_shared'))
from engine import AssemblyWorld,ActionRejected
def mixrot(a,b,u):return R.from_rotvec((b*a.inv()).as_rotvec()*u)*a
class World(AssemblyWorld):
 def __init__(self,asset,seed=1):
  self.stage='Inspect loose parts';self.tool=None;self.tool_control=False;self.tool_parked=False;self.stroke=0.;self.tool_engaged=False;self.closure=0.;self.two_hands=False;self.connector=None;self.grasp_profile='tool'
  super().__init__(asset,seed)
 def move(self,position,rotation=None,speed=.25):
  return super().move(position,rotation,speed)
 def advance(self,seconds):
  start=len(self.rows);super().advance(seconds)
  if self.tool_engaged and self.connector:
   tp,ta=self.tool_site(self.connector);tr=self.tool_rotation(ta)
   self.tool=[(tp-ta*.14).tolist(),tr.as_quat(scalar_first=True).tolist()]
  if not self.tool_control and not self.tool_parked:
   p,r=self.pose('gripper')
   self.tool=[(p+np.array([.23,-.05,.18])).tolist(),[1,0,0,0]]
  for row in self.rows[start:]:
   row.update(tool_parked=self.tool_parked,tool_control=self.tool_control,grasp_profile=self.grasp_profile,stage=self.stage,tool=self.tool,stroke=self.stroke,tool_engaged=self.tool_engaged,closure=self.closure,two_hands=self.two_hands,connector=self.connector,engagement=self.engagement.copy())
 def site(self,part):
  p,r=self.pose(part);s=self.parts[part]
  return p+r.apply(s['grasp_position']),r*R.from_quat(s['grasp_rotation'],scalar_first=True)
 def grasp(self,part):
  if self.held:raise ActionRejected('Release first')
  p,r=self.pose(part);hp,hr=self.pose('gripper');gp,gr=self.site(part)
  if np.linalg.norm(hp-gp)>.02 or (hr.inv()*gr).magnitude()>.12:raise ActionRejected('Hand is not at the declared surface grasp')
  eid=self.m.equality('grasp_'+part).id
  self.m.eq_data[eid,3:6]=hr.inv().apply(p-hp);self.m.eq_data[eid,6:10]=(hr.inv()*r).as_quat(scalar_first=True)
  self.d.eq_active[eid]=True;self.held=part;self.events.append(dict(t=float(self.d.time),action='grasp',part=part))
 def fingers(self,amount):
  old=self.closure
  for u in np.linspace(0,1,21)[1:]:
   self.closure=float(old+(amount-old)*u);self.advance(.02)
 def pickup(self,part):
  self.stage='Approach '+part.replace('_',' ');self.connector=None;self.grasp_profile=self.parts[part].get('grasp_profile','tool')
  p,r=self.site(part);hp,_=self.pose('gripper')
  clearance=max(1.0,max(self.pose(n)[0][2]+max(self.parts[n]['size'])/2 for n in self.parts)+.15)
  self.move([hp[0],hp[1],clearance])
  self.move([p[0],p[1],clearance],r);self.advance(1.2)
  self.stage='Reach for '+part.replace('_',' ');self.move(p,r,speed=.25)
  self.stage='Grasp '+part.replace('_',' ');self.fingers(1);self.grasp(part)
 def carry(self,part,goal,rotation):
  hp,hr=self.pose('gripper');p,r=self.pose(part);local=hr.inv().apply(p-hp);relative=hr.inv()*r
  desired=rotation*relative.inv();target=np.asarray(goal)-desired.apply(local)
  group=self.group(part);radius=0.
  for n in group:
   bp,br=self.pose(n);half=np.array(self.parts[n]['size'])/2
   for signs in np.array(np.meshgrid([-1,1],[-1,1],[-1,1])).T.reshape(-1,3):
    radius=max(radius,float(np.linalg.norm(bp+br.apply(half*signs)-hp)))
  highest=max([0.]+[self.pose(n)[0][2]+abs(self.pose(n)[1].as_matrix()[2])@np.array(self.parts[n]['size'])/2 for n in self.parts if n not in group])
  ceiling=max(1.0,highest+radius+.10)
  self.stage='Raise '+part.replace('_',' ')
  self.move([hp[0],hp[1],ceiling],hr)
  self.stage='Carry '+part.replace('_',' ')
  self.move([target[0],target[1],ceiling],desired);self.advance(1.2)
  self.stage='Align '+part.replace('_',' ');self.move(target,desired,speed=.22);self.advance(.2)
 def release(self):
  if not self.held:return
  self.fingers(0);super().release()
 def tool_site(self,key):
  p,axis=super().tool_site(key);c=self.connectors[key]
  fraction=min(1.,self.engagement[key]/c['required_turns'])
  return p-axis*(.012*(1-fraction)+.0015),axis
 def tool_rotation(self,axis):
  y=-np.asarray(axis,float);x=np.cross([0,0,1],y)
  if np.linalg.norm(x)<.1:x=np.array([1.,0,0])
  x/=np.linalg.norm(x);return R.from_matrix(np.column_stack([x,y,np.cross(x,y)]))
 def tool_move(self,pos,rotation,duration=1.):
  if self.tool is None:self.tool=[[.65,-.7,.24],[1,0,0,0]]
  a=np.array(self.tool[0]);ar=R.from_quat(self.tool[1],scalar_first=True)
  count=max(1,int(duration/.02))
  for i in range(count):
   u=(i+1)/count;u=u*u*(3-2*u)
   self.tool=[(a+(np.asarray(pos)-a)*u).tolist(),mixrot(ar,rotation,u).as_quat(scalar_first=True).tolist()]
   self.advance(.02)
 def fasten(self,key,direction=1):
  self.tool_control=True;self.connector=key;c=self.connectors[key];pos,axis=self.tool_site(key);rot=self.tool_rotation(axis)
  # Tool position is the handle center. The bit extends 14 cm along local -Y.
  handle=pos-axis*.14
  self.stage='Position driver at '+key.replace('_',' ')
  park=np.array(self.tool[0]) if self.tool else np.array([.65,-.7,.24])
  self.tool_move(park+[0,0,.15],rot,1.2)
  self.tool_move(handle-axis*.15+[0,0,.30],rot,1.2)
  self.tool_move(handle-axis*.15,rot,.8);self.tool_move(handle,rot,.8)
  for i in range(15):
   self.stroke=-direction*np.pi/4*(i+1)/15;self.advance(.02)
  self.tool_engaged=True
  remaining=c['required_turns'] if direction>0 else .25
  while remaining>1e-8:
   step=min(.25,remaining);self.stage=('Tighten clockwise · ' if direction>0 else 'Loosen counterclockwise · ')+key.replace('_',' ')
   self.stroke=-direction*np.pi/4
   # Rotate through 90 degrees; return stroke uses an ideal one-way ratchet.
   count=40
   for i in range(count):
    pos,axis=self.tool_site(key);rot=self.tool_rotation(axis)
    self.stroke=direction*(-np.pi/4+(i+1)/count*2*np.pi*step)
    self.tool=[(pos-axis*.14).tolist(),rot.as_quat(scalar_first=True).tolist()]
    actual_tip=np.array(self.tool[0])+rot.apply([0,-.14,0])
    increment=direction*step/count
    if direction>0 and remaining<=.25+1e-8 and i==count-1:increment=c['required_turns']-self.engagement[key]
    super().turn(key,increment,c['minimum_torque']*1.2,actual_tip,axis)
    self.advance(.018)
   self.stage='Reset ratchet · '+key.replace('_',' ')
   initial=self.stroke
   for i in range(20):
    self.stroke=float(initial+(-direction*np.pi/4-initial)*(i+1)/20);self.advance(.02)
   remaining-=step
  self.tool_engaged=False;initial=self.stroke
  for i in range(15):
   self.stroke=initial*(1-(i+1)/15);self.advance(.02)
  self.stage='Withdraw driver'
  self.tool_move(handle-axis*.15,rot,.6);self.tool_move(handle-axis*.15+[0,0,.30],rot,.6)
  self.tool_move(self.pose('gripper')[0]+[.23,-.05,.18],R.identity(),1.2);self.connector=None;self.tool_control=False
 def finish(self):
  base=self.spec['base'];carrier=self.spec.get('finish_grasp_part',base)
  self.tool_control=True;self.stage='Set driver in the rack'
  park=np.array([.65,-.7,.086])
  safe_z=max(self.pose(n)[0][2]+abs(self.pose(n)[1].as_matrix()[2])@np.array(self.parts[n]['size'])/2 for n in self.parts)+.24
  current=np.array(self.tool[0])
  self.tool_move([current[0],current[1],safe_z],R.identity(),.8)
  self.tool_move([park[0],park[1],safe_z],R.identity(),1.2)
  self.tool_move(park,R.identity(),.8);self.tool_parked=True
  # Park the tool before pinning the left hand to the furniture. Otherwise the
  # two simultaneous targets can exceed the articulated body's entire span.
  self.pickup(carrier);self.stage='Reach second support grasp';self.two_hands=True
  # Aggregate wrench of the declared two-hand grasp, not an invisible fixture.
  self.max_force=160.;self.max_torque=32.;self.advance(1.2)
  self.stage='Turn completed furniture upright'
  p,r=self.pose(base);desired=R.from_quat(self.spec['finish_rotation'],scalar_first=True)
  offset=np.array(self.parts[carrier]['assembly_position'])-self.parts[base]['assembly_position']
  self.carry(carrier,np.array([0,0,self.spec['finish_height']+.015])+desired.apply(offset),desired)
  self.stage='Steady the upright furniture';self.advance(1.5)
  self.stage='Set down completed furniture';hp,hr=self.pose('gripper');self.move(hp+[0,0,-.012],hr,speed=.1)
  self.release();self.two_hands=False;self.move(self.target+[0,-.20,.35]);self.stage='Released · standing under gravity';self.advance(2)
