"""Signed escape constraints for deeply intersecting capsule/box contacts.

MuJoCo's capsule/box center-line distance saturates at minus the capsule radius
once the center line enters the box. A constant residual cannot guide IK out of
that state. Use an oriented box face separation constraint in that case; normal
separated contacts retain MuJoCo's distance and contact normal.
"""
import numpy as np
import mujoco


def geometry(model,data,contact):
    a,b=map(int,contact.geom);types={int(model.geom_type[a]),int(model.geom_type[b])}
    required={int(mujoco.mjtGeom.mjGEOM_BOX),int(mujoco.mjtGeom.mjGEOM_CAPSULE)}
    if types==required:
        capsule=a if model.geom_type[a]==mujoco.mjtGeom.mjGEOM_CAPSULE else b;box=b if capsule==a else a
        radius=float(model.geom_size[capsule,0])
        if contact.dist<=-radius+1e-8:
            center=data.geom_xpos[capsule];direction=data.geom_xmat[capsule].reshape(3,3)[:,2]*model.geom_size[capsule,1]
            ends=np.array([center-direction,center+direction]);rotation=data.geom_xmat[box].reshape(3,3)
            axes=np.r_[rotation.T,-rotation.T];half=np.r_[model.geom_size[box],model.geom_size[box]]
            projection=ends@axes.T;gap=projection.min(axis=0)-radius-axes@data.geom_xpos[box]-half
            chosen=int(np.argmax(gap));normal=axes[chosen];distance=float(gap[chosen])
            cap_point=ends[int(np.argmin(projection[:,chosen]))]-radius*normal
            # Any point on the support plane has the same normal projection.
            # This tangentially matched point also accounts for a rotating box
            # normal in the rigid-body contact Jacobian.
            box_point=cap_point-distance*normal
            return distance,box,box_point,capsule,cap_point,normal
    return float(contact.dist),a,contact.pos,b,contact.pos,contact.frame[:3]


def crossing_contacts(model,data,pairs):
    """Detect capsule center lines crossing boxes even when native CCD misses.

    Pairs are prefiltered to human capsules against scene boxes. A slab test in
    box coordinates is independent of MuJoCo's contact list and penetration
    distance. Native contacts are retained for near-surface clearance.
    """
    from types import SimpleNamespace
    pairs=np.asarray(pairs,dtype=int).reshape(-1,2)
    if not len(pairs):return
    capsules,boxes=pairs.T
    directions=data.geom_xmat[capsules].reshape(-1,3,3)[:,:,2]*model.geom_size[capsules,1,None]
    extents=np.einsum('nij,nj->ni',np.abs(data.geom_xmat[boxes].reshape(-1,3,3)),model.geom_size[boxes])
    # Conservative world AABBs discard distant pairs before the exact local
    # slab test. This changes query cost, not contact geometry or tolerances.
    possible=np.all(np.abs(data.geom_xpos[capsules]-data.geom_xpos[boxes])<=np.abs(directions)+extents+1e-12,axis=1)
    pairs=pairs[possible]
    for capsule,box in pairs:
        rotation=data.geom_xmat[box].reshape(3,3)
        center=(data.geom_xpos[capsule]-data.geom_xpos[box])@rotation
        direction=(data.geom_xmat[capsule].reshape(3,3)[:,2]*model.geom_size[capsule,1])@rotation
        half=model.geom_size[box]
        if np.any(np.abs(center)>half+np.abs(direction)):continue
        start=center-direction;delta=2*direction;lo=0.;hi=1.
        for axis in range(3):
            if abs(delta[axis])<1e-12:
                if abs(start[axis])>half[axis]:hi=-1.;break
            else:
                a=(-half[axis]-start[axis])/delta[axis];b=(half[axis]-start[axis])/delta[axis]
                lo=max(lo,min(a,b));hi=min(hi,max(a,b))
        if lo<=hi:
            yield SimpleNamespace(geom=(box,capsule),dist=-float(model.geom_size[capsule,0]))
