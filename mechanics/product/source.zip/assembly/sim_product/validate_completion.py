"""Independent completion check. Upright means aligned with gravity; exact
world yaw is not required to assemble and stand a piece of furniture."""
import json,sys,hashlib
from pathlib import Path
import numpy as np,mujoco
from scipy.spatial.transform import Rotation as R
H=Path(__file__).resolve().parent
def validate(name,seed=1):
 O=H.parent/'outputs/product_v1'/f'{name}_{seed}';s=json.loads((O/'asset.json').read_text());state=np.load(O/'final_state.npz')
 m=mujoco.MjModel.from_binary_path(str(O/'model.mjb'));d=mujoco.MjData(m);d.qpos[:]=state['qpos'];d.qvel[:]=state['qvel'];d.eq_active[:]=state['eq_active'];mujoco.mj_forward(m,d)
 desired=R.from_quat(s['finish_rotation'],scalar_first=True);actual=R.from_matrix(d.xmat[m.body(s['base']).id].reshape(3,3))
 tilt=float(np.degrees(np.arccos(np.clip(np.dot(actual.apply(desired.inv().apply([0,0,1])),[0,0,1]),-1,1))))
 expected={m.equality('joint_'+c['id']).id for c in s['connectors']};active=set(np.flatnonzero(d.eq_active))
 vels=[];bottoms=[]
 for p in s['parts']:
  b=m.body(p['id']).id;adr=m.jnt_dofadr[m.body_jntadr[b]];vels.extend(d.qvel[adr:adr+6]);bottoms.append(float(d.xpos[b,2]-abs(d.xmat[b].reshape(3,3)[2])@np.array(p['size'])/2))
 checks={'only_completed_fasteners_active':active==expected,'upright_tilt_under_2_degrees':tilt<2,'resting_on_floor':-.003<min(bottoms)<.003,'settled':max(abs(np.array(vels)))<.01,'gravity_enabled':bool(np.allclose(m.opt.gravity,[0,0,-9.81])),'no_furniture_gravity_compensation':all(m.body_gravcomp[m.body(p['id']).id]==0 for p in s['parts'])}
 checks={k:bool(v) for k,v in checks.items()}
 report={'passed':all(checks.values()),'checks':checks,'upright_tilt_degrees':tilt,'orientation_error_including_yaw_degrees':float(np.degrees((desired.inv()*actual).magnitude())),'maximum_final_speed':float(max(abs(np.array(vels)))),'floor_clearance_m':min(bottoms),'trajectory_sha256':hashlib.sha256((O/'trajectory.json').read_bytes()).hexdigest(),'scope':__doc__}
 (O/'completion.json').write_text(json.dumps(report,indent=2));print(name,seed,json.dumps(report),flush=True);assert report['passed']
if __name__=='__main__':validate(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 1)
