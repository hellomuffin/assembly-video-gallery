"""Plan both halves of a bimanual turn from a feasible vertical midpoint."""
import json,sys,copy
from pathlib import Path
import numpy as np
from articulated_body import Body,R
from carried_body import CarriedBody
from task_hands import hand_constraints
from validate_body_motion import validate

folder=Path(sys.argv[1]);rows=json.loads((folder/'trajectory.json').read_text());spec=json.loads((folder/'asset.json').read_text());plain=Body(spec)
reference=min([r for r in rows if r.get('two_hands') and r['stage']=='Carry top'],key=lambda r:abs(R.from_quat(r['parts']['top'][1],scalar_first=True).magnitude()-np.pi/2))
_,targets=hand_constraints(reference,spec);focus=np.mean(list(targets.values()),axis=0);nominal=plain.seed('stand',focus[:2]-[0,.4],0)
anchors={s:plain.point(s+'_ankle') for s in ['left','right']}
for s in anchors:anchors[s][2]=.065
body=CarriedBody(spec,reference,nominal,bimanual=True);object_rotation=R.from_quat(reference['parts']['top'][1],scalar_first=True)
body.hand_rotation_override=R.from_euler('x',-np.pi/2)*object_rotation.inv()*body.reference_rotation
initial,report=body.fit({},reference,mode='stand',initial=nominal,nominal=nominal,anchors=anchors,max_nfev=250)
print('MIDPOINT',report,flush=True)
if not report['accepted']:raise RuntimeError('No feasible vertical midpoint')
out=folder/'coupled-rotation-bidirectional';out.mkdir(exist_ok=True);records={};failures=[]
for direction,indices in [('backward',range(50,-1,-1)),('forward',range(51,101))]:
    previous=initial.copy()
    for i in indices:
        angle=-np.pi*i/100;body.hand_rotation_override=R.from_euler('x',angle)*object_rotation.inv()*body.reference_rotation
        q,report=body.fit({},reference,mode='stand',initial=previous,nominal=nominal,anchors=anchors,continuity=previous,max_nfev=120)
        row=copy.deepcopy(body.predicted_row);row['t']=i*.08;row['stage']='Coupled turn planning prediction';v=body.landmarks(q);hands,_=hand_constraints(row,spec);v.update(hands)
        records[i]=dict(row=row,visual=v,q=q.tolist(),report=report);previous=q
        if not report['accepted']:failures.append(dict(frame=i,**report))
        if i%10==0 or not report['accepted']:
            print(direction,i,round(row['parts']['top'][0][2],3),report,flush=True)
            (out/'candidate.partial.json').write_text(json.dumps(records))
result=[records[i] for i in range(101)];report={'passed':not failures,'requires_physics_execution':True,'failures':failures}
if not failures:
    report['geometry']=validate([r['row'] for r in result],[r['q'] for r in result],spec,subsamples=3);report['passed']=report['geometry']['passed']
for name,value in [('candidate',dict(report=report,frames=result)),('trajectory',[r['row'] for r in result]),('visuals',[r['visual'] for r in result]),('asset',spec),('validation',report)]:
    (out/(name+'.json')).write_text(json.dumps(value))
print('TURN_RESULT',report['passed'],'pose_failures',len(failures),'audit_failures',len(report.get('geometry',{}).get('failures',[])),flush=True)
