"""Stage only validated completion videos and their reproducible sources."""
from pathlib import Path
import json,hashlib,shutil,zipfile
H=Path(__file__).resolve().parent;A=H.parent;O=A/'outputs/product_v1';S=A/'showcase/mechanics/product'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
from body_proof import require_body_validation
reports={};core=read(O/'core-regression/validation.json');assert core['passed']
for name in ['table','shelf']:
 for seed in [1,7]:
  d=O/f'{name}_{seed}';r=read(d/'completion.json');assert r['passed']
  assert r['trajectory_sha256']==sha(d/'trajectory.json')
  reports[f'{name}_{seed}']=r
 d=O/f'{name}_1';reports[f'{name}_articulated_body']=require_body_validation(d);r=read(d/'audit.json');assert r['passed']
 assert r['trajectory_sha256']==sha(d/'trajectory.json')
 reports[f'{name}_recording_audit']=r
 v=read(d/'visual-check.json');assert v['passed'];reports[f'{name}_visual_reach']=v
manifest=read(O/'media/manifest.json');assert {v['file'] for v in manifest['videos']}=={f'{n}-{v}.mp4' for n in ['table','shelf'] for v in ['overview','ego','detail']}
for v in manifest['videos']:
 d=O/f'{v["furniture"]}_1'
 assert v['trajectory_sha256']==sha(d/'trajectory.json')
 assert v['visuals_sha256']==sha(d/'visuals.json')
 assert v['sha256']==sha(O/'media'/v['file'])
S.mkdir(parents=True,exist_ok=True)
for p in (O/'media').iterdir():
 if p.suffix in ['.mp4','.jpg','.json']:shutil.copy2(p,S/p.name)
shutil.copy2(H/'page.html',S/'index.html')
from stage_body_reviews import stage_body_reviews
stage_body_reviews(O,S)
(S/'validation.json').write_text(json.dumps({'passed':True,'completion_and_recording_checks':reports,'core_regression':core},indent=2))
files=list(H.glob('*.py'))+[H/'README.txt',* (H/'assets').glob('*.json'),A/'sim_shared/engine.py',A/'sim_shared/test_physics.py',A/'sim_shared/reference_demo.py',* (A/'sim_shared/assets').glob('*.json'),A/'sim_v2/render_blender.py',A/'sim_v3/render_hand.py',A/'sim_v3/vendor/myo_sim/LICENSE',A/'sim_v5/human_surface.py']
files += [A/'outputs/hand_v3'/n for n in ['lift_geometry.json','lift_frames.json','contact_model.xml']]
files += [A/'sim_v5/assets/makehuman'/n for n in ['base.obj','default.mhskel','default_weights.mhw','LICENSE.ASSETS.md','provenance.json']]
files += list((H/'tests').rglob('*.json'))
with zipfile.ZipFile(S/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(A.parent)))
 for review in read(O/'body-review-inputs.json'):
  script=Path(review['directory'])/'render_script.py'
  z.write(script,'assembly/review_scripts/'+review['furniture']+'.py')
  interval=script.parent.parent/(script.parent.name.replace('-verified-motion-','-review-interval-')+'.json')
  z.write(interval,str(interval))
 z.writestr('requirements.txt','numpy==2.2.6\nscipy==1.17.1\nmujoco==3.14.0\nPillow==11.3.0\n')
with zipfile.ZipFile(O/'recordings.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['table','shelf']:
  for seed in [1,7]:
   d=O/f'{name}_{seed}'
   for filename in ['asset.json','trajectory.json','events.json','model.xml','model.mjb','final_state.npz','completion.json','audit.json','visuals.json','visual-check.json','body-validation.json','result.json','integration-state.npy','controller-state.json','continuation-parent-audit.json']:
    p=d/filename
    if p.exists():z.write(p,str(p.relative_to(O)))
   for directory in ['execution_sources','execution_parent']:
    for p in (d/directory).rglob('*'):
     if p.is_file():z.write(p,str(p.relative_to(O)))
from recording_downloads import stage_recording_downloads
stage_recording_downloads(O/'recordings.zip',S)
if (O/'recordings-release.json').exists():
 from recording_downloads import use_recording_release
 use_recording_release(S,O/'recordings-release.json')
print('Staged',S,flush=True)
