"""Regression tests for the structural causes of the rejected leg workaround."""
import unittest
import numpy as np
from articulated_body import Body,THIGH,SHIN,UPPER_ARM,FOREARM
from foot_contacts import landing_clear,choose_landing
from validate_body_motion import validate_pose
from task_hands import hand_constraints

SPEC={'parts':[{'id':'block','size':[.3,.3,.3],'mass':1.,'assembly_position':[0,0,.15]}],'connectors':[],'base':'block'}
ROW={'parts':{'block':[[0,0,.15],[1,0,0,0]]},'held':None,'fastened':[],'gripper':[[0,0,1.],[1,0,0,0]],'tool':[[0,0,1.],[1,0,0,0]],'stage':'Released','two_hands':False}

class AnatomyRegression(unittest.TestCase):
    def setUp(self):self.body=Body(SPEC)
    def test_between_frame_native_skin_crossing_is_rejected(self):
        import json
        from pathlib import Path
        from validate_body_motion import validate_transition,ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_between_frame_skin.json').read_text())
        body=Body(fixture['spec'],comfortable=True);previous,row=fixture['rows'];surface=ClothingAudit()
        for endpoint in [previous,row]:
            self.assertEqual(validate_pose(body,endpoint['body_q'],endpoint,surface),[])
        failures=validate_transition(body,previous,row,row['body_q'])
        self.assertEqual([f['between_fraction'] for f in failures],[.5])
        self.assertEqual(failures[0]['errors'],[{'rendered_clothing':{'left':1}}])

    def test_between_frame_foot_floor_crossing_is_rejected(self):
        import json
        from pathlib import Path
        from validate_body_motion import validate_transition,ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_between_frame_floor.json').read_text())
        body=Body(fixture['spec'],comfortable=True);previous,row=fixture['rows'];surface=ClothingAudit()
        for endpoint in [previous,row]:
            self.assertEqual(validate_pose(body,endpoint['body_q'],endpoint,surface),[])
        failures=validate_transition(body,previous,row,row['body_q'])
        self.assertEqual([f['between_fraction'] for f in failures],[.25,.5,.75])
        self.assertTrue(all(any('penetration' in error for error in f['errors']) for f in failures))

    def test_shorter_alternating_step_precedes_same_foot_hopping(self):
        import json
        from pathlib import Path
        from types import SimpleNamespace
        from embodied_world import EmbodiedWorld
        from validate_body_motion import ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_stalled_step.json').read_text())
        row=fixture['row'];body=Body(fixture['spec'],comfortable=True);surface=ClothingAudit();poses=[]
        class PlannedStep(Exception):pass
        def execute(q,anchors,yaws,**options):
            sample={**row,'body_anchors':anchors,'body_foot_yaws':yaws,'body_support':options['support_goal']}
            self.assertEqual(validate_pose(body,q,sample,surface),[])
            poses.append({s:a.copy() for s,a in anchors.items()})
            if len(poses)==9:raise PlannedStep()
        world=SimpleNamespace(spec=fixture['spec'],operator=body,operator_q=np.asarray(row['body_q']),
            anchors={s:np.asarray(a) for s,a in row['body_anchors'].items()},foot_yaws=row['body_foot_yaws'],
            current_row=lambda:row,execute_pose=execute)
        with self.assertRaises(PlannedStep):EmbodiedWorld.walk_to(world,row['walk_target'])
        self.assertGreater(np.linalg.norm(poses[-1]['left']-world.anchors['left']),.1)
        np.testing.assert_allclose(poses[-1]['right'],world.anchors['right'],atol=1e-12)
        waypoint=np.array([.6,.7]);start=np.mean(list(world.anchors.values()),axis=0)[:2];end=np.mean(list(poses[-1].values()),axis=0)[:2]
        self.assertLess(np.linalg.norm(end-waypoint),np.linalg.norm(start-waypoint))

    def test_driver_preparation_refines_supporting_grasp_without_relaxation(self):
        import json
        from pathlib import Path
        from task_stance import fit_work_contact
        from validate_body_motion import ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_driver_preparation.json').read_text())
        body=Body(fixture['spec'],comfortable=True);options=fixture['options']
        for key in ['initial','nominal','continuity']:options[key]=np.asarray(options[key])
        options['anchors']={s:np.asarray(a) for s,a in options['anchors'].items()}
        self.assertFalse(fixture['report']['accepted'])
        self.assertGreater(fixture['report']['wrist_error_m']['left'],.008)
        q,report=fit_work_contact(body,{s:np.asarray(t) for s,t in fixture['targets'].items()},fixture['row'],**options)
        self.assertTrue(report['accepted'],report)
        self.assertEqual(validate_pose(body,q,{**fixture['row'],'body_anchors':options['anchors'],
            'body_foot_yaws':options['foot_yaws']},ClothingAudit()),[])

    def test_shelf_approach_refines_contact_without_relaxing_clearance(self):
        import json
        from pathlib import Path
        from task_stance import fit_work_contact
        from validate_body_motion import ClothingAudit
        f=json.loads((Path(__file__).parent/'tests/fixtures/shelf_precise_contact.json').read_text())
        body=Body(f['spec'],comfortable=True);options=f['options']
        for key in ['initial','nominal','continuity']:
            if key in options:options[key]=np.array(options[key])
        options['anchors']={s:np.array(a) for s,a in options['anchors'].items()}
        targets={s:np.array(t) for s,t in f['targets'].items()}
        self.assertGreater(max(f['unrefined_report']['wrist_error_m'].values()),.004)
        q,report=fit_work_contact(body,targets,f['row'],**options)
        self.assertTrue(report['accepted'],report)
        self.assertLess(max(report['wrist_error_m'].values()),.004)
        self.assertEqual(validate_pose(body,q,{**f['row'],'body_anchors':options['anchors'],
            'body_foot_yaws':options['foot_yaws']},ClothingAudit()),[])

    def test_pose_tracking_preserves_loaded_foot_support(self):
        import json
        from pathlib import Path
        from validate_body_motion import ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_support_tracking.json').read_text())
        row=fixture['row'];debug=row['body_debug'];body=Body(fixture['spec'],comfortable=True)
        previous=np.array(debug['previous']);nominal=np.array(debug['nominal'])
        body.obstacles(row);body.set(nominal);center=body.load_center().copy()
        _,targets=hand_constraints(row,fixture['spec'])
        anchors={s:np.array(a) for s,a in debug['anchors'].items()}
        actual,report=body.fit(targets,row,initial=previous,nominal=nominal,anchors=anchors,
            foot_yaws=debug['foot_yaws'],continuity=previous,motion_dt=.04,
            balance_center=center,posture_weight=20.,max_nfev=250)
        # This executed carry frame previously lost the required 5 mm margin
        # because the stronger pose preference overrode the support penalty.
        self.assertTrue(report['accepted'],report)
        self.assertGreaterEqual(report['support_margin_m'],.005)
        self.assertEqual(validate_pose(body,actual,{**row,'body_anchors':debug['anchors'],
            'body_foot_yaws':debug['foot_yaws']},ClothingAudit()),[])

    def test_sparse_skinning_preserves_every_rendered_vertex(self):
        from surface_constraints import SurfaceConstraints
        checker=SurfaceConstraints();surface=checker.surface;rng=np.random.default_rng(52)
        for mode in ['stand','squat']:
            for _ in range(4):
                q=self.body.seed(mode,[0,-1],float(rng.uniform(-4,4)))
                q[4:]+=rng.normal(0,.05,len(q)-4);q=np.clip(q,self.body.bounds[0]+1e-8,self.body.bounds[1]-1e-8)
                operator=checker.operator(self.body,q)
                for native_frames in [True,False]:
                    row={'operator':dict(operator)}
                    if not native_frames:row['operator'].pop('segment_frames',None)
                    np.testing.assert_allclose(surface.deform(row),surface.deform(row,sparse=False),atol=1e-12,rtol=0)
        # Surface collision repair makes shallow copies with smaller arrays.
        # A copied full-mesh cache must not address those subset arrays.
        import copy
        subset=copy.copy(surface);indices=surface.used[::73]
        subset.rest=surface.rest[indices].copy();subset.weights=surface.weights[indices].copy();subset.used=np.arange(len(indices))
        np.testing.assert_allclose(subset.deform(row),subset.deform(row,sparse=False),atol=1e-12,rtol=0)

    def test_driver_route_checks_tool_even_when_body_pose_is_clear(self):
        import json
        from pathlib import Path
        from task_hands import driver_tool_clear
        from leg_clearance import boxes
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_driver_tool_route.json').read_text())
        obstacles=boxes(fixture['row'],fixture['spec'])
        self.assertFalse(driver_tool_clear(fixture['rejected_tool'],obstacles))
        self.assertTrue(driver_tool_clear(fixture['clear_tool'],obstacles))

    def test_setdown_stance_reaches_standing_without_crossing_table(self):
        import json
        from pathlib import Path
        from final_motion import standing_path
        from validate_body_motion import ClothingAudit
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_setdown_exit.json').read_text())
        body=Body(fixture['spec'],comfortable=True);start=np.array(fixture['q'])
        anchors={s:np.array(a) for s,a in fixture['anchors'].items()};yaws={s:fixture['yaw'] for s in anchors}
        path=standing_path(body,fixture['row'],start,anchors,yaws,fixture['yaw'])
        self.assertGreater(path[-1][2],.78)
        self.assertTrue(all(path[-1][body.index[s+'_knee']]>=np.radians(-40) for s in anchors))
        row={**fixture['row'],'held':None,'two_hands':False,'stage':'Stand before walking','body_anchors':fixture['anchors'],'body_foot_yaws':yaws}
        surface=ClothingAudit();previous=start
        for q in path:
            for u in np.linspace(0,1,9):
                self.assertEqual(validate_pose(body,previous+(q-previous)*u,row,surface),[])
            previous=q

    def test_native_neck_does_not_flip_when_looking_down(self):
        from surface_constraints import SurfaceConstraints
        body=self.body;q=body.seed('stand',[0,-1],0)
        q[4]=np.radians(20);q[body.index['spine_pitch']]=np.radians(35)
        audit=SurfaceConstraints();surface=audit.surface
        neck=surface.weights[surface.used,surface.names.index('neck')]>.05
        previous=None
        for pitch in np.arange(28,33.1,.5):
            q[body.index['neck_pitch']]=np.radians(pitch)
            vertices=surface.deform({'operator':audit.operator(body,q)})[neck]
            if previous is not None:
                # A half-degree nod used to flip the neck frame and move skin
                # by 73 mm. It must remain a small continuous joint motion.
                self.assertLess(np.linalg.norm(vertices-previous,axis=1).max(),.003)
            previous=vertices

    def test_low_fastener_has_a_fixed_anatomy_crouching_stance(self):
        import json
        from pathlib import Path
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_crouching_work_stance.json').read_text())
        row=fixture['row'];body=Body(fixture['spec'],comfortable=True);q=np.array(row['body_q'])
        _,targets=hand_constraints(row,fixture['spec']);anchors={s:np.array(a) for s,a in row['body_anchors'].items()}
        actual,report=body.fit(targets,row,initial=q,nominal=q,anchors=anchors,foot_yaws=row['body_foot_yaws'],max_nfev=150)
        self.assertTrue(report['accepted'],report)
        self.assertLess(actual[2],.45)
        self.assertLessEqual(actual[4],np.radians(20)+1e-8)
        self.assertLessEqual(actual[body.index['spine_pitch']],np.radians(35)+1e-8)
        # This is a task posture policy, not changed anatomy or leg lengths.
        self.assertAlmostEqual(body.bounds[1][4],np.radians(45))
        for chain in body.landmarks(actual)['legs'].values():
            np.testing.assert_allclose(np.linalg.norm(np.diff(chain,axis=0),axis=1),[THIGH,SHIN],atol=1e-9)

    def test_publication_audit_rejects_the_folded_working_posture(self):
        from validate_body_motion import validate
        q=self.body.seed('stand',[0,-1],0);q[4]=np.radians(40)
        # The physical anatomy still permits bending; accepted working motion
        # must also satisfy the coordinated-posture policy.
        self.assertNotIn('working posture limit',validate_pose(self.body,q,ROW))
        report=validate([ROW],[q],SPEC,clothing=False)
        self.assertTrue(any('working posture limit' in failure['errors'] for failure in report['failures']))

    def test_fixed_bones_in_every_joint_pose(self):
        rng=np.random.default_rng(8)
        lower,upper=(a.copy() for a in self.body.bounds);lower[3],upper[3]=-np.pi,np.pi
        for _ in range(30):
            q=rng.uniform(lower,upper);v=self.body.landmarks(q)
            for side in ['-1','1']:np.testing.assert_allclose(np.linalg.norm(np.diff(v['legs'][side],axis=0),axis=1),[THIGH,SHIN],atol=1e-9)
            for side in ['left','right']:np.testing.assert_allclose(np.linalg.norm(np.diff(v['arms'][side],axis=0),axis=1),[UPPER_ARM,FOREARM],atol=1e-9)
    def test_knees_have_one_flexion_axis(self):
        for side in ['left','right']:
            joint=self.body.m.joint(side+'_knee')
            np.testing.assert_allclose(joint.axis,[1,0,0])
            self.assertEqual(len([n for n in self.body.joints if n.startswith(side+'_knee')]),1)
            self.assertEqual(self.body.bounds[1][self.body.index[side+'_knee']],0)
    def test_rejects_hyperextension(self):
        q=self.body.seed('stand',[0,-1],0);q[self.body.index['left_knee']]=.1
        self.assertIn('joint limit',validate_pose(self.body,q,ROW))
    def test_repeated_world_turns_do_not_change_anatomical_limits(self):
        q=self.body.seed('stand',[0,-1],8*np.pi)
        anchors={s:self.body.point(s+'_ankle') for s in ['left','right']}
        for anchor in anchors.values():anchor[2]=.065
        result,report=self.body.fit({},ROW,nominal=q,anchors=anchors,max_nfev=100)
        self.assertTrue(report['accepted'],report)
        self.assertLess(abs(result[3]-8*np.pi),.2)
        self.assertTrue(np.all(result[6:]>=self.body.bounds[0][6:]))
        self.assertTrue(np.all(result[6:]<=self.body.bounds[1][6:]))
    def test_rejects_furniture_penetration(self):
        q=self.body.seed('stand',[0,0],0)
        self.assertTrue(any(isinstance(e,dict) and 'penetration' in e for e in validate_pose(self.body,q,ROW)))
    def test_native_forehead_contact_is_detected_by_the_planner(self):
        import json
        from pathlib import Path
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_native_head_contact.json').read_text())
        body=Body(fixture['spec']);row=fixture['row'];body.obstacles(row);body.set(row['body_q'])
        _,hits=body.collision_penalties()
        self.assertTrue(any({a,b}=={'head','part_shelf_2'} for a,b,_ in hits),hits)
    def test_released_hand_does_not_pin_body(self):
        _,targets=hand_constraints(ROW,SPEC);self.assertEqual(targets,{})
    def test_foot_landing_avoids_visible_parts_and_rack(self):
        from leg_clearance import boxes
        obstacles=boxes(ROW,SPEC);target=np.array([0,0,.065])
        self.assertFalse(landing_clear(target,0,obstacles))
        point=choose_landing(target,0,obstacles,'left',max_shift=.4)
        self.assertTrue(landing_clear(point,0,obstacles))
    def test_work_stance_can_be_reached_by_the_step_planner(self):
        from leg_clearance import boxes
        from foot_contacts import choose_step,stance_valid
        obstacles=boxes(ROW,SPEC);left=np.array([-.095,-2.,.065]);narrow=np.array([.095,-2.,.065])
        self.assertFalse(stance_valid(narrow,0,'right',left))
        goal=choose_landing(narrow,0,obstacles,'right',left,max_shift=.16)
        self.assertTrue(stance_valid(goal,0,'right',left))
        end,_=choose_step(np.array([.2,-2.15,.065]),goal,0,0,obstacles,'right',left,other_yaw=0)
        np.testing.assert_allclose(end,goal,atol=1e-12)
    def test_pelvis_and_spine_have_separate_skin_frames(self):
        q=self.body.seed('stand',[0,-1],0);q[self.body.index['spine_pitch']]=.4
        v=self.body.landmarks(q)
        self.assertFalse(np.allclose(v['segment_frames']['pelvis'],v['segment_frames']['torso']))
    def test_recorded_joint_lists_regenerate_native_forearm_frames(self):
        q=self.body.seed('stand',[0,-1],0)
        v=self.body.landmarks(q.tolist())
        np.testing.assert_allclose(v['q'],q)
        for side in ['L','R']:
            frame=np.array(v['segment_frames']['forearm.'+side])
            np.testing.assert_allclose(frame.T@frame,np.eye(3),atol=1e-12)


class CoupledCarryRegression(unittest.TestCase):
    def test_object_follows_wrist_without_mutating_recording(self):
        import copy
        from carried_body import CarriedBody
        from task_hands import wrist_offset
        from scipy.spatial.transform import Rotation as R
        row=copy.deepcopy(ROW);row['held']='block';before=copy.deepcopy(row)
        base=Body(SPEC);q=base.seed('stand',[0,-1],0);body=CarriedBody(SPEC,row,q)
        body.set(q);first=copy.deepcopy(body.predicted_row)
        q[:2]+=[.2,.1];body.set(q);second=body.predicted_row
        np.testing.assert_allclose(np.array(second['parts']['block'][0])-first['parts']['block'][0],[.2,.1,0],atol=1e-9)
        p,r=second['gripper'];wrist=np.array(p)+R.from_quat(r,scalar_first=True).apply(wrist_offset('left','tool'))
        np.testing.assert_allclose(wrist,body.point('left_wrist'),atol=1e-9)
        self.assertEqual(row,before)
    def test_native_clothing_uses_serialized_joint_frames(self):
        from validate_body_motion import ClothingAudit
        from leg_clearance import boxes
        body=Body(SPEC);q=body.seed('stand',[0,-1],0);v=body.landmarks(q)
        audit=ClothingAudit();self.assertIsInstance(audit.collisions(v,boxes(ROW,SPEC)),dict)
    def test_legacy_leg_report_cannot_authorize_rendering(self):
        import tempfile,json
        from pathlib import Path
        from body_proof import require_body_validation
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory);(path/'leg-validation.json').write_text(json.dumps({'passed':True}))
            with self.assertRaisesRegex(RuntimeError,'leg-only'):require_body_validation(path)

class MotionRegression(unittest.TestCase):
    def test_driver_target_requires_more_time_with_same_joint_limits(self):
        import json
        from pathlib import Path
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_driver_speed.json').read_text())
        row=fixture['row'];debug=row['body_debug'];body=Body(fixture['spec']);_,targets=hand_constraints(row,fixture['spec'])
        previous=np.array(debug['previous']);options=dict(initial=previous,nominal=np.array(debug['nominal']),anchors={s:np.array(a) for s,a in debug['anchors'].items()},foot_yaws=debug['foot_yaws'],continuity=previous,max_nfev=250)
        _,fast=body.fit(targets,row,motion_dt=.04,**options)
        self.assertFalse(fast['accepted'])
        q,slow=body.fit(targets,row,motion_dt=.16,**options)
        self.assertTrue(slow['accepted'],slow)
        self.assertLessEqual(np.max(abs(q[3:]-previous[3:]))/.16,np.pi/2+1e-8)

    def test_blended_waist_clears_panel_with_joint_motion(self):
        import json
        from pathlib import Path
        from validate_body_motion import ClothingAudit
        from leg_clearance import boxes
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_blended_torso_contact.json').read_text())
        body=Body(fixture['spec']);row=fixture['row'];initial=np.array(fixture['q'])
        targets={s:np.array(v) for s,v in fixture['targets'].items()}
        options=dict(nominal=initial,initial=initial,anchors={s:np.array(v) for s,v in fixture['anchors'].items()},
            foot_yaws=fixture['foot_yaws'],continuity=initial,motion_dt=.1,
            balance_center=np.array(fixture['balance_center']),max_nfev=120)
        proxy,report=body.fit(targets,row,surface=False,**options)
        self.assertTrue(report['accepted'],report)
        self.assertTrue(ClothingAudit().collisions(body.landmarks(proxy),boxes(row,body.spec)))
        q,report=body.fit(targets,row,**options)
        self.assertTrue(report['accepted'],report)
        self.assertGreater(report['surface_repair_iterations'],0)
        self.assertEqual(validate_pose(body,q,row,ClothingAudit()),[])
        self.assertLessEqual(np.max(abs(q[3:]-initial[3:])),np.pi/20+1e-9)

    def test_carried_board_clearance_is_not_traded_for_balance_preference(self):
        import json
        from pathlib import Path
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/shelf_carry_clearance.json').read_text())
        row=fixture['row'];debug=row['body_debug'];body=Body(fixture['spec'])
        previous=np.array(debug['previous']);nominal=np.array(debug['nominal'])
        # This older recording used an undersized head proxy. Keep the arms,
        # feet and load exactly as recorded, with a valid forward-looking head,
        # so this test isolates the forearm/load clearance regression.
        for name in ['neck_yaw','neck_pitch']:
            previous[body.index[name]]=0.;nominal[body.index[name]]=0.
        anchors={s:np.array(a) for s,a in debug['anchors'].items()}
        body.obstacles(row);body.set(nominal);balance=body.load_center().copy()
        _,targets=hand_constraints(row,body.spec)
        q,report=body.fit(targets,row,initial=previous,nominal=nominal,anchors=anchors,
            foot_yaws=debug['foot_yaws'],support_sides=[s for s,a in anchors.items() if a[2]<.066],
            continuity=previous,motion_dt=.04,balance_center=balance,max_nfev=150)
        self.assertTrue(report['accepted'],report)
        self.assertLess(report['max_clearance_violation_m'],.001)
        self.assertEqual(validate_pose(body,q,row),[])

    def test_ratchet_contact_is_not_traded_for_a_preferred_pose(self):
        import json
        from pathlib import Path
        fixture=json.loads((Path(__file__).parent/'tests/fixtures/table_ratchet_reach.json').read_text())
        row=fixture['row'];debug=row['body_debug'];body=Body(fixture['spec'])
        _,targets=hand_constraints(row,body.spec)
        previous=np.array(debug['previous'])
        q,report=body.fit(targets,row,initial=previous,nominal=np.array(debug['nominal']),
            anchors={s:np.array(a) for s,a in debug['anchors'].items()},foot_yaws=debug['foot_yaws'],
            continuity=previous,motion_dt=.04,max_nfev=200)
        self.assertTrue(report['accepted'],report)
        self.assertLess(max(report['wrist_error_m'].values()),.001)
        self.assertLessEqual(np.max(abs(q[3:]-previous[3:])),np.pi/2*.04+1e-9)
        self.assertEqual(validate_pose(body,q,row),[])

    def test_swing_clears_loose_board_before_advancing(self):
        from foot_contacts import plan_swing,swing_pose
        obstacles=(['loose_board'],np.array([[0.,0.,.045]]),np.eye(3)[None],np.array([[.05,.1,.045]]))
        start=np.array([-.25,0,.065]);end=np.array([.25,0,.065]);height=plan_swing(start,end,0,0,obstacles)
        self.assertGreater(height,.1)
        self.assertTrue(all(landing_clear(*swing_pose(start,end,0,0,height,u),obstacles) for u in np.linspace(0,1,201)))
        np.testing.assert_allclose(swing_pose(start,end,0,0,height,.2)[0][:2],start[:2])
    def test_swing_uses_same_clearance_as_declared_landing(self):
        from foot_contacts import plan_swing
        obstacles=(['board'],np.array([[0.,0.,.045]]),np.eye(3)[None],np.array([[.05,.1,.045]]))
        start=np.array([-.25,0,.065]);end=np.array([.13,0,.065])
        self.assertTrue(landing_clear(end,0,obstacles,.012))
        self.assertFalse(landing_clear(end,0,obstacles,.018))
        self.assertGreater(plan_swing(start,end,0,0,obstacles),0.)
    def test_turning_step_clears_the_planted_shoe(self):
        from foot_contacts import choose_step,swing_pose
        obstacles=([],np.empty((0,3)),np.empty((0,3,3)),np.empty((0,3)))
        start=np.array([.254,0,.065]);other=np.array([0,0,.065]);target=np.array([.19,.05,.065])
        end,height=choose_step(start,target,0,.35,obstacles,'right',other,other_yaw=0)
        planted=(['planted_shoe'],np.array([[0,.04,.04]]),np.eye(3)[None],np.array([[.065,.13,.04]]))
        self.assertFalse(landing_clear(target,.35,planted))
        self.assertTrue(all(landing_clear(*swing_pose(start,end,0,.35,height,u),planted) for u in np.linspace(0,1,201)))
    def test_temporal_bounds_prevent_joint_branch_jumps(self):
        body=Body(SPEC);previous=body.seed('stand',[0,-1],0);nominal=previous.copy();nominal[body.index['left_elbow']]+=1.
        q,_=body.fit({},ROW,initial=nominal,nominal=nominal,continuity=previous,motion_dt=.04,max_nfev=10)
        self.assertLessEqual(np.max(np.abs(q[3:]-previous[3:])),np.pi/2*.04+1e-9)
        self.assertLessEqual(np.linalg.norm(q[:3]-previous[:3]),1.5*.04)

class RouteRegression(unittest.TestCase):
    def test_route_goes_around_floor_obstacle(self):
        from walk_route import plan_route
        obstacles=(['panel'],np.array([[0.,0.,.02]]),np.eye(3)[None],np.array([[.2,.2,.02]]))
        route=plan_route([-.8,0],[.8,0],obstacles)
        self.assertGreater(max(abs(p[1]) for p in route),.42)
        for a,b in zip(route,route[1:]):
            for u in np.linspace(0,1,31):
                point=a*(1-u)+b*u
                self.assertTrue(np.any(abs(point)>.419))

if __name__=='__main__':unittest.main()
