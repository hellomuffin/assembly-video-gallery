"""Recording checks: actual constraints, contact geometry, action direction,
tool clearance and finite arm reach. No assertion of exact finger contacts."""
from pathlib import Path
import json,sys,numpy as np,mujoco,hashlib,os
from scipy.spatial.transform import Rotation as R
from leg_clearance import boxes
H=Path(__file__).resolve().parent
def audit(name,seed=1):
 O=Path(os.environ.get('PRODUCT_DATA',H.parent/'outputs/product_v1'/f'{name}_{seed}'));rows=json.loads((O/'trajectory.json').read_text());spec=json.loads((O/'asset.json').read_text());parts={p['id']:p for p in spec['parts']}
 m=mujoco.MjModel.from_binary_path(str(O/'model.mjb'));d=mujoco.MjData(m);maxpen=0;bad=[];toolbad=[];worst=None;max_tip_error=0.;direction_errors=[];premature=[];previous=None
 for row in rows:
  for key in row['fastened']:
   c=next(c for c in spec['connectors'] if c['id']==key)
   if row['engagement'][key]+1e-9<c['required_turns']:premature.append(row['t'])
  if row['tool_engaged'] and row['connector']:
   c=next(c for c in spec['connectors'] if c['id']==row['connector'])
   ap,aq=row['parts'][c['a']];ar=R.from_quat(aq,scalar_first=True);axis=ar.apply(c['tool_axis'])
   e=min(1,row['engagement'][c['id']]/c['required_turns'])
   target=np.array(ap)+ar.apply(c['tool_position'])-axis*(.012*(1-e)+.0015)
   tip=np.array(row['tool'][0])+R.from_quat(row['tool'][1],scalar_first=True).apply([0,-.14,0])
   max_tip_error=max(max_tip_error,float(np.linalg.norm(tip-target)))
   if previous and previous['stage']==row['stage'] and row['stage'].startswith('Tighten clockwise'):
    if row['engagement'][c['id']]>previous['engagement'][c['id']]+1e-8 and row['stroke']<=previous['stroke']:direction_errors.append(row['t'])
  previous=row
  expected={m.equality('joint_'+k).id for k in row['fastened']}
  if row['held']:expected.add(m.equality('grasp_'+row['held']).id)
  if set(row['active_constraints'])!=expected:bad.append(row['t'])
  for n,(p,q) in {**row['parts'],'gripper':row['gripper']}.items():
   adr=m.jnt_qposadr[m.body_jntadr[m.body(n).id]];d.qpos[adr:adr+7]=[*p,*q]
  mujoco.mj_forward(m,d)
  for c in d.contact:
   if -c.dist>maxpen:maxpen=-c.dist;worst={'t':row['t'],'geoms':[m.geom(c.geom1).name,m.geom(c.geom2).name]}
  pos=np.array(row['tool'][0]);rot=R.from_quat(row['tool'][1],scalar_first=True)*R.from_rotvec([0,-row['stroke'],0])
  local=np.r_[np.c_[np.linspace(-.07,.07,13),np.zeros(13),np.zeros(13)],np.c_[np.zeros(18),np.linspace(-.02,-.14,18),np.zeros(18)]]
  radii=np.r_[np.full(13,.017),np.full(18,.003)]
  points=rot.apply(local)+pos
  names,centers,rotations,half=boxes(row,spec)
  local_points=np.einsum('pbi,bij->pbj',points[:,None]-centers,rotations)
  qdist=np.abs(local_points)-half
  sd=np.linalg.norm(np.maximum(qdist,0),axis=2)+np.minimum(np.max(qdist,axis=2),0)-radii[:,None]
  for index,n in enumerate(names):
   if sd[:,index].min()<-.004:toolbad.append({'t':round(row['t'],3),'part':n,'depth_m':float(-sd[:,index].min()),'stage':row['stage']})
  floor=float(np.min(points[:,2]-radii))
  if floor<-.001:toolbad.append({'t':round(row['t'],3),'part':'floor','depth_m':-floor,'stage':row['stage']})

 report={'engaged_tool_tip_tolerance_m':.005,'maximum_engaged_tool_tip_error_m':max_tip_error,'clockwise_direction_errors':direction_errors,'premature_fastening':premature,'constraint_mismatches':bad,'maximum_sampled_furniture_penetration_m':float(maxpen),'worst_contact':worst,'tool_intersection_frames_over_4mm':len([hit for hit in toolbad if hit['part']!='floor']),'tool_floor_intersections_over_1mm':len([hit for hit in toolbad if hit['part']=='floor']),'worst_tool_intersections':sorted(toolbad,key=lambda r:-r['depth_m'])[:12],
 'trajectory_sha256':hashlib.sha256((O/'trajectory.json').read_bytes()).hexdigest(),
 'scope':'25 Hz sampled replay audit; tool capsule samples checked against parts, attached hardware, fixtures and floor; finger contact is intentionally not exact.'}
 report['passed']=not bad and maxpen<.003 and not toolbad and max_tip_error<.005 and not direction_errors and not premature
 (O/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':audit(sys.argv[1])
