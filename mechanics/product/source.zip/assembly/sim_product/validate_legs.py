"""Fail-closed validation for leg-safe rendered replay artifacts."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from leg_clearance import boxes,gaps,interpolate_obstacles
from audit_leg_surface import LegSurface


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(rows,visuals,spec):
    assert len(rows)==len(visuals) and len(rows)>1
    skin=LegSurface();obs=[boxes(r,spec) for r in rows]
    failures=[];worst=float('inf');worst_frame=None;surface_hits=[];floor_min=1.;support_fail=[];limb_error=0.;subframes=0
    for i,(row,v,o) in enumerate(zip(rows,visuals,obs)):
        distance,labels=gaps(v,o);gap=float(distance.min())
        if gap<worst:worst=gap;worst_frame=i
        if gap< -1e-6:failures.append(dict(frame=i,gap_m=gap))
        vertices=skin.points(v)
        hit=skin.collisions(v,o,vertices)
        if hit:surface_hits.append(dict(frame=i,parts=hit))
        used=np.unique(skin.triangles);floor_min=min(floor_min,float(vertices[used,2].min()))
        for leg in v['legs'].values():
            a,k,f=np.array(leg);limb_error=max(limb_error,abs(np.linalg.norm(a-k)-.52),abs(np.linalg.norm(k-f)-.52))
        if i:
            prev=visuals[i-1]
            planted=[s for s in v['legs'] if np.linalg.norm(np.array(v['legs'][s][2])-prev['legs'][s][2])<1e-8 and abs(v['legs'][s][2][2]-.055)<1e-8]
            if not planted:support_fail.append(i)
            for u in [.25,.5,.75]:
                iv=dict(legs={s:(np.array(prev['legs'][s])*(1-u)+np.array(v['legs'][s])*u).tolist() for s in v['legs']},back=(np.array(prev['back'])*(1-u)+np.array(v['back'])*u).tolist())
                io=interpolate_obstacles(obs[i-1],o,u);d,_=gaps(iv,io);subframes+=1
                if d.min()< -1e-6:failures.append(dict(frame=i-1+u,gap_m=float(d.min())))
        if i%1000==0:print('audit',i,'envelope hits',len(failures),'skin hits',len(surface_hits),flush=True)
    speed={}
    for label,index in [('hip',0),('knee',1),('foot',2)]:
        series=[np.array([v['hip'] for v in visuals])] if label=='hip' else [np.array([v['legs'][s][index] for v in visuals]) for s in ['-1','1']]
        dt=np.diff([r['t'] for r in rows]);speed[label]=float(max((np.linalg.norm(np.diff(a,axis=0),axis=1)/dt).max() for a in series))
    checks=dict(leg_envelopes_clear=not failures,trouser_mesh_clear=not surface_hits,trousers_above_floor=floor_min>=-.002,fixed_limb_lengths=limb_error<1e-5,one_stationary_floor_foot=not support_fail)
    checks={k:bool(value) for k,value in checks.items()}
    return dict(passed=all(checks.values()),checks=checks,frames=len(rows),intermediate_capsule_samples=subframes,minimum_recorded_capsule_gap_m=worst,worst_frame=worst_frame,minimum_trouser_height_m=floor_min,maximum_limb_length_error_m=limb_error,maximum_landmark_speed_m_s=speed,envelope_failures=failures,surface_failures=surface_hits,unsupported_transitions=support_fail,scope='Thigh/calf/shoe envelopes versus recorded furniture, mounting brackets and driver rack at 25 Hz plus three interpolated samples per interval; rendered trouser triangles at every recorded frame. Fixed leg lengths and alternating planted-foot support are kinematic checks, not balance or full-body dynamics certification.')

def source_hashes():
    h=Path(__file__).resolve().parent
    return {name:sha(h/name) for name in ['prepare_visuals.py','plan_legs.py','smooth_legs.py','repair_leg_transitions.py','leg_clearance.py','audit_leg_surface.py','validate_legs.py','render.py','../sim_v5/human_surface.py','../sim_v5/assets/makehuman/base.obj','../sim_v5/assets/makehuman/default_weights.mhw','../sim_v5/assets/makehuman/default.mhskel']}


def stamp(report,folder,visual_path):
    report.update(trajectory_sha256=sha(folder/'trajectory.json'),visuals_sha256=sha(visual_path),asset_sha256=sha(folder/'asset.json'),validation_source_sha256=source_hashes())
    (folder/'leg-validation.json').write_text(json.dumps(report,indent=2))


def require_leg_validation(folder):
    report=json.loads((folder/'leg-validation.json').read_text())
    assert report['passed'], 'Leg clearance validation failed'
    for file,key in [('trajectory.json','trajectory_sha256'),('visuals.json','visuals_sha256'),('asset.json','asset_sha256')]:
        assert report[key]==sha(folder/file), f'Stale leg validation: {file}'
    assert report['validation_source_sha256']==source_hashes(), 'Leg validator/planner changed; revalidate'
    return report


if __name__=='__main__':
    H=Path(__file__).resolve().parent;d=H.parent/'outputs/product_v1'/sys.argv[1];vpath=d/(sys.argv[2] if len(sys.argv)>2 else 'visuals.json')
    report=validate(json.loads((d/'trajectory.json').read_text()),json.loads(vpath.read_text()),json.loads((d/'asset.json').read_text()))
    stamp(report,d,vpath)
    print(json.dumps({k:v for k,v in report.items() if not isinstance(v,list)},indent=2));sys.exit(0 if report['passed'] else 1)
