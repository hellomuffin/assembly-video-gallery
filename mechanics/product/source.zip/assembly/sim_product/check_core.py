"""Re-run the existing causal-physics regressions in a new evidence directory."""
from pathlib import Path
import sys
H=Path(__file__).resolve().parent;core=H.parent/'sim_shared'
sys.path.insert(0,str(core))
source=(core/'test_physics.py').read_text().replace("OUT=ROOT.parent/'outputs/shared_v1'","OUT=ROOT.parent/'outputs/product_v1/core-regression';OUT.mkdir(parents=True,exist_ok=True)")
exec(compile(source,str(core/'test_physics.py'),'exec'),{'__file__':str(core/'test_physics.py'),'__name__':'__main__'})
