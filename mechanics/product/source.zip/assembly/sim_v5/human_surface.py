"""Private visual MakeHuman surface retargeting, never a physics controller.

The CC0 mesh is driven by the existing operator landmarks. Native simulated
forearms/hands and existing shoes remain separate. This surface needs its own
mesh contact audit; the older ellipsoid screen does not validate it.
"""
from pathlib import Path
import json,os
import numpy as np

ASSETS=Path(__file__).parent/'assets/makehuman'

def unit(v):
 v=np.asarray(v,dtype=float);return v/max(np.linalg.norm(v),1e-12)

def frame(a,b,forward):
 z=unit(np.asarray(b)-a);x=np.asarray(forward)-z*np.dot(forward,z)
 if np.linalg.norm(x)<1e-6:
  seed=np.eye(3)[np.argmin(np.abs(z))];x=seed-z*np.dot(seed,z)
 x=unit(x);return np.column_stack([x,np.cross(z,x),z])

class Surface:
 def __init__(self,elbow_twist=False):
  self.elbow_twist=elbow_twist;self.arm_reference={}
  vertices=[];faces=[];group=None
  for line in (ASSETS/'base.obj').read_text().splitlines():
   fields=line.split()
   if not fields:continue
   if fields[0]=='v':vertices.append([float(x) for x in fields[1:4]])
   elif fields[0]=='g':group=fields[1]
   elif fields[0]=='f' and group=='body':faces.append([int(x.split('/')[0])-1 for x in fields[1:]])
  v=np.array(vertices);self.rest=np.column_stack([-v[:,0],v[:,2],v[:,1]])*.1
  rig=json.loads((ASSETS/'default.mhskel').read_text());weights=json.loads((ASSETS/'default_weights.mhw').read_text())['weights']
  joints={k:self.rest[ids].mean(axis=0) for k,ids in rig['joints'].items()}
  def point(bone,end='head'):return joints[rig['bones'][bone][end]]
  self.hip=(point('upperleg01.L')+point('upperleg01.R'))/2
  self.shoulder=(point('upperarm01.L')+point('upperarm01.R'))/2
  self.head=(point('head')+point('head','tail'))/2
  self.segments={'torso':(self.hip,self.shoulder),'head':(self.head,self.head+[0,0,.1])}
  if os.environ.get('HUMAN_SURFACE_NECK')=='1':self.segments['neck']=(point('neck01'),point('head'))
  for side in ['L','R']:
   self.arm_reference[side]=point('wrist.'+side)-point('lowerarm01.'+side)
   self.segments['arm.'+side]=(point('upperarm01.'+side),point('lowerarm01.'+side))
   self.segments['thigh.'+side]=(point('upperleg01.'+side),point('lowerleg01.'+side))
   self.segments['shin.'+side]=(point('lowerleg01.'+side),point('foot.'+side))
  self.names=list(self.segments);self.weights=np.zeros((len(self.rest),len(self.names)));removed=np.zeros(len(self.rest))
  for bone,entries in weights.items():
   if bone.startswith(('lowerarm','wrist','finger','metacarpal','foot','toe')):target=None
   elif bone.startswith('neck') and 'neck' in self.segments:target='neck'
   elif bone.startswith('upperarm'):target='arm.'+bone[-1]
   elif bone.startswith('upperleg'):target='thigh.'+bone[-1]
   elif bone.startswith('lowerleg'):target='shin.'+bone[-1]
   elif bone.startswith(('spine','root','pelvis','breast','clavicle','shoulder')):target='torso'
   else:target='head'
   for index,w in entries:
    if target is None:removed[index]+=w
    else:self.weights[index,self.names.index(target)]+=w
  self.faces=[face for face in faces if max(removed[face])<.5 and min(self.weights[face].sum(axis=1))>1e-8]
  self.weights/=np.maximum(self.weights.sum(axis=1,keepdims=True),1e-12)
  self.used=np.unique(np.concatenate(self.faces));self.inverse=np.full(len(self.rest),-1,dtype=int);self.inverse[self.used]=np.arange(len(self.used))
  self.faces=[self.inverse[face].tolist() for face in self.faces]
  self.materials=[]
  for face in self.faces:
   ids=self.used[face];mean=self.weights[ids].mean(axis=0)
   # Clothing is a visual material on the surface, not simulated cloth.
   category=self.names[int(np.argmax(mean))]
   self.materials.append(0 if category in ['head','neck'] else 2 if category.startswith(('thigh','shin')) or self.rest[ids,2].mean()<self.hip[2]+.07 else 1)

 def deform(self,row):
  v=row['operator'];c=np.array(v['shoulder_center']);hip=np.array(v['hip']);forward=np.array(v['forward']);head=np.array(v['head']);head_forward=np.array(v.get('head_forward',forward))
  target={'torso':(hip,c,forward),'head':(head,head+[0,0,.1],head_forward)}
  if os.environ.get('HUMAN_SURFACE_HEAD_GAZE')=='1':
   q=np.asarray(v['camera_quaternion'],dtype=float);q/=np.linalg.norm(q)
   def rotate(vector):
    vector=np.asarray(vector,dtype=float);twice=2*np.cross(q[1:],vector)
    return vector+q[0]*twice+np.cross(q[1:],twice)
   target['head']=(head,head+.1*rotate([0,1,0]),rotate([0,0,-1]))
  if 'neck' in self.segments:
   # Attach the neck at the actual neighboring rest-bone landmarks. Fixed
   # offsets leave the pitched head penetrating its stretched neck surface.
   a,b=self.segments['neck'];old_torso=frame(self.hip,self.shoulder,[0,1,0]);new_torso=frame(hip,c,forward)
   local=(a-self.hip)@old_torso;local[2]*=np.linalg.norm(c-hip)/np.linalg.norm(self.shoulder-self.hip)
   neck_base=local@new_torso.T+hip
   old_head=frame(*self.segments['head'],[0,1,0]);new_head=frame(*target['head'])
   neck_top=(b-self.head)@old_head@new_head.T+head
   target['neck']=(neck_base,neck_top,head_forward)
  for side,hand,leg in [('L','hand_left','-1'),('R','hand_right','1')]:
   shoulder,elbow,_=np.asarray(v['arms'][hand]);h,k,f=np.asarray(v['legs'][leg])
   arm_forward=np.asarray(row['hands'][hand]['bodies']['lunate_r'][0])-elbow if self.elbow_twist else forward
   target['arm.'+side]=(shoulder,elbow,arm_forward)
   target['thigh.'+side]=(h,k,np.array(v.get('pelvis_forward',forward)))
   target['shin.'+side]=(k,f,np.array(v.get('pelvis_forward',forward)))
  transformed=np.zeros_like(self.rest);rotations=[];translations=[];stretch=np.zeros_like(self.rest)
  for j,name in enumerate(self.names):
   a,b=self.segments[name];ta,tb,tf=target[name]
   reference=self.arm_reference[name[-1]] if self.elbow_twist and name.startswith('arm.') else [0,1,0]
   old=frame(a,b,reference);new=frame(ta,tb,tf)
   local=(self.rest-a)@old;local[:,2]*=np.linalg.norm(tb-ta)/np.linalg.norm(b-a)
   points=local@new.T+ta;transformed+=points*self.weights[:,j,None]
   rotation=new@old.T;rotations.append(rotation);translations.append(ta-rotation@a)
   stretch+=(local@old.T+a-self.rest)*self.weights[:,j,None]
  if os.environ.get('HUMAN_SURFACE_SKINNING')=='dq':
   from human_hand_surface import dual_quaternion_skin
   transformed[self.used]=dual_quaternion_skin((self.rest+stretch)[self.used],np.asarray(rotations),np.asarray(translations),self.weights[self.used].T)
  result=transformed[self.used]
  if not np.isfinite(result).all():raise ValueError('Nonfinite human surface')
  return result
