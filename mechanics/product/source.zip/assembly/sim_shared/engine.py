"""Furniture-independent assembly action executor with explicit approximations.

A finite-force virtual gripper uses an assisted grasp. Screw groups use guarded
fixed joints after abstract tool turns, not detailed thread contact. Furniture
poses are never assigned after initialization. This is a mechanics/action core,
not an anatomical human or a learned assembly policy.
"""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation as R

class ActionRejected(RuntimeError): pass

def numbers(values): return ' '.join(str(float(v)) for v in values)

class AssemblyWorld:
    def __init__(self, asset, seed=0):
        self.spec=json.loads(Path(asset).read_text())
        self.parts={p['id']:p for p in self.spec['parts']}
        self.connectors={c['id']:c for c in self.spec['connectors']}
        assert len(self.parts)==len(self.spec['parts'])
        assert len(self.connectors)==len(self.spec['connectors'])
        self.engagement={c:0. for c in self.connectors};self.fastened=set();self.held=None
        self.events=[];self.rows=[];self.steps=0
        rng=np.random.default_rng(seed)
        root=ET.Element('mujoco',model=self.spec['id'])
        ET.SubElement(root,'option',timestep='.001',gravity='0 0 -9.81',integrator='implicitfast')
        default=ET.SubElement(root,'default')
        ET.SubElement(default,'geom',friction='.7 .01 .001',solref='.008 1',condim='3')
        world=ET.SubElement(root,'worldbody')
        ET.SubElement(world,'geom',name='floor',type='plane',size='3 3 .1',priority='1',solref='.002 1',rgba='.28 .32 .29 1')
        ET.SubElement(world,'light',pos='0 -2 4',dir='0 0 -1')
        self.initial={};occupied=[]
        # Fixtures participate in both physical contact and initial placement.
        # A visible rack must not be absent from the scene used to scatter parts.
        for fixture in self.spec.get('fixtures',[]):
            position=np.asarray(fixture['position'],float);size=np.asarray(fixture['size'],float)
            rotation=R.from_quat(fixture.get('rotation',[1,0,0,0]),scalar_first=True)
            ET.SubElement(world,'geom',name='fixture_'+fixture['id'],type='box',
                pos=numbers(position),quat=numbers(rotation.as_quat(scalar_first=True)),
                size=numbers(size/2),rgba='.45 .32 .18 1')
            occupied.append((position[:2].copy(),(np.abs(rotation.as_matrix())@size/2)[:2]))
        ordered=[self.parts[self.spec['base']]]+[p for n,p in self.parts.items() if n!=self.spec['base']]
        for index,p in enumerate(ordered):
            size=np.array(p['size']);rotation=R.identity()
            signs=np.array(np.meshgrid([-1,1],[-1,1],[-1,1])).T.reshape(-1,3)
            local_corners=[signs*size/2]
            for box in p.get('collision_boxes',[]):
                local_corners.append(np.asarray(box['position'])+R.from_quat(box.get('rotation',[1,0,0,0]),scalar_first=True).apply(signs*np.asarray(box['size'])/2))
            local_corners=np.vstack(local_corners)
            if p['id']==self.spec['base']:
                position=np.array(p['assembly_position'],float)
            else:
                # Lay the thin dimension on the floor, then randomize yaw.
                thin=int(np.argmin(size))
                rotation=R.from_euler('y',np.pi/2) if thin==0 else R.from_euler('x',np.pi/2) if thin==1 else R.identity()
                rotation=R.from_euler('z',rng.uniform(-.35,.35))*rotation
                corners=rotation.apply(local_corners)
                height=-float(corners[:,2].min())
                half_xy=np.max(np.abs(corners[:,:2]),axis=0)
                for _ in range(2000):
                    xy=rng.uniform([-1.05,-1.85],[1.05,-.65])
                    if all(np.any(np.abs(xy-other)>half_xy+extent+.04) for other,extent in occupied):break
                else:raise ActionRejected('Cannot scatter parts without initial overlaps')
                position=np.r_[xy,height+.003]
            occupied.append((position[:2].copy(),np.max(np.abs(rotation.apply(local_corners)[:,:2]),axis=0)))
            self.initial[p['id']]=(position.copy(),rotation)
            b=ET.SubElement(world,'body',name=p['id'],pos=numbers(position),quat=numbers(rotation.as_quat(scalar_first=True)))
            ET.SubElement(b,'freejoint',name='free_'+p['id'])
            ET.SubElement(b,'geom',name='shape_'+p['id'],type='box',size=numbers(size/2),mass=str(p['mass']),rgba='.72 .55 .34 1')
            for box in p.get('collision_boxes',[]):
                # Hardware belongs to the same rigid part; its mass is already
                # included in the part's declared mass, not counted twice.
                ET.SubElement(b,'geom',name='attachment_'+box['id'],type='box',
                    pos=numbers(box['position']),quat=numbers(box.get('rotation',[1,0,0,0])),
                    size=numbers(np.asarray(box['size'])/2),mass='0',rgba='.5 .5 .52 1')
        b=ET.SubElement(world,'body',name='gripper',pos='0 -1 1.2')
        ET.SubElement(b,'freejoint',name='free_gripper')
        ET.SubElement(b,'inertial',pos='0 0 0',mass='.2',diaginertia='.003 .003 .003')
        ET.SubElement(b,'geom',name='gripper_marker',type='sphere',size='.025',mass='.2',contype='0',conaffinity='0',rgba='.3 .8 .6 .6')
        eq=ET.SubElement(root,'equality')
        for p in self.parts:
            ET.SubElement(eq,'weld',name='grasp_'+p,body1='gripper',body2=p,active='false',relpose='0 0 0 1 0 0 0',solref='.004 1',solimp='.999 .9999 .001 .5 2')
        for c in self.connectors.values():
            assert c['kind']=='screw_group', 'Connector kind needs an explicit implementation'
            assert c['a'] in self.parts and c['b'] in self.parts and c['a']!=c['b']
            rel=np.array(self.parts[c['b']]['assembly_position'])-self.parts[c['a']]['assembly_position']
            # These are fastened rigid connections. Default soft impedance
            # let a table-leg joint bend over 20 degrees under the carried load.
            # Keep finite actuator limits, but enforce the intended fixed joint.
            ET.SubElement(eq,'weld',name='joint_'+c['id'],body1=c['a'],body2=c['b'],active='false',relpose=numbers([*rel,1,0,0,0]),solref='.004 1',solimp='.999 .9999 .001 .5 2')
        self.xml=ET.tostring(root,encoding='unicode');self.m=mujoco.MjModel.from_xml_string(self.xml);self.d=mujoco.MjData(self.m)
        self.ids={name:self.m.body(name).id for name in [*self.parts,'gripper']}
        self.target=np.array([0.,-1.,1.2]);self.target_rotation=R.identity()
        self.max_force=100.;self.max_torque=15.
        dof=self.m.jnt_dofadr[self.m.joint('free_gripper').id]
        self.m.dof_damping[dof:dof+6]=[35,35,35,3,3,3]
        mujoco.mj_forward(self.m,self.d);self.advance(.5)

    def pose(self,name):
        i=self.ids[name];return self.d.xpos[i].copy(),R.from_matrix(self.d.xmat[i].reshape(3,3))

    def group(self,name):
        found={name}
        while True:
            previous=len(found)
            for key in self.fastened:
                c=self.connectors[key]
                if c['a'] in found or c['b'] in found:found.update([c['a'],c['b']])
            if len(found)==previous:return found

    def advance(self,seconds):
        for _ in range(round(seconds/self.m.opt.timestep)):
            p,r=self.pose('gripper');vel=np.zeros(6)
            mujoco.mj_objectVelocity(self.m,self.d,mujoco.mjtObj.mjOBJ_BODY,self.ids['gripper'],vel,0)
            gravity_force,gravity_torque=self.gravity_wrench(p)
            force=650*(self.target-p)+gravity_force
            torque=35*(self.target_rotation*r.inv()).as_rotvec()+gravity_torque
            force*=min(1.,self.max_force/max(np.linalg.norm(force),1e-12));torque*=min(1.,self.max_torque/max(np.linalg.norm(torque),1e-12))
            self.d.xfrc_applied[:]=0;self.d.xfrc_applied[self.ids['gripper']]=[*force,*torque]
            mujoco.mj_step(self.m,self.d);self.steps+=1
            if not np.isfinite(self.d.qpos).all():raise RuntimeError('Nonfinite dynamics')
            if self.steps%round(.04/self.m.opt.timestep)==0:
                self.rows.append(dict(gripper=[self.pose('gripper')[0].tolist(),self.pose('gripper')[1].as_quat(scalar_first=True).tolist()],active_constraints=np.flatnonzero(self.d.eq_active).tolist(),t=float(self.d.time),parts={n:[p.tolist(),r.as_quat(scalar_first=True).tolist()] for n in self.parts for p,r in [self.pose(n)]},held=self.held,fastened=sorted(self.fastened)))

    def gravity_wrench(self,origin):
        """Compensate the carried weight that external contacts do not support.

        Joining a grounded assembly must not suddenly lift its entire weight
        through the held component. Use the previous physics step's measured
        support along gravity, including its moment about the real grasp. In
        free space this reduces to full weight and off-center load compensation.
        This is feedforward only; the same finite wrench limits still apply.
        """
        gravity=-self.m.opt.gravity;length=float(np.linalg.norm(gravity))
        group=self.group(self.held) if self.held else set()
        mass=sum(self.parts[n]['mass'] for n in group)
        force=(.2+mass)*gravity;torque=np.zeros(3)
        for name in group:torque+=np.cross(self.pose(name)[0]-origin,self.parts[name]['mass']*gravity)
        if not group or length<1e-12:return force,torque
        up=gravity/length;ids={self.ids[n] for n in group};supported=0.;moment=np.zeros(3)
        for index,contact in enumerate(self.d.contact):
            a,b=[int(self.m.geom_bodyid[g]) for g in contact.geom]
            if (a in ids)==(b in ids):continue
            wrench=np.zeros(6);mujoco.mj_contactForce(self.m,self.d,index,wrench)
            external=contact.frame.reshape(3,3).T@wrench[:3]*(1 if b in ids else -1)
            load=max(0.,float(external@up));supported+=load
            moment+=np.cross(contact.pos-origin,up*load)
        # Impacts can exceed static weight. They must not turn gravity
        # compensation into a downward pull from the hand.
        fraction=min(1.,mass*length/max(supported,1e-12))
        return force-up*(fraction*supported),torque-fraction*moment

    def move(self,position,rotation=None,speed=.35):
        start=self.target.copy();a=self.target_rotation;end=np.array(position,float);rotation=rotation or a
        delta=(rotation*a.inv()).as_rotvec();duration=max(.25,np.linalg.norm(end-start)/speed,np.linalg.norm(delta)/.8)
        count=int(np.ceil(duration/.02))
        for i in range(count):
            u=(i+1)/count;u=u*u*(3-2*u);self.target=start*(1-u)+end*u;self.target_rotation=R.from_rotvec(delta*u)*a;self.advance(.02)
        self.advance(.25)

    def grasp(self,part):
        if self.held:raise ActionRejected('Release the current grasp first')
        p,r=self.pose(part);hp,hr=self.pose('gripper')
        if np.linalg.norm(p-hp)>.02:raise ActionRejected('Hand is not at the declared center grasp site')
        eid=self.m.equality('grasp_'+part).id
        self.m.eq_data[eid,3:6]=hr.inv().apply(p-hp);self.m.eq_data[eid,6:10]=(hr.inv()*r).as_quat(scalar_first=True)
        self.d.eq_active[eid]=True;self.held=part;self.events.append(dict(t=self.d.time,action='grasp',part=part))

    def release(self):
        if not self.held:return
        self.d.eq_active[self.m.equality('grasp_'+self.held).id]=False
        self.events.append(dict(t=self.d.time,action='release',part=self.held));self.held=None

    def mating_error(self,key):
        c=self.connectors[key];ap,ar=self.pose(c['a']);bp,br=self.pose(c['b'])
        relative=np.array(self.parts[c['b']]['assembly_position'])-self.parts[c['a']]['assembly_position']
        return np.linalg.norm(bp-(ap+ar.apply(relative))),(ar.inv()*br).magnitude()

    def align(self,key):
        """Track the requested receiver as it moves; do not choose a connector."""
        c=self.connectors[key]
        if self.held!=c['b']:raise ActionRejected('Hold the requested moving component before aligning')
        eq=self.m.eq_data[self.m.equality('grasp_'+self.held).id]
        local=eq[3:6].copy();relative=R.from_quat(eq[6:10],scalar_first=True)
        offset=np.array(self.parts[c['b']]['assembly_position'])-self.parts[c['a']]['assembly_position']
        for _ in range(20):
            error,angle=self.mating_error(key)
            if error<.002 and angle<np.radians(.5):return
            p,r=self.pose(c['a']);desired=r*relative.inv()
            self.move(p+r.apply(offset)-desired.apply(local),desired)
        raise ActionRejected('Alignment did not converge against the moving receiver')

    def tool_site(self,key):
        c=self.connectors[key];p,r=self.pose(c['a'])
        return p+r.apply(c['tool_position']),r.apply(c['tool_axis'])

    def turn(self,key,turns,torque,tool_position,tool_axis):
        c=self.connectors[key];pos,axis=self.tool_site(key)
        if not np.isfinite([turns,torque,*tool_position,*tool_axis]).all():raise ActionRejected('Nonfinite tool action')
        provided=np.asarray(tool_axis,float)
        if np.linalg.norm(provided)<1e-9:raise ActionRejected('Missing tool axis')
        if np.linalg.norm(np.asarray(tool_position)-pos)>.015 or np.dot(provided/np.linalg.norm(provided),axis)<np.cos(np.radians(8)):
            raise ActionRejected('Tool is not aligned with this connector')
        error,angle=self.mating_error(key)
        if error>.006 or angle>np.radians(3):raise ActionRejected('Components are not aligned')
        if abs(torque)<c['minimum_torque']:raise ActionRejected('Insufficient tightening torque')
        if abs(turns)>.25:raise ActionRejected('Turn increments must be at most a quarter turn')
        self.engagement[key]=max(0.,self.engagement[key]+float(turns))
        eid=self.m.equality('joint_'+key).id
        if self.engagement[key]>=c['required_turns']:
            self.d.eq_active[eid]=True;self.fastened.add(key)
        else:
            self.d.eq_active[eid]=False;self.fastened.discard(key)
        self.events.append(dict(t=float(self.d.time),action='turn',connector=key,turns=float(turns),engagement=self.engagement[key],joint_active=key in self.fastened))
        self.advance(abs(turns)*.4)

    def save(self,out):
        out=Path(out);out.mkdir(parents=True,exist_ok=True)
        (out/'model.xml').write_text(self.xml)
        mujoco.mj_saveModel(self.m,str(out/'model.mjb'))
        np.savez(out/'final_state.npz',qpos=self.d.qpos,qvel=self.d.qvel,eq_active=self.d.eq_active,mocap_pos=self.d.mocap_pos,mocap_quat=self.d.mocap_quat)
        (out/'trajectory.json').write_text(json.dumps(self.rows))
        (out/'events.json').write_text(json.dumps(self.events,indent=2))
        (out/'scope.json').write_text(json.dumps(dict(scope=__doc__,asset=self.spec['id'],physics_hz=round(1/self.m.opt.timestep),collision_geometries=self.m.ngeom),indent=2))
